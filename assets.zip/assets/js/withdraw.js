(function($){
	"use strict";

    $('.add_wallet_value').on('click',function(){
        var id=$(this).attr('data-amount');
        $("#wallet_amt").val(id);
    }); 
	
    $('#stripe_withdraw_wallet').on('click',function(){
		var stripe_amt=$("#wallet_amt").val();
		var wallet_amount=$('#wallet_amount').val();
		var payment_type =$( 'input[name="group2"]:checked' ).val();
		if(payment_type==undefined || payment_type==''){
			swal({
				title: payments,
				text: payment_method,
				icon: "error",
				button: "okay",
				closeOnEsc: false,
				closeOnClickOutside: false
			});
			$("#wallet_amt").select();
			return false;
		}
		if(stripe_amt>wallet_amount){
			swal({
				title: wallet,
				text: wallet_amt_available,
				icon: "error",
				button: "okay",
				closeOnEsc: false,
				closeOnClickOutside: false
			});
			$("#wallet_amt").select();
			return false;
		}
		if(stripe_amt =='' || stripe_amt < 1){
			swal({
				title: wallet,
				text: wallet_field,
				icon: "error",
				button: "okay",
				closeOnEsc: false,
				closeOnClickOutside: false
			});
			$("#wallet_amt").select();
			return false;
		}  
		$('.bank_details').hide();
		$('.paypal_details').hide();
		$('.razorpay_details').hide();
		if(payment_type=="Direct"){
			$('.paypal_details').show();
			$('.bank_details').hide();
			$('.razorpay_details').hide();
		}else if(payment_type=="RazorPay"){
			$('.razorpay_details').show();
			$('.paypal_details').hide();
			$('.bank_details').hide();
		}else if(payment_type=="stripe"){
			$('.bank_details').show();
			$('.paypal_details').hide();
			$('.razorpay_details').hide();
		} 
		$('#withdraw_modal').modal('show');
		$('#stripe_amount').val(stripe_amt);   
		$('#payment_types').val(payment_type);   
	});

	$(document).ready(function(){
		$('#bank_details').on('submit',function(e){
			e.preventDefault();
			var payment_type =$( 'input[name="group2"]:checked' ).val();	  
			if(payment_type=="Direct"){
				var paypal_id=$('#paypal_id').val();
				var paypal_email_id=$('#paypal_email_id').val();
				if(paypal_id==""){
					$('.paypal_id_error').text(paypal_account).css('color','red');
				}
				if(paypal_email_id==""){
					$('.paypal_email_id_error').text(paypal_email).css('color','red');
				}
				if(paypal_id!=''&&paypal_email_id!=''){
					bank_details();
				}
			}else if(payment_type=="RazorPay"){
				razorpay_details();
			}else{
				var account_no=$('#account_no').val();
				if(account_no==""){
					$('.account_no_error').text(account_no_error).css('color','red');
				}
				if(account_no!=''){
					bank_details();
				}
			}

		});
	});
	
	function bank_details(){
		$.ajax({
			type:'POST',
			url: base_url+'user/wallet/bank_details',
			data :  $('#bank_details').serialize(),
			dataType:'json',
			success:function(response) {
				if(response.status){
					swal({
						title:success,
						text: response.msg,
						icon: "success",
						button: "okay",
						closeOnEsc: false,
						closeOnClickOutside: false
					}).then(function(){
						location.reload();
					});
				}else{
					swal({
						title: warning,
						text: response.msg,
						icon: "error",
						button: "okay",
						closeOnEsc: false,
						closeOnClickOutside: false
					}).then(function(){
						location.reload();
					});
				}
			}
		});
	}
	
	function razorpay_details(){
		$.ajax({
			type:'POST',
			url: base_url+'user/wallet/razorpay_details',
			data :  $('#bank_details').serialize(),
			dataType:'json',
			success:function(response) {
				if(response.status){
					swal({
						title:success,
						text: response.msg,
						icon: "success",
						button: "okay",
						closeOnEsc: false,
						closeOnClickOutside: false
					}).then(function(){
						location.reload();
					});
				}else{
					swal({
						title: warning,
						text: response.msg,
						icon: "error",
						button: "okay",
						closeOnEsc: false,
						closeOnClickOutside: false
					}).then(function(){
						location.reload();
					});
				}
			}
		});
	}
})(jQuery);