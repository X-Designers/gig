(function ($) {
	"use strict";
	
	$('.home-fde-carousel').slick({
		dots: false,
		arrows: false,
		infinite: true,
		autoplay: true,
		rtl: true,
		autoplaySpeed: 3000,
		fade: true,
		cssEase: 'linear'
	});

	$(".discription-img").slick({
		dots: false,
		autoplay: false,
		rtl: true,
		autoplaySpeed: 2000,
		infinite: false
	});
})(jQuery);
