(function ($) {
    "use strict";	
	var uri = $('#uri').val();
	var modules = $('#modules').val();
	$('.change_language').on('click', function () {
		change_language(this);
	});
	$('.refresh_form_sale').on('click', function () {
		window.location.href=base_url+'sales';
	});
	$('.refresh_form_purchase').on('click', function () {
		window.location.href=base_url+'purchases';
	});
	$('.refresh_form_payment').on('click', function () {
		window.location.href=base_url+'payments';
	});
	$('.user_currency').on('change', function () {
		user_currency(this.value);
	});  
	$('.paycancel').on('change', function () {
		paycancel();
	}); 
	$('.fbLogin').on('click', function () {
		fbLogin();
	}); 
	$('.IsAlphaNumeric').on('keypress', function () {
		IsAlphaNumeric(this);
	});
	$(document).on('click', '#openNav', function () {
		$("#mySidenav").css({ "width": "250px" });
	});
	$(document).on('click', '#closeNav', function () {
		$("#mySidenav").css({ "width": "0px" });
	}); 
	$(document).on('click', 'show_usermessage', function () {
		var id=$(this).attr('data-id');
		var user=$(this).attr('data-user');
		show_usermessage(id,user);
	});
    //Document ready start
    $(document).on('ready', function () {
		$('.numberonly').keypress(function (event) {
			return isNumber(event, this)
		});
        //Stlesheet Selector
        $('link').each(function () {
            if ($(this).attr('href') == base_url + 'assets/css/style-rtl.css') {
                $('body').addClass('rtladded');
            }
        });
        var stickyNavTop = $('.top-header-gigs').offset().top;
        var stickyNav = function () {
            var scrollTop = $(window).scrollTop();
            if (scrollTop > stickyNavTop) {
                $('.top-header-gigs').addClass('sticky');
            } else {
                $('.top-header-gigs').removeClass('sticky');
            }
        };
        stickyNav();
        $(window).scroll(function () {
            stickyNav();
        });
        $('#contact_us_submit').on('click', function () {
            var c_name = $('#contact_name').val();
            var c_email = $('#contact_email').val();
            var c_message = $('#contact_message').val();
            if (c_name == '') {
                $('#c_name').css('display', '');
            } else if (c_email == '') {
                $('#c_name').css('display', 'none');
                $('#c_email').css('display', '');
            } else if (c_message == '') {
                $('#c_name').css('display', 'none');
                $('#c_email').css('display', 'none');
                $('#c_phone').css('display', 'none');
                $('#c_message').css('display', '');
            } else {
                $('#c_name').css('display', 'none');
                $('#c_email').css('display', 'none');
                $('#c_phone').css('display', 'none');
                $('#c_message').css('display', 'none');
                $.ajax({
                    type: "POST",
                    url: base_url + "gigs/contactus_send_mail/",
                    data: $('#contact_us_form').serialize(),
                    success: function (result) {
                        $('#contact_us_form')[0].reset();
                        $('#success_contact').css('display', '');
                        setTimeout(function () {
                            $('#success_contact').css('display', 'none');
                        }, 3500);
                    }
                });
            }
            return false;
        });
        var tz = jstz.determine();
        var timezone = tz.name();
        var ip_city = '';
        $.post(base_url + 'ajax', { timezone: timezone, ip_city: ip_city }, function (res) {})
        setTimeout(function () { $('.alert-dismissable').hide(); }, 2000);
    }); //Document ready end
	
    function change_language(e) {
        var lg = $(e).attr('lang');
        var tag = $(e).attr('lang_tag');
        var lang_value = $(e).attr('lang_value');
        $.post(base_url + 'ajax/change_language',
        {
            lg: lg,
            tag: tag,
            lang_value: lang_value
        },
        function (res) {
            location.reload();
        })
    }
	
    function change_language_new(e) {
        var lg = $(e).attr('lang');
        $.post(base_url + 'ajax/change_language', { lg: lg }, function (res) {
            location.reload();
        });
    }

    function user_currency(code) {
        if (code != "") {
            $.ajax({
                type: 'POST',
                url: base_url + 'ajax/add_user_currency',
                data: { code: code },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        location.reload();
                    }
                    else {
                        location.reload();
                    }
                }
            });
        }
    }
	
    function isNumber(evt, element) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (
            (charCode != 45 || $(element).val().indexOf('-') != -1) &&      
            (charCode != 46 || $(element).val().indexOf('.') != -1) &&      
            (charCode < 48 || charCode > 57))
            return false;
        return true;
    }
	
    $('.home-fde-carousel').slick({
        dots: false,
        arrows: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 3000,
        fade: true,
        cssEase: 'linear'
    });

    $(".discription-img").slick({
        dots: false,
        autoplay: false,
        autoplaySpeed: 2000,
        infinite: false
    });
    
    $(document).on('ready', function () {
        //Stlesheet Selector
        $('link').each(function () {
            if ($(this).attr('href') == base_url + 'assets/css/style-rtl.css') {
                $('body').addClass('rtladded');
            }
        });
        var stickyNavTop = $('.top-header-gigs').offset().top;
        var stickyNav = function () {
            var scrollTop = $(window).scrollTop();

            if (scrollTop > stickyNavTop) {
                $('.top-header-gigs').addClass('sticky');
            } else {
                $('.top-header-gigs').removeClass('sticky');
            }
        };
        stickyNav();
        $(window).scroll(function () {
            stickyNav();
        });
    });

    // Skin Settings  
    // Template Options
    $(document).on('click', '.skin-sett-icon', function () {
        $('.skin-settings').toggleClass("active");
    });

    // Template Options html append
    if ($('#demoSettings').length === 0) {
        var adminColorSetting = $('#adminColorSetting').val();
		var canChange = adminColorSetting == 0 ? 'style="display:none"' : 'style="display:block"';
        $('.footer-section').append('<div class="skin-settings" id="demoSettings" '+ canChange +' >' +
            '<div class="skin-sett-icon"><i class="fa fa-cog"></i></div>' +
            '<div class="skin-sett-body">' +
            '<h4>Theme Colors</h4>' +
            '<ul class="skin-colors">' +
            '<li><a class="skin-pink" data-color="default" href="#"></a></li>' +
            '<li><a class="skin-blue" data-color="blue" href="#"></a></li>' +
            '<li><a class="skin-green" data-color="green" href="#"></a></li>' +
            '<li><a class="skin-orange" data-color="orange" href="#"></a></li>' +
            '<li><a class="skin-red" data-color="red" href="#"></a></li>' +
            '</ul>' +
            '</div>' +
            '</div>')
    }
    const hasTemp = localStorage.getItem('skin-color');
    if (!!hasTemp) {
        $('body').find('.skin-colors a').each(function () {
            const name = $(this).attr('data-color');
            if (name === hasTemp) {
                $(this).addClass('active');
            } else {
                $(this).removeClass('active');
            }
        })
    } else {
        $('body').find('.skin-colors a').each(function () {
            const name = $(this).attr('data-color');

            if (name === 'default') {
                $(this).addClass('active');
            }
        });
    }

    // Skin colors change event
    $(document).on('click', '.skin-colors a', function (e) {
        e.preventDefault();
        $(this).parent().siblings().find('a').removeClass('active');
        $(this).addClass('active');
        var skin = $(this).attr('data-color');
        if (skin === 'default') {
            localStorage.removeItem('skin-color');
            $('#tempSkin').remove();
        } else {                        
            localStorage.setItem('skin-color', skin);
        }
        updateTheme(skin);
    })

    if (uri == 'sell-service') {
        $('.summernote').summernote({
            tabsize: 2,
            height: 100
        });
    }
    if (uri == "edit-gig") {
        $('.summernote').summernote({
            tabsize: 2,
            height: 100
        });
    }
    if (modules == 'sales' || modules == 'purchases' || modules == 'payments') {
        $('#J-demo-02').dateTimePicker();
        $('#J-demo-01').dateTimePicker();
    }
    if (modules == "gig_preview") {
        $("#payment_formid").on('submit', function (e) {
          var wallet_amts=$('#wallet_amt').val();
          var gigs_amount = parseFloat($('#gigs_rate').val());
          var wallet_amt = parseFloat(wallet_amts);          
          if (gigs_amount > wallet_amt) {
            swal({
                title: wallet,
                text: wallet_amt_available,
                icon: "success",
                button: "okay",
                closeOnEsc: false,
                closeOnClickOutside: false
            }).then(function () {
                window.location = base_url + "wallet";
            });
            return false;
        }
        return true;
    });
    }
    if (modules == "sell_service" || modules == "edit_gig") {
        $(document).ready(function () {
            $("#upload_image_btn").on('click',function() {
                $("#avatar-gig-modal").css('display', 'block');
                $("#avatar-gig-modal").modal('show');
            });
        });
    }
    var $star_rating = $('.star-rating .fa');
    var SetRatingStar = function () {
        return $star_rating.each(function () {
            if (parseInt($star_rating.siblings('input.rating-value').val()) >= parseInt($(this).data('rating'))) {
                return $(this).removeClass('fa-star-o').addClass('fa-star');
            } else {
                return $(this).removeClass('fa-star').addClass('fa-star-o');
            }
        });
    };
    $star_rating.on('click', function () {
        $star_rating.siblings('input.rating-value').val($(this).data('rating'));
        return SetRatingStar();
    });
    SetRatingStar();
    //fb ------------
    window.fbAsyncInit = function () {
        // FB JavaScript SDK configuration and setup
        FB.init({
            appId: '2911852635603641', // FB App ID
            cookie: true,  // enable cookies to allow the server to access the session
            xfbml: true,  // parse social plugins on this page
            version: 'v2.8' // use graph api version 2.8
        });
    };

    // Load the JavaScript SDK asynchronously
    (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

    // Facebook login with JavaScript SDK
    function fbLogin() {
        FB.login(function (response) {
            if (response.authResponse) {
                // Get and display the user profile data
                getFbUserData();
            } else {
                $('#register_errtext').html('User canceled login or did not fully authorize');
            }
        }, { scope: 'email' });
    }

    // Fetch the user profile data from facebook
    function getFbUserData() {
        FB.api('/me', { locale: 'en_US', fields: 'id,name,first_name,last_name,email,link,gender,locale,picture' },
            function (response) {
                var profileid = response.id;
                var fullname = response.name;
                var firstname = response.first_name;
                var lastname = response.last_name;
                var profileurl = response.picture.data.url;
                var email = response.email;
                var auth = 'Facebook';
                var selected_menu = $('#selected_menu').val();
                $.post(base_url + 'user/dashboard/sociallogin_registration', { 'profileid': profileid, 'fullname': fullname, 'profileurl': profileurl, 'email': email, 'auth': auth, 'firstname': firstname }, function (response) {
                    if (response == 1) {
                        if (selected_menu != '') {
                            window.location.href = base_url + selected_menu;
                        } else {
                            location.reload();
                        }
                    } if (response == 0) {
                        $('#register_errtext').html('<div class="account-error">Login failed wrong user credentials</div>');
                        $('#users_login').bootstrapValidator('resetForm', true);
                    }
                });
            });
    }

    function show_usermessage(id, frmuser) {
        window.location = base_url + 'message/' + frmuser;
    }
	
    $('#stars').on('starrr:change', function (e, value) {
        $('#count').html(value);
    });

    $('#stars-existing').on('starrr:change', function (e, value) {
        $('#count-existing').html(value);
        $('#rating_input').val(value);
    });
    if (modules == "my_dashboard") {
        $(document).ready(function () {
            var jsonData2 = $.getJSON(base_url + 'user/my_dashboard/my_gigs_amount', function (jsonData2) {
                new Morris.Line({
                    // ID of the element in which to draw the chart.
                    element: "line-chart",
                    // Chart data records -- each entry in this array corresponds to a point on
                    // the chart.
                    data: jsonData2,
                    // The name of the data record attribute that contains x-values.
                    xkey: 'month',
                    // A list of names of data record attributes that contain y-values.
                    ykeys: ['amount'],
                    // Labels for the ykeys -- will be displayed when you hover over the
                    // chart.
                    labels: ['Amount'],
                    lineColors: ['#444455'],
                    pointFillColors: ['#FF4877'],
                    smooth: false,
                    parseTime: false,
                    resize: true
                });
            });
            var jsonData1 = $.getJSON(base_url + 'user/my_dashboard/my_gigs_status', function (jsonData1) {
                Morris.Donut({
                    element: 'donut-chart',
                    data: jsonData1,
                    resize: true,
                    colors: ['#FF4877', 'rgb(0, 13, 51)', 'rgb(68, 68, 85)']

                });
            });
            var barColorsArray = ['#FF4877', '#444455', '#FF4877'];
            var colorIndex = 0;
            var jsonData = $.getJSON(base_url + 'user/my_dashboard/gigs_sales', function (jsonData) {
                Morris.Bar({
                    element: 'bar-chart',
                    data: jsonData,
                    xkey: 'month',
                    ykeys: ['sales'],
                    labels: ['Gigs Sales'],
                    barRatio: 0.4,
                    barColors: function () {
                        if (colorIndex < 2)
                            return barColorsArray[++colorIndex];
                        else {
                            colorIndex = 0;
                            return barColorsArray[++colorIndex];
                        }
                    },
                    xLabelAngle: 35,
                    hideHover: 'auto',
                    resize: true
                });
            });
        });
    }
    if (modules == "wallet" && uri=="wallet") {
        var publishable_key = $('#publishable_key').val();
        var logo_value = $('#logo_value').val();
        if (logo_value == '' || logo_value == undefined) {
            logo_value = base_url + "assets/img/logo.png";
        }
        $('.add_wallet_value').on('click', function () {
            var id = $(this).attr('data-amount');
            $("#wallet_amt").val(id);
        });
        var handler = StripeCheckout.configure({
            key: publishable_key,
            image: logo_value,
            locale: 'auto',
            token: function (token, args) {                
                // You can access the token ID with `token.id`.
                var tokenid = token.id;
                $('#access_token').val(token.id);
                var stripe_amt = $("#wallet_amt").val();
                $.ajax({
                    url: base_url + 'user/stripe_payment/add_user_wallet',
                    data: { amount: stripe_amt, tokenid: tokenid },
                    type: 'POST',
                    dataType: 'JSON',
                    beforeSend: function () {
                        button_loading();
                    },
                    success: function (response) {
                        button_unloading();
                        swal({
                            title: success,
                            text: amount_add_wallet,
                            icon: "success",
                            button: "okay",
                            closeOnEsc: false,
                            closeOnClickOutside: false
                        }).then(function () {
                            location.reload();
                        });

                    },
                    error: function (error) {
                        console.log(error);
                    }
                });
            }
        });
        $('#stripe_wallet').on('click', function (e) {
            var stripe_amt = $("#wallet_amt").val();
            var payment_type = $('input[name="group2"]:checked').val();		
			if (payment_type == "RazorPay" && payment_type != undefined) {
				var totalAmount = $('#wallet_amt').val();
				var product_id =  '123';
				var product_name =  'Wallet Topup';				
				var options = {
					"key": $('#razorpay_apikey').val(),
					"currency": "INR",
					"amount": totalAmount*100,
					"name": product_name,
					"description": product_name,
					"handler": function (response){
						  $.ajax({
							url: base_url+'user/wallet/razor_payment_success',
							type: 'post',
							dataType: 'json',
							data: {
								razorpay_payment_id: response.razorpay_payment_id , totalAmount : totalAmount ,product_id : product_id,
							}, 
							success: function (msg) {	
							   window.location.href = base_url+'user/wallet/razorthankyou?res='+msg;
							}
						});
					},
					"theme": {
						"color": "#F37254"
					}
				}
				var rzp1 = new Razorpay(options);
				rzp1.open();
				e.preventDefault();
				return false;
			}
            if (payment_type == "PayTabs" && payment_type != undefined) {
                if (stripe_amt < 20) {
                    swal({
                        title: min_amount,
                        text: add_min_amount + " 21",
                        icon: "error",
                        button: "okay",
                        closeOnEsc: false,
                        closeOnClickOutside: false
                    });
                    return false;
                }
            }
            if (payment_type == undefined || payment_type == '') {
                swal({
                    title: payments,
                    text: payment_method,
                    icon: "error",
                    button: "okay",
                    closeOnEsc: false,
                    closeOnClickOutside: false
                });
                $("#wallet_amt").select();
                return false;
            }
            if (stripe_amt == '' || stripe_amt < 1) {
                swal({
                    title: empty_amount,
                    text: wallet_field,
                    icon: "error",
                    button: "okay",
                    closeOnEsc: false,
                    closeOnClickOutside: false
                });
                $("#wallet_amt").select();
                return false;
            }
            if (payment_type == "stripe") {
                var final_gig_amount = (stripe_amt * 100); //  dollar to cent
                var striep_currency = $('#user_currency_code').val();
                // Open Checkout with further options:
                handler.open({
                    name: base_url,
                    description: 'Wallet Recharge',
                    amount: final_gig_amount,
                    currency: striep_currency
                });
                e.preventDefault();
            } else {
                $('#paypal_payment').submit();
            }
        });

        function button_loading() {
            var $this = $('.btn');
            var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
            if ($this.html() !== loadingText) {
                $this.data('original-text', $this.html());
                $this.html(loadingText).prop('disabled', 'true').bind('click', false);
            }
        }
        function button_unloading() {
            var $this = $('.btn');
            $this.html($this.data('original-text')).prop('disabled', 'false');
        }
    }
    if (modules == "gig_preview") {
        $('#payment_formid').submit(function () {
            var option = $('input[name=group2]:checked').val();
            var gigs_rate = $('#gigs_rate').val();
            var converted_india_gigs_rate = $('#converted_india_gigs_rate').val();
            var gigs_actual_rate = $('#gigs_actual_rate').val();
            var gigs_id = $('#gigs_id').val();
            var gig_user_id = $('#gig_user_id').val();
            var extra_gig_row_id = $('#extra_gig_row_id').val();
            var currency_type = $('#currency_type').val();
            var hidden_super_fast_delivery = $('#hidden_super_fast_delivery').val();
            var total_delivery_days = $('#total_delivery_days').val();
            var hidden_super_fast_delivery_charges = $('#hidden_super_fast_delivery_charges').val();
            if (option == 'stripe') {
                $('#gigs_rates').val(gigs_rate);
                $('#converted_india_gigs_rates').val(converted_india_gigs_rate);
                $('#gigs_actual_rates').val(gigs_actual_rate);
                $('#gigs_ids').val(gigs_id);
                $('#gig_user_ids').val(gig_user_id);
                $('#extra_gig_row_ids').val(extra_gig_row_id);
                $('#currency_types').val(currency_type);
                $('#hidden_super_fast_deliverys').val(hidden_super_fast_delivery);
                $('#total_delivery_dayss').val(total_delivery_days);
                $('#hidden_super_fast_delivery_chargess').val(hidden_super_fast_delivery_charges);
                $('#stripe_amount').val(gigs_rate);
                $("#checkout-popup").modal('hide');
                $("#my_stripe_payyment").click();
                return false;
            }
        });
        $(document).on('click', '#cancelInlineBtn', function () {
            $("#checkout-popup").modal('show');
        });
        $(document).on('click', '#stripe_payment', function () {
            $('#locloader').show();
            setTimeout(function () {
                $('#locloader').hide();
            }, 1000);
        });

        function paycancel() {
            $("#checkout-popup").modal('show');
        }

        /* Stripe Payment End   */

        // Returns a random integer between min and max
        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }  
    } //Gig preview if condition end

    var specialKeys = new Array();
    specialKeys.push(8); //Backspace
    specialKeys.push(9); //Tab
    specialKeys.push(46); //Delete
    specialKeys.push(36); //Home
    specialKeys.push(35); //End
    specialKeys.push(37); //Left
    specialKeys.push(39); //Right
    function IsAlphaNumeric(e) {
        var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
        var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (specialKeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode));
        return ret;
    }
    if (modules == "subscriptions") {
        $(document).ready(function () {
            $('#subscriptionpayment_formid').submit(function () {
                var option = $('input[name=group2]:checked').val();
                var subscription_name = $('#subscription_name').val();
                var subscription_period = $('#subscription_period').val();
                var subscription_gigs = $('#subscription_gigs').val();
                var subscription_amount = $('#subscription_amount').val();
                var subscription_id = $('#subscription_id').val();
                if (option == 'stripe') {
                    $('#subscription_names').val(subscription_name);
                    $('#subscription_periods').val(subscription_period);
                    $('#subscription_gigss').val(subscription_gigs);
                    $('#subscription_amounts').val(subscription_amount);
                    $('#subscription_ids').val(subscription_id);
                    $("#checkout-popup").modal('hide');
                    $("#my_stripe_subscription_payyment").click();
                    return false;
                }
            });
        });

        function paycancel() {
            $("#checkout-popup").modal('show');
        }
        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
        var logo_value = $('#logo_value').val();
        var publishable_key = $('#publishable_key').val();
        if (logo_value == '' || logo_value == undefined) {
            logo_value = base_url + "assets/img/logo.png";
        }
        var handler = StripeCheckout.configure({
            key: publishable_key,
            image: logo_value,
            locale: 'auto',
            token: function (token, args) {
                // You can access the token ID with `token.id`.
                $('#access_token').val(token.id);
                $.ajax({
                    url: base_url + 'user/subscriptions/stripe_payment',
                    data: $('#subscription_payment-form').serialize(),
                    type: 'POST',
                    dataType: 'JSON',
                    success: function (response) {
                        if (response.status == 'Success') {
                            window.location.href = base_url + 'sell-service';
                        }
                        else {
                            window.location.href = base_url + 'gigs';
                        }
                    },
                    error: function (error) {
                        console.log(error);
                    }
                });
            }
        });
        $('#my_stripe_subscription_payyment').on('click',function(e) {
            var final_subscription_amount = $('#subscription_amounts').val();
            final_subscription_amount = (final_subscription_amount * 100); //  dollar to cent 
            var cur = $('#currency_types').val();
            striep_currency = 'USD';
            if (cur == '$') { striep_currency = 'USD'; }
            if (cur == '€') { striep_currency = 'EUR'; }
            if (cur == '£') { striep_currency = 'GBP'; }
            // Open Checkout with further options:
            handler.open({
                name: base_url,
                description: 'My Gigs Subscription',
                amount: final_subscription_amount,
                currency: striep_currency
            });
            final_subscription_amount = (final_subscription_amount / 100); // cent to dollar 
            e.preventDefault();
        });
        // Close Checkout on page navigation:
        window.addEventListener('popstate', function () {
            handler.close();
        });
    }//Subscription if end
    $('.switch').on('click', function (e) {
        $('.main-menu .navbar-static-top').toggleClass("hide-icons"); //you can list several class names 
        e.preventDefault();
    }); 
	//social login
    //google login
    var googleUser = {};
    var auth2 = '';
    var startApp = function () {
        var website_google_client_ids = $('#website_google_client_ids').val();
        gapi.load('auth2', function () {
            // Retrieve the singleton for the GoogleAuth library and set up the client.
            auth2 = gapi.auth2.init({
                client_id: website_google_client_ids,
                cookiepolicy: 'single_host_origin',
                // Request scopes in addition to 'profile' and 'email'
            });
            attachSignin(document.getElementById('customBtn'));
        });
    };

    function attachSignin(element) {
        auth2.attachClickHandler(element, {},
            function (googleUser) {              
                var profileid = googleUser.getBasicProfile().getId();
                var fullname = googleUser.getBasicProfile().getName();
                var firstname = googleUser.getBasicProfile().getGivenName();
                var profileurl = googleUser.getBasicProfile().getImageUrl();
                var email = googleUser.getBasicProfile().getEmail();
                var auth = 'Google';
                var selected_menu = $('#selected_menu').val();                
                $.post(base_url + 'user/dashboard/sociallogin_registration', { 'profileid': profileid, 'fullname': fullname, 'profileurl': profileurl, 'email': email, 'auth': auth, 'firstname': firstname }, function (response) {
                    if (response == 1) {                        
                        if (selected_menu != '') {
                            window.location.href = base_url + selected_menu;
                        } else {
                            location.reload();
                        }
                    } if (response == 0) {
                        $('#register_errtext').html('<div class="account-error">Login failed wrong user credentials</div>');
                        $('#users_login').bootstrapValidator('resetForm', true);
                    }
                });
            }, function (error) {});
    }
    function updateTheme(theme) {		
		$.ajax({
			type: 'POST',
			url: base_url + 'ajax/updatetheme',
			data: { theme: theme },
			success: function (response) {
				if(response){
					location.reload();
				}
			}
		});
	}
    startApp();
})(jQuery);