(function ($) {
	"use strict";
	var BASE_URL = $('#base_url').val();
	var modules = $('#module').val();
	var page = $('#page').val();
	var page_id = $('#page_id').val();

	var priceoptions=$('#priceoption').val();
	if(priceoptions=="fixed"){
		$('.fixed_price').show();
	}else{
		$('.fixed_price').hide();
	}
	setTimeout(function () { $('#flash_succ_message, #flash_error_message').hide(); }, 5000);
	var resizefunc = [];
	$('.colorpicker-component').colorpicker();
	$(".switch").bootstrapSwitch();

	$('#subitmorefield').on('click', function () {
		subitmorefield();
	});
	$('#priceoption').on('change', function () {
		priceoption(this);
	});   
	$('.paycancel').on('click', function () {
		paycancel();
	}); 
	$('.submit_stripe').on('click', function () {
		submit_stripe();
	}); 
	$('.check_sub_rate').on('keyup', function () {
		check_sub_rate();
	}); 
	$('.check_sub_rate').on('blur', function () {
		check_sub_rate();
	});

	$('.default_lang').on('click', function () {
		var updateid = $(this).attr('data-id');
		//alert(updateid);
		update_language_default(updateid);
	});	

	$('.update_wallet').on('click', function () {
		var id = $(this).attr('data-id');
		var user_id = $(this).attr('data-user_id');
		var request = $(this).attr('data-request');
		update_wallet(id, user_id, request);
	});


	$(document).ready(function () {
		var tz = jstz.determine();
		var timezone = tz.name();
		$.post(BASE_URL+'ajax', { timezone: timezone }, function (res) {
		})
		$('.numberonly').keypress(function (event) {
			return isNumber(event, this)
		});
	});

  $('#withdraw_form').bootstrapValidator({
    message: 'This value is not valid',
    feedbackIcons: {
      valid: 'glyphicon glyphicon-ok',
      invalid: 'glyphicon glyphicon-remove',
      validating: 'glyphicon glyphicon-refresh'
    },
    fields: {
      transaction_id: {
        message: 'The Transaction ID is not valid',
        validators: {
          notEmpty: {
            message: 'The Transaction ID is required and cannot be empty'
          }

        }
      },
      transaction_date: {
        message: 'The Transaction Date is not valid',
        validators: {
          notEmpty: {
            message: 'The Transaction Date is required and cannot be empty'
          }

        }
      },

      transaction_status: {
        message: 'The Transaction Status is not valid',
        validators: {
          notEmpty: {
            message: 'The Transaction Status is required and cannot be empty'
          }

        }
      },
      description: {
        validators: {
          notEmpty: {
            message: 'The Description is required and cannot be empty'
          }
        }
      }
    }
  });

	function subitmorefield() {
		var labe = $("#field-1").val();
		var fname = $("#field-2").val();
		var html = '';
		var html = '<div class="form-group">';
		html = html + ' <label class="col-sm-3 control-label">' + labe + '</label>';
		html = html + ' <div class="col-sm-9">';
		html = html + '<input type="text" class="form-control"  name="' + fname + '" placeholder="Type here.." value=""';
		html = html + '</div>';
		html = html + '</div>';
		$('.hrs_detail_addmore').append(html);
		$('#con-close-modal').modal('hide');
	}

	function subitmorefields() {
		var labe = $("#field-1").val();
		var fname = $("#field-2").val();
		var html = '';
		var html = '<div class="form-group">';
		html = html + ' <label class="col-sm-3 control-label">' + labe + '</label>';
		html = html + ' <div class="col-sm-9">';
		html = html + '<input type="text" class="form-control"  name="' + fname + '" placeholder="Type here.." value=""';
		html = html + '</div>';
		html = html + '</div>';
		$('.hrs_detail_addmore').append(html);
		$('#con-close-modal').modal('hide');
	}

	function fnc(value, min, max) {
		if (parseInt(value) < 0 || isNaN(value))
			return 0;
		else if (parseInt(value) > 50)
			return 1;
		else return value;
	}
	
	function isNumber(evt, element) {
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (
		  (charCode != 45 || $(element).val().indexOf('-') != -1) &&      
		  (charCode != 46 || $(element).val().indexOf('.') != -1) &&     
		  (charCode < 48 || charCode > 57))
		  return false;
		return true;
	}

	function priceoption(e) {
		var option = $(e).val();
		if (option == 'fixed') {
			$('.fixed_price').show();
			$('#base_gig_price').attr('required', 'required');
			$('#base_extra_gig_price').attr('required', 'required');
		} else if (option == 'dynamic') {
			$('.fixed_price').hide();
			$('#base_gig_price').removeAttr('required');
			$('#base_extra_gig_price').removeAttr('required');
		}
	}
	
	$(document).ready(function () {
		if ($('.content-page').length > 0) {
			var height = $(window).height();
			$(".content-page").css("min-height", height);
		}
	});

	
	$(window).resize(function () {
		if ($('.content-page').length > 0) {
			var height = $(window).height();
			$(".content-page").css("min-height", height);
		}
	});
	$(document).ready(function () {
		if ($('.datatable').length > 0) {
			$('.datatable').DataTable({
				"bPaginate": false,
			});
		}
	});
	$(document).ready(function () {
		var totalRows = $(".releasetable > tbody > tr").length;
		var admin_releasetable = $(".admin_releasetable > tbody > tr").length;

		if ($('.releasetable').length > 0) {
			if(totalRows>5){
				$('.releasetable').DataTable(); 
			}
		} 
		if ($('.admin_releasetable').length > 0) {
			if(admin_releasetable>5){
				$('.admin_releasetable').DataTable({
					order: [[1, "asc"]]
				});
			}
		}
	});

	function update_wallet(id, user_id, request_payment) {
		var request_payment = request_payment;
		if (id != '') {
			$('#wallet_modal').modal('show');
			$('#transaction_id').val(id);
			$.ajax({
				type: 'POST',
				url: BASE_URL + 'admin/wallet_payments/get_bank_details',
				data: { id: user_id },
				dataType: 'json',
				success: function (response) {
					if (response != '') {
						$('#paypal_id').val(response.paypal_account);
						$('#paypal_email').val(response.paypal_email_id);
						$('#bank_name').val(response.bank_name);
						$('#ac_no').val(response.account_number);
						$('#ifsc_code').val(response.account_ifsc);
						$('#pancard_no').val(response.pancard_no);
						$('#routing_no').val(response.routing_number);
						$('#sort_code').val(response.sort_code);
						if (request_payment == "stripe") {
							$('.paypal_details').hide();
							$('.stripe_details').show();
						} else {
							$('.paypal_details').show();
							$('.stripe_details').hide();
						}
					}
				}
			});
		}
	}
	
	$(function () {
		setTimeout(function () {
		$('.alert').hide();
		}, 3000);
		$('.datepicker').on('change', function (e) {
			$('#withdraw_form').bootstrapValidator('revalidateField', 'transaction_date');
		});

		$('.paypal_details').hide();
		$('.stripe_details').hide();
		$("#datepicker").datepicker({
			dateFormat: 'dd-mm-yy',
			changeMonth: true,
			changeYear: true
		});
	});
  
	!function ($) {
		"use strict";
		var Sidemenu = function () {
			this.$menuItem = $("#sidebar-menu a")
		};
		
		// Sidebar Menu
		Sidemenu.prototype.menuItemClick = function (e) {
			if ($(this).parent().hasClass("has_sub")) {
				e.preventDefault();
			}
			if (!$(this).hasClass("subdrop")) {
				// close open menu
				$("ul", $(this).parents("ul:first")).slideUp(350);
				$("a", $(this).parents("ul:first")).removeClass("subdrop");
				$("#sidebar-menu .pull-right i").removeClass("md-remove").addClass("md-add");
				// open new menu
				$(this).next("ul").slideDown(350);
				$(this).addClass("subdrop");
				$(".pull-right i", $(this).parents(".has_sub:last")).removeClass("md-add").addClass("md-remove");
				$(".pull-right i", $(this).siblings("ul")).removeClass("md-remove").addClass("md-add");
			} else if ($(this).hasClass("subdrop")) {
				$(this).removeClass("subdrop");
				$(this).next("ul").slideUp(350);
				$(".pull-right i", $(this).parent()).removeClass("md-remove").addClass("md-add");
			}
		},
		Sidemenu.prototype.init = function () {
			var $this = this;
			$this.$menuItem.on('click', $this.menuItemClick);
			$("#sidebar-menu ul li.has_sub a.active").parents("li:last").children("a:first").addClass("active").trigger("click");
		},
		$.Sidemenu = new Sidemenu, $.Sidemenu.Constructor = Sidemenu
	}(window.jQuery),

	function ($) {
		"use strict";
		var App = function () {
			this.$body = $("body")
		};
		App.prototype.init = function () {
			var $this = this;
			$(document).ready($this.onDocReady);
			$.Sidemenu.init();
		},
		$.App = new App, $.App.Constructor = App
	}(window.jQuery),

	function ($) {
		"use strict";
		$.App.init();
	}(window.jQuery);

	$(document).ready(function () {
		if ($('.slimscrollleft').length > 0) {
			$('.slimscrollleft').slimScroll({
				height: 'auto',
				width: '100%',
				position: 'right',
				size: "5px",
				color: '#dcdcdc',
				touchScrollStep: 50,
				wheelStep: 5
			});
			var h = $(window).height() - 60;
			$('.slimscrollleft').height(h);
			$('.sidebar .slimScrollDiv').height(h);

			$(window).resize(function () {
				var h = $(window).height() - 60;
				$('.slimscrollleft').height(h);
				$('.sidebar .slimScrollDiv').height(h);
			});
		}
	});

	$('#site_logo').change(function () {
		var url = $(this).val();
		var ext = url.substring(url.lastIndexOf('.') + 1).toLowerCase();
		if ((ext == "gif" || ext == "png" || ext == "jpeg" || ext == "jpg" || ext == "ico")) {
			$('#img_upload_error').css('display', 'none');
		}
		else {
			$('#img_upload_error').css('display', 'block');
			$('#site_logo').val('');
		}
	});
	
	$('#favicon').change(function () {
		var url = $(this).val();
		var ext = url.substring(url.lastIndexOf('.') + 1).toLowerCase();
		if ((ext == "gif" || ext == "png" || ext == "jpeg" || ext == "jpg" || ext == "ico")) {
			$('#img_upload_errors').css('display', 'none');
		}
		else {
			$('#img_upload_errors').css('display', 'block');
			$('#favicon').val('');
		}
	});
  
	$(document).on('click', '#mobile_btn', function (e) {
		$("#wrapper").removeClass('close-menu').toggleClass('slide-nav-toggle');
		$("body").removeClass('').toggleClass('menu-open');
		return false;
	});
	
	$(document).on('click', '#close_menu', function () {
		$('#wrapper').toggleClass('close-menu').removeClass('slide-nav-toggle');
		$("body").removeClass('menu-open').toggleClass('');
		return false;
	});

	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	specialKeys.push(9); //Tab
	specialKeys.push(46); //Delete
	specialKeys.push(36); //Home
	specialKeys.push(35); //End
	specialKeys.push(37); //Left
	specialKeys.push(39); //Right
	
	function IsAlphaNumeric(e) {
		var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
		var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (specialKeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode));
		return ret;
	}

	$(document).ready(function () {
		$('.switch_subscription').on('switchChange.bootstrapSwitch', function (e, data) {
			var status = '';
			var sts_str = '';
			var id = $(this).attr('id');
			if ($(this).is(':checked')) {
				status = '1';
				sts_str = 'Active';
			} else {
				status = '0';
				sts_str = 'InActive';
			}
			if (status != '') {
				$.ajax({
					type: 'POST',
					url: BASE_URL + 'admin/subscription/update_subscription_status',
					data: { id: id, status: status },
					success: function (response) {
						$('#change_staus_' + id).html(sts_str);
					}
				});
			}
		})
	});

	if (modules == 'settings' || modules == 'language') {
	}
	else {
		$(document).ready(function () {
			$('input[type=text], input[type=number], textarea').keyup(function () {
				var yourInput = $(this).val();
				var re = /[`~!#%^&*()|+\=?;"<>\{\}\[\]\\\\]/gi;
				var isSplChar = re.test(yourInput);
				if (isSplChar) {
					var no_spl_char = yourInput.replace(/[`~!#%^&*()|+\=?;"<>\{\}\[\]\\\\]/gi, '');
					$(this).val(no_spl_char);
				}
			});

			$('input[type=text], input[type=number], textarea').blur(function () {
				var yourInput = $(this).val();
				var re = /[`~!#%^&*()|+\=?;"<>\{\}\[\]\\\\]/gi;
				var isSplChar = re.test(yourInput);
				if (isSplChar) {
					var no_spl_char = yourInput.replace(/[`~!#%^&*()|+\=?;"<>\{\}\[\]\\\\]/gi, '');
					$(this).val(no_spl_char);
				}
			});
		});
	}

	if (modules == "category") {
		$(document).ready(function () {

			$("#multi_deletes_form").submit(function (event) {
				var multi_Delete = $('#multi_Delete').val();
				if (multi_Delete == '') {
					alert('Please choose anyone category');
				return false;
				}
				else {
					$("#multi_deletes_form").submit();
				}
			});

			$("#ckbCheckAll").on('click',function() {
				$(".checkBoxClass").prop('checked', $(this).prop('checked'));
				var checkboxValues = [];
				$('.checkBoxClass:checked').each(function (index, elem) {
					checkboxValues.push($(elem).val());
				});
				$('#multi_Delete').val(checkboxValues.join(','));
			});
			
			$(".releasetable").on('change', "input[type='checkbox']", function (e) {
				if (!$(this).prop("checked")) {
					$("#ckbCheckAll").prop("checked", false);
				}
				var checkboxValues = [];
				$('.checkBoxClass:checked').each(function (index, elem) {
					checkboxValues.push($(elem).val());
				});
				$('#multi_Delete').val(checkboxValues.join(','));
			});
		});
	}

	if (modules == 'profession') {
		$(document).ready(function () {

			$("#multi_deletes_form").submit(function (event) {
				var multi_Delete = $('#multi_Delete').val();
				if (multi_Delete == '') {
					alert('Please choose anyone profession');
					return false;
				}
				else {
					$("#multi_deletes_form").submit();
				}
			});

			$("#ckbCheckAll").on('click',function() {
				$(".checkBoxClass").prop('checked', $(this).prop('checked'));
				var checkboxValues = [];
				$('.checkBoxClass:checked').each(function (index, elem) {
					checkboxValues.push($(elem).val());
				});
				$('#multi_Delete').val(checkboxValues.join(','));
			});

			$(".checkBoxClass").change(function () {
				if (!$(this).prop("checked")) {
					$("#ckbCheckAll").prop("checked", false);
				}
				var checkboxValues = [];
				$('.checkBoxClass:checked').each(function (index, elem) {
					checkboxValues.push($(elem).val());
				});
				$('#multi_Delete').val(checkboxValues.join(','));
			});
		});
	}

	if (modules == 'terms') {
		$(document).ready(function () {

			$("#multi_deletes_form").submit(function (event) {
				var multi_Delete = $('#multi_Delete').val();
				if (multi_Delete == '') {
					alert('Please choose anyone term');
					return false;
				}
				else {
					$("#multi_deletes_form").submit();
				}
			});

			$("#ckbCheckAll").on('click',function() {
				$(".checkBoxClass").prop('checked', $(this).prop('checked'));
				var checkboxValues = [];
				$('.checkBoxClass:checked').each(function (index, elem) {
					checkboxValues.push($(elem).val());
				});
				$('#multi_Delete').val(checkboxValues.join(','));
			});

			$(".checkBoxClass").change(function () {
				if (!$(this).prop("checked")) {
					$("#ckbCheckAll").prop("checked", false);
				}
				var checkboxValues = [];
				$('.checkBoxClass:checked').each(function (index, elem) {
					checkboxValues.push($(elem).val());
				});
				$('#multi_Delete').val(checkboxValues.join(','));
			});
		});
	}

	if (page == "language_keywords") {
		$(document).ready(function () {
			var language_list = $('#language_list').val();
			var page_id = $('#page_id').val();
			language_table = $('#language_table').DataTable({
				"processing": true, //Feature control the processing indicator.
				"serverSide": true, //Feature control DataTables' server-side processing mode.
				"order": [], //Initial no order.
				"ajax": {
					"url": language_list,
					"type": "POST",
					"data": function (data) {
						data.page_key = page_id
					}
				},
				"columnDefs": [
					{
						"targets": [], //first column / numbering column
						"orderable": false, //set not orderable
					},
				],
			});
		});
	}
	
	if (page == "web_language_keywords") {
		$(document).ready(function () {
			var language_web_list = $('#language_web_list').val();
			language_table = $('#language_web_table').DataTable({
				"processing": true, //Feature control the processing indicator.
				"serverSide": true, //Feature control DataTables' server-side processing mode.
				"order": [], //Initial no order.
				"ajax": {
					"url": language_web_list,
					"type": "POST",
					"data": function (data) {
					}
				},
				"columnDefs": [
					{
						"targets": [], //first column / numbering column
						"orderable": false, //set not orderable
					},
				],
			});
		});
	}

	if (modules == 'policy_settings' || modules == 'client') {
		function imageUpload(error, data, response) {
			$('#imageurl').val(response.image_url);
		}
	}

	if (modules == "new_updates") {
		$(document).ready(function () {
				
			// Check Updates Button 
			$('#check').on('click',function() {
				$(this).html('Please wait checking  <i class="fa fa-spinner fa-spin fa-fw"></i>').removeClass('btn-danger').addClass('btn-warning');
				$.get(BASE_URL + 'admin/new_updates/get_updates', function (res) {
					var obj = jQuery.parseJSON(res);
					if (obj.build) {
						$('#filename').val(obj.filename) // storing new file name in hidden text box 
						$('#check').hide();
						$('#download').removeClass('hidden');
					} else {
						$('#check').html('Already Updated <i class="fa fa-warning"></i>').removeClass('btn-danger').addClass('btn-warning');
					}
				});
			});
			
			// Download Button click 
		
			$('#download').on('click',function() {
				var filename = $('#filename').val();
				if (filename != '') {
					$(this).html('Please wait downloading  <i class="fa fa-spinner fa-spin fa-fw"></i>').removeClass('btn-success').addClass('btn-warning');
					window.open('https://www.dreamguys.co.in/gigs_updates/' + filename, '_self');
					$('#download').html('Download again <i class="fa fa-download">').removeClass('btn-warning').addClass('btn-success');
				}
			});
			
			// Upload Button click 
			$('#upload').on('click',function() {
				$('form')[0].reset();
				$('#upload_file').click();
			});
			
			$('#upload_file').change(function () {
				var formData = new FormData($('#upload_form')[0]);
				$.ajax({
					url: BASE_URL + 'admin/new_updates/upload_updates',
					type: 'POST',
					data: formData,
					async: false,
					success: function (data) {
						var obj = jQuery.parseJSON(data);
						if (obj.success) {
						  $('.notify').html('<div class="alert alert-success fade in alert-dismissable">' +
							'<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>' +
							'<strong>Success!</strong> New Version updated successfully !' +
							'</div>');
							setTimeout(function () {
								window.location.reload();
							}, 1000);
						} else if (obj.error) {
							$('.notify').html('<div class="alert alert-danger fade in alert-dismissable">' +
							'<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>' +
							'<strong>' + obj.error + '</strong> ' +
							'</div>');
						}
					},
					error: function (data) {
					$('.notify').html('<div class="alert alert-danger fade in alert-dismissable">' +
						'<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>' +
						'<strong>Sorry! Some problem occcurs try again later !</strong>' +
						'</div>');

					},
					cache: false,
					contentType: false,
					processData: false
				});
				$('#upload_form')[0].reset();
				return false;
			});
			
			$('.backup_btn').on('click',function() {
				$(this).hide();
				$('.loading').show();
			});
		});
	}

	if(modules=="orders"){
		function change_payments_status(id,ele) {
			bootbox.confirm("Are you sure want to UPDATE ? ", function(result) {
				if(result ==true) {
					var url = BASE_URL+'admin/request/update_payment_status';
					$.ajax({
						url:url,
						data:{id:id}, 
						type:"POST",
						success:function(res){
							if(res==1) {
								$("#"+ele).html('<span class="label label-info">Paid</span>');
							}
						}
					});  
				}
			});            
		}
	}

	function change_payments_status(id,ele) {
		bootbox.confirm("Are you sure want to UPDATE ? ", function(result) {
			if(result ==true) {
				var url = BASE_URL+'admin/request/update_payment_status';
				$.ajax({
					url:url,
					data:{id:id}, 
					type:"POST",
					success:function(res){
						if(res==1) {
							$("#"+ele).html('<span class="label label-success">Transfer Completed</span>');
						}
					}
				});
			}
		});
	}
	
	function paycancel(){
		$('#stripe_popup').modal('hide');
		$('.stripe_payment_price_text').text(0);
		$('#stripe_payment_price_max').val(0);
		$('#stripe_payment_price').attr('max',100);
		$('#return_token').val('');
	}

	function refund_striptpaymet(amount,pid,status,seller_amt,seller_id,payment_id){

		if(status == 'Declined' || status == 'Cancelled'){
			$('#stripe_popup').modal('show');
			$('.stripe_payment_price_text').text(amount);
			$('#stripe_payment_price_max').val(amount);
			$('#stripe_payment_price').attr('max',amount);
			$('#return_token').val(pid);
		}else if(status == 'Completed'){
			$('.acc_name').text('loading...');
			$('.acc_no').text('loading...');
			$('.acc_iban').text('loading...');
			$('.acc_ban_name').text('loading...');
			$('.acc_ban_addr').text('loading...');
			$('.acc_sor_cod').text('loading...');
			$('.acc_rout').text('loading...');
			$('.acc_ifsc').text('loading...');

			$.post(BASE_URL+'user/stripe_payment/details',{id:seller_id},function(data){
				var details = JSON.parse(data);
				details
				$('.acc_name').text(details.account_holder_name);
				$('.acc_no').text(details.account_number);
				$('.acc_iban').text(details.account_iban);
				$('.acc_ban_name').text(details.bank_name);
				$('.acc_ban_addr').text(details.bank_address);
				$('.acc_sor_cod').text(details.sort_code);
				$('.acc_rout').text(details.routing_number);
				$('.acc_ifsc').text(details.account_ifsc);
				var curl = $('#current_page').val();
				curl = curl+'/'+payment_id;
				$('#update_url').attr('href',curl);
			});
			$('#stripe_money_transfer').modal('show');
			$('.stripe_payment_seller_amt').text(seller_amt);
		}
	}

	function submit_stripe(){
		var max_price = parseFloat($('#stripe_payment_price_max').val());
		var stripe_payment_price = parseFloat(($('#stripe_payment_price').val()!="")?$('#stripe_payment_price').val():0);
		var error = 0 ;
		if(stripe_payment_price == ""){
			$('.empty_amount').show();	
			error = 1 ;
		}else{
			$('.empty_amount').hide();	
		}		

		if( stripe_payment_price > 0 && stripe_payment_price >= max_price){		
			$('.empty_amount_refund').show();
			error = 1 ;
		}else{
			$('.empty_amount_refund').hide();
		}
		if(error == 0 ){
			var amount = $('#stripe_payment_price').val();
			var pid = $('#return_token').val();
			stripe_ajax_call(pid,amount);
			return false;	
		}else{
			return false;	
		}
	}

	function stripe_ajax_call(pid,amount){

		var url = BASE_URL+'user/stripe_payment/stripe_refund';
		$.ajax({
			url:url,
			data:{pid:pid,amount:amount}, 
			type:"POST",
			success:function(res){
				if(res==1) {
					bootbox.alert("Your customer sees the refund as a credit approximately 5-10 business days later, depending upon the bank");
				}else{
					bootbox.alert("Something is wrong, Please try later.");
				}
				location.reload();
			}
		});
	}
function update_language_default(val) {
		//bootbox.confirm("Are you sure want to Delete ? ", function (result) {
			//if (result == true) {
				//alert(val);
				var url = BASE_URL + 'admin/language/update_language_default';
				var tbl_id = val;
				$.ajax({
					url: url,
					data: { tbl_id: tbl_id },
					type: "POST",
					success: function (res) {
						if (res == 1) {
							window.location = BASE_URL + 'admin/language';
						}
					}
				});
			//}
		///});
	}
	function refund_amplifypaymet(amount,pid){
		bootbox.prompt({
			title: '<h3 class="text-primary">Refund Amplify Paymet</h3><p>The Gigs amount is '+amount+'. Please pay less than the paid amount</p>',
			inputType: 'number',
			callback: function (result) {
				if(result != '' && result > 0 && result < amount){
					var url = BASE_URL+'user/buy_service/amplify_refund';
					$.ajax({
						url:url,
						data:{pid:pid,amount:result}, 
						type:"POST",
						success:function(res){ 
							if(res==1) {
								bootbox.alert("Amount has been refunded as soon as possible.");
							}else{
								bootbox.alert("Something is wrong, Please try later.");
							}
							location.reload();
						}
					});
				}else if(result < 0){	
				  refund_striptpaymet(amount);	
				}
			}
		});	
	}

	function check_sub_rate() {
		var a=$('#subscription_rate').val();
		if(a!='') {
			$('#subscription_rate').val(parseInt(a));
		}
	}
	
	$('#menu_status').on('click',function() {
		$('#sub_menu').attr('required', 'required');
		$('.sub_menu').show();
	});           
	$('#menu_status_one').on('click',function() {
		$('#sub_menu').removeAttr('required', 'required');
		$('.sub_menu').hide();
	});
	
})(jQuery);