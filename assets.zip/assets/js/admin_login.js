(function($) {
	"use strict";
	
	var BASE_URL=$('#base_url').val();
	var login_error=$('#login_error').val();
	$('#admin_login').bootstrapValidator({
		fields: {        
			username:{
				validators:{
					notEmpty:{
						message: 'Please enter your Username'
					}
				}
			},
			password:{
				validators:{
					notEmpty:{
						message: 'Please enter your Password'
					}
				}
			}           
		}
	}).on('success.form.bv', function(e) {
		var username = $('#username').val();
		var password = $('#password').val();
		$.ajax({
			type:'POST',
			url: BASE_URL+'admin/dashboard/is_valid_login',
			data : {username:username,password:password},
			success:function(response) {     
				if(response==1) { 
					window.location = BASE_URL+'admin';
				}
				else if (response==2) {
					location.reload();
				}
			}                
		});
	});
	
	$('#forget').on('click', function () {
		//var catid = $(this).attr('data-catid');
		window.location=BASE_URL+'admin/dashboard/forget_passwd';
		//get_forgetpasswd(BASE_URL);
	});

	
	
})(jQuery);


