<?php
class admin_login_model extends CI_Model
{
    public function is_valid_login($username, $password)
    {
        $this->db->select('ADMINID,user_role,password');
        $this->db->from('administrators');
        $this->db->where('username', $username);
        $result = $this->db->get()->row_array();
        if ($this->encryption->decrypt($result['password']) == $password) {
            unset($result['password']);
            return $result;
        } else {
            $result = array();
            return $result;
        }
    }
    public function is_valid_password($id, $password)
    {
        $this->db->select('ADMINID,user_role,password');
        $this->db->from('administrators');
        $this->db->where('ADMINID', $id);
        $result = $this->db->get()->row_array();
        if ($this->encryption->decrypt($result['password']) == $password) {
            unset($result['password']);
            return $result;
        } else {
            $result = array();
            return $result;
        }
    }
}
