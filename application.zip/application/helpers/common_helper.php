<?php
function removeTag($data)
{
	foreach ($data as $key => $value) {
		if (!is_array($value)) {
			$_POST[$key] = strip_tags($value);
		}
	}
	return $_POST;
}
