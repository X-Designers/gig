<?php
namespace Braintree;
class AchMandate extends Base
{
    public function __toString()
    {
        return __CLASS__ . '[' . Util::attributesToString($this->_attributes) . ']';
    }
    protected function _initialize($achAttribs)
    {
        $this->_attributes = $achAttribs;
    }
    public static function factory($attributes)
    {
        $instance = new self();
        $instance->_initialize($attributes);
        return $instance;
    }
}
