<?php
namespace Braintree;
class AccountUpdaterDailyReport extends Base
{
    protected $_attributes = array();
    protected function _initialize($disputeAttribs)
    {
        $this->_attributes = $disputeAttribs;
    }
    public static function factory($attributes)
    {
        $instance = new self();
        $instance->_initialize($attributes);
        return $instance;
    }
    public function __toString()
    {
        $display           = array(
            'reportDate',
            'reportUrl'
        );
        $displayAttributes = array();
        foreach ($display AS $attrib) {
            $displayAttributes[$attrib] = $this->$attrib;
        }
        return __CLASS__ . '[' . Util::attributesToString($displayAttributes) . ']';
    }
}
