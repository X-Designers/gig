<?php
class Adminlist extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        error_reporting(0);
        $this->data['theme'] = 'admin';
        $this->data['module'] = 'adminlist';
        $this->load->model('admin_panel_model');
        $this->load->model('common_model','common_model');

        $this->data['admin_id'] = $this->session->userdata('id');
        $this->user_role = !empty($this->session->userdata('user_role')) ? $this->session->userdata('user_role') : 0;
        $this->load->helper('common_helper');
    }
    public function index()
    {
        $this->common_model->checkAdminUserPermission(2);
        $this->data['page'] = 'index';
        $this->data['list'] = $this->admin_panel_model->get_adminlist();
        $this->load->vars($this->data);
        $this->load->view($this->data['theme'] . '/template');
    }
    
    public function add_adminlist()
    {
        $this->common_model->checkAdminUserPermission(2);

        removeTag($this->input->post());
        $this->data['page']            = 'add_adminlist';
       //echo "fdf". $this->data['module_list'] = $this->admin_panel_model->get_modulelist();
        if ($this->input->post('form_submit')) {
            if ($this->data['admin_id'] > 1) {
                $this->session->set_flashdata('message', '<p class="alert alert-danger">Permission Denied</p>');
                redirect(base_url() . 'admin/adminlist');
            } else {
                $data['username']      = $this->input->post('admin_username');
        $data['password']      = $this->encryption->encrypt($this->input->post('admin_password'));
        $data['email']         = $this->input->post('admin_email');
        $data['name']      = ucfirst($this->input->post('admin_fullname'));
        //$data['access_module'] = $this->input->post('accesscheck');
        //print_r($this->input->post('accesscheck'));
         $accesscheck = $this->input->post('accesscheck');


        //$data['country']       = $this->input->post('country_id');
        //$data['state']         = $this->input->post('state_id');
        //$data['user_timezone'] = $this->data['time_zone'];
        //date_default_timezone_set($data['user_timezone']);
        $data['created_date']   = date('Y-m-d H:i:s');
       // $data['verified']       = 1;
        //$data['reference_code'] = rand(10, 1000000);
        $data['status']         = 1;
        
                if ($this->db->insert('administrators', $data)) {
                    $message = "<div class='alert alert-success text-center fade in' id='flash_succ_message'>Admin Added Successfully Added</div>";

                
                $insert_id = $this->db->insert_id();
                 $username            = $this->input->post('admin_username');
                 $module_result = $this->db->select('*')->get('module_list')->result_array();
    foreach ($module_result as $module){
        $adminparams['admin_user_id'] = $insert_id;
        $adminparams['module_id'] = $module['module_id'];
        $access_result = $this->db->where('admin_user_id',$insert_id)->where('module_id',$module['module_id'])->select('access_id')->get('module_access')->result_array();
        if (in_array($module['module_id'], $accesscheck)){         
            $adminparams['access_status'] = 1;
        }else{
            $adminparams['access_status'] = 0;
        }
        if(!empty($access_result)){
            $result=$this->db->where('access_id',$access_result[0]['access_id'])->update('module_access',$adminparams);
        }else{
            $result=$this->db->insert('module_access',$adminparams);
        }
        
    }
            // $url_encypted        = urlencode($this->encryptor('encrypt', $username));
            // $url                 = base_url() . 'activate_account/' . $url_encypted;
            // $this->load->model('templates_model');
            // $message          = '';
            // $welcomemessage   = '';
            // $bodyid           = 13;
            // $tempbody_details = $this->templates_model->get_usertemplate_data($bodyid);
            // $body             = $tempbody_details['template_content'];
            // $body             = str_replace('{base_url}', $this->base_domain, $body);
            // $body             = str_replace('{base_image}', $this->base_domain . '/' . $this->logo_front, $body);
            // $body             = str_replace('{USER_NAME}', $username, $body);
            // $body             = str_replace('{sitetitle}', $this->site_name, $body);
            // $body             = str_replace('{SUBMIT_LINK}', $url, $body);
            // $message          = '<table style="font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: #f6f6f6; margin: 0;" bgcolor="#f6f6f6">
            //                       <tr>
            //                         <td></td>
            //                         <td width="600" style="box-sizing: border-box; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;" valign="top">
            //                           <div style="box-sizing: border-box; max-width: 600px; display: block; margin: 0 auto; padding: 20px;">
            //                             <table width="100%" cellpadding="0" cellspacing="0" style="box-sizing: border-box; font-size: 14px; border-radius: 3px; background-color: #fff; margin: 0; border: 1px solid #e9e9e9;" bgcolor="#fff">
            //                               <tr>
            //                                 <td style="box-sizing: border-box; vertical-align: top; text-align: left; margin: 0; padding: 20px;" valign="top">
            //                                   <table width="100%" cellpadding="0" cellspacing="0">
            //                                     <tr>
            //                                       <td style="text-align:center;">
            //                                         <a href="{base_url}" target="_blank"><img src="' . $this->logo_front . '" style="width:90px" /></a>
            //                                       </td>
            //                                     </tr>
            //                                     <tr>
            //                                       <td>' . $body . '</td>
            //                                     </tr>
            //                                   </table>
            //                                 </td>
            //                               </tr>
            //                             </table>
            //                             <div style="box-sizing: border-box; width: 100%; clear: both; color: #999; margin: 0; padding: 15px 15px 0 15px;">
            //                               <table width="100%">
            //                                 <tr>
            //                                   <td style="font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 12px; vertical-align: top; color: #999; text-align: center; margin: 0; padding: 0;" align="center" valign="top">
            //                                     &copy; ' . date("Y") . ' <a href="' . $this->base_domain . '" target="_blank" style="color:#bbadfc;" target="_blank">' . $this->site_name . '</a> All Rights Reserved.
            //                                   </td>
            //                                 </tr>
            //                               </table>
            //                             </div>
            //                           </div>
            //                         </td>
            //                       </tr>
            //                     </table>';
            // $this->load->helper('file');
            // $this->load->library('email');
            // $this->email->initialize($this->smtp_config);
            // $this->email->set_newline("\r\n");
            // $this->email->from($this->email_address, $this->email_tittle);
            // $this->email->to($this->input->post('admin_username'));
            // $this->email->subject('Welcome and thank you for joining ' . $this->site_name);
            // $this->email->message($message);
            // $send = $this->email->send();
            // if ($send) {
            //     $this->session->set_userdata("add_adminlist", "Success");
            //     echo 1;
            // } else {
            //     echo 0;
            // }
        }
                $this->session->set_flashdata('message', $message);
                redirect(base_url() . 'admin/adminlist');
            }
        }
        $this->load->vars($this->data);
        $this->load->view($this->data['theme'] . '/template');
    }
    public function edit_adminlist($id)
    {
        removeTag($this->input->post());
             $this->common_model->checkAdminUserPermission(2);

        if ($this->data['admin_id'] > 1) {
            $this->session->set_flashdata('message', '<p class="alert alert-danger">Permission Denied</p>');
            redirect(base_url() . 'admin/adminlist');
        } else {
            $this->data['page'] = 'edit_adminlist';
            $this->data['list'] = $this->admin_panel_model->edit_adminlist($id);
            if ($this->input->post('form_submit')) {
                $data['name'] = $this->input->post('admin_fullname');
                $data['email'] = $this->input->post('admin_email');
                $data['username'] = $this->input->post('admin_username');

               $data['verified'] = $this->input->post('admin_verified');
                $data['status'] = $this->input->post('status');
                         $accesscheck = $this->input->post('accesscheck');

                $this->db->where('ADMINID', $id);
                if ($this->db->update('administrators', $data)) {
                    $message = '<div class="alert alert-success text-center fade in" id="flash_succ_message">Admin edited successfully.</div>';
                }
                $username            = $this->input->post('admin_username');
                 $module_result = $this->db->select('*')->get('module_list')->result_array();
                foreach ($module_result as $module){
                $adminparams['admin_user_id'] = $id;
                $adminparams['module_id'] = $module['module_id'];
                $access_result = $this->db->where('admin_user_id',$id)->where('module_id',$module['module_id'])->select('access_id')->get('module_access')->result_array();
            if (in_array($module['module_id'], $accesscheck)){         
            $adminparams['access_status'] = 1;
            }else{
            $adminparams['access_status'] = 0;
            }
            if(!empty($access_result)){
            $result=$this->db->where('access_id',$access_result[0]['access_id'])->update('module_access',$adminparams);
            }else{
            $result=$this->db->insert('module_access',$adminparams);
            }
        
        }
                $this->session->set_flashdata('message', $message);
                redirect(base_url() . 'admin/adminlist');
            }
        }
        $this->load->vars($this->data);
        $this->load->view($this->data['theme'] . '/template');
    }
        public function deleteadmin()
    {  $this->common_model->checkAdminUserPermission(2);
        ////echo "df";exit;
        if ($this->data['admin_id'] > 1) {
            $this->session->set_flashdata('message', '<p class="alert alert-danger">Permission Denied</p>');
            redirect(base_url() . 'admin/adminlist');
        } else {
            $id = $this->input->post('tbl_id');
            //echo $id;exit;
            $this->db->where('ADMINID', $id);
            if ($this->db->delete('administrators')) {
                $message = "<div class='alert alert-success text-center fade in' id='flash_succ_message'>Delete successfully.</div>";
                echo 1;
            }
            $this->session->set_flashdata('message', $message);
        }
    }
    public function activate_account()
    {
        if ($this->uri->segment(2))
            $user_name = $this->uri->segment(2);
        $username = $this->encryptor('decrypt', $user_name);
        if (!empty($username)) {
            $data['verified'] = 0;
            $data['status']   = 0;
            $this->db->update('administrators', $data, array(
                'username' => $username
            ));
            $this->session->set_userdata('users_account_activate', "success");
            redirect(base_url());
        }
        redirect(base_url());
    }
}