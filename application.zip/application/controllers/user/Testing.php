<?php
class Testing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        error_reporting(0);
        $this->load->library('Stripe');
    }
    public function index()
    {
        $result = $this->stripe->direct_charges(500, 'usd', 'acct_1BufHdGUTwCuzzLt', 'sk_test_OVXvseuWuLVp2w0XOWvGKDQJ');
        echo "<pre>";
        print_r($result);
        exit;
    }
}
