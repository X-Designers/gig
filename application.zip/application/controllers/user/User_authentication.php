<?php
defined('BASEPATH') or exit('No direct script access allowed');
class User_Authentication extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        error_reporting(0);
        $this->load->helper('custom_language');
        $default_language_select = default_language();
        if ($this->session->userdata('user_select_language') == '') {
            $this->data['user_selected'] = $default_language_select['language_value'];
        } else {
            $this->data['user_selected'] = $this->session->userdata('user_select_language');
        }
        $this->data['active_language']  = $active_lang = active_language();
        $lg                             = custom_language($this->data['user_selected']);
        $this->data['default_language'] = $lg['default_lang'];
        $this->data['user_language']    = $lg['user_lang'];
        $this->user_selected            = (!empty($this->data['user_selected'])) ? $this->data['user_selected'] : 'en';
        $this->default_language         = (!empty($this->data['default_language'])) ? $this->data['default_language'] : '';
        $this->user_language            = (!empty($this->data['user_language'])) ? $this->data['user_language'] : '';
        $this->load->helper('favourites');
        $common_settings  = gigs_settings();
        $default_currency = 'USD';
        if (!empty($common_settings)) {
            foreach ($common_settings as $datas) {
                if ($datas['key'] == 'currency_option') {
                    $default_currency = $datas['value'];
                }
            }
        }
        $this->load->helper('currency');
        $this->load->helper('common_helper');
        $this->default_currency      = $default_currency;
        $this->default_currency_sign = currency_sign($default_currency);
        $this->smtp_config           = smtp_mail_config();
    }
    public function index()
    {
        // Include the facebook api php libraries
        include_once APPPATH . "libraries/inc/facebook.php";
        // Facebook API Configuration
        $appId         = '2911852635603641';
        $appSecret     = '9e68b46becec3c386f2cbad2a49d9301';
        $redirectUrl   = base_url() . 'user/user_authentication/';
        $fbPermissions = 'email';
        //Call Facebook API
        $facebook      = new Facebook(array(
            'appId' => $appId,
            'secret' => $appSecret
        ));
        $fbuser        = $facebook->getUser();
        if ($fbuser) {
            $userProfile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
            print_r($userProfile);
            exit;
            // Preparing data for database insertion
            $userData['oauth_provider'] = 'facebook';
            $userData['oauth_uid']      = $userProfile['id'];
            $userData['first_name']     = $userProfile['first_name'];
            $userData['last_name']      = $userProfile['last_name'];
            $userData['email']          = $userProfile['email'];
            $userData['gender']         = $userProfile['gender'];
            $userData['locale']         = $userProfile['locale'];
            $userData['profile_url']    = 'https://www.facebook.com/' . $userProfile['id'];
            $userData['picture_url']    = $userProfile['picture']['data']['url'];
        } else {
            $fbuser          = '';
            $data['authUrl'] = $facebook->getLoginUrl(array(
                'redirect_uri' => $redirectUrl,
                'scope' => $fbPermissions
            ));
        }
        $this->load->view('user/modules/user_authentication/index', $data);
    }
    public function logout()
    {
        $this->session->unset_userdata('userData');
        $this->session->sess_destroy();
        redirect('/user_authentication');
    }
}
