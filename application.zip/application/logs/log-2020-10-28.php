<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/profile_images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:23:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:23:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 05:34:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:34:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:41:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:41:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:42:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 05:42:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:42:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 05:42:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:42:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:43:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:43:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:43:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:44:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:44:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:44:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:45:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:45:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:45:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:46:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:46:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:46:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:47:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:47:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:47:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:48:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:48:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:48:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:49:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:49:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:49:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:50:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:50:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:50:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:51:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:51:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:51:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 05:52:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:09:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:09:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:09:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:09:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:09:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:09:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:09:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:09:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:09:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:10:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:10:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:10:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:10:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:12:39 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 06:12:40 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 06:12:40 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 06:12:40 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 06:12:40 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 06:12:41 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 06:12:41 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 06:12:41 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 06:12:41 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 06:12:41 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 06:12:42 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 06:12:42 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 06:12:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:12:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:12:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:12:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:13:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:14:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:15:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:16:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:17:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:17:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:18:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:33 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 06:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:19:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:20:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:20:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:21:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:21:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:22:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:22:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:22:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:22:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:22:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:22:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:23:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:23:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:27:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:28:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:29:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:30:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:31:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:32:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:33:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:33:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:33:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:34:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:35:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:36:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 06:37:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 06:37:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 06:37:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:37:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:37:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:38:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:38:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:38:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:39:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:39:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:39:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:39:55 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 06:40:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:40:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:41:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:41:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:41:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:42:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:42:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:42:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:43:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:43:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:43:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:44:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:44:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:44:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:45:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:45:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:45:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:46:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:46:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:46:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:46:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:46:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:46:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:47:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:47:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:47:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:47:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:47:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:47:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:48:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:48:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:48:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:48:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:48:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:48:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:10 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 06:49:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 06:49:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:49:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:49:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 06:49:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:49:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:49:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:50:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:51:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:52:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:30 --> 404 Page Not Found: admin/Admin_list/index
ERROR - 2020-10-28 06:53:30 --> 404 Page Not Found: admin/Admin_list/index
ERROR - 2020-10-28 06:53:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:53:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 06:54:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:54:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:55:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:55:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:55:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:56:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:56:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:56:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:57:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:57:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:57:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:58:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:58:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:58:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:59:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:59:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 06:59:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:00:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:00:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:00:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:01:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:01:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:01:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:02:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:02:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:02:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:03:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:03:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:03:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:04:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:04:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:04:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:05:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:05:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:05:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:06:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:06:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:06:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:07:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:07:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:07:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:08:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:08:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:08:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:09:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:09:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:09:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:10:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:10:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:10:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:11:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:11:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:11:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:12:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:12:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:12:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:13:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:13:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:13:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:14:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:14:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:14:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:14:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:14:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:14:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:15:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:15:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:15:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:15:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:15:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:16:12 --> 404 Page Not Found: admin/Admin_list/edit_adminlist
ERROR - 2020-10-28 07:16:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:18:53 --> 404 Page Not Found: admin/Admin_list/edit_adminlist
ERROR - 2020-10-28 07:18:56 --> 404 Page Not Found: admin/Admin_list/edit_adminlist
ERROR - 2020-10-28 07:19:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:19:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:19:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:19:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:19:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:19:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:20:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:20:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:20:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:20:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:21:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:21:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:22:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:22:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:23:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:23:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:23:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:23:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:23:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:23:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:24:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:24:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:24:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:24:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:24:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:24:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:24:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:24:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:25:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:25:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:25:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:25:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:25:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:26:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:26:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:26:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:26:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:26:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:27:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:27:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:27:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:28:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:28:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:28:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:29:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:29:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:29:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:30:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:30:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:30:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:31:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:31:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:31:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:32:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:32:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:32:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:33:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:33:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:33:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:33:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:33:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:33:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:34:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:34:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:34:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:35:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:35:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:35:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:36:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:36:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:36:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:37:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:37:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:37:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:38:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:38:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:38:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:39:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:39:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:39:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:40:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:40:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:40:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:41:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:41:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:41:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:42:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:42:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:42:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:43:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:43:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:43:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:44:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:44:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:44:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:45:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:45:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:45:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:46:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:46:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:46:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:47:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:47:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:47:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:48:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 07:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:48:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:49:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:49:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:49:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:50:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:50:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:50:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:51:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:51:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:51:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:52:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:52:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:52:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:53:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:53:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:53:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:54:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:54:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:54:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:55:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:55:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:55:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:55:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:55:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:56:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:56:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:56:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:57:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:57:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:57:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:58:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:58:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 07:58:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:58:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 07:59:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 07:59:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:59:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 07:59:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:00:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:00:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:00:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:01:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:05:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:05:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:05:51 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:05:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:06:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:06:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:06:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:07:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:07:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:07:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:08:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:08:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:08:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:09:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:09:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:09:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:09:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:09:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:09:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:10:03 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:10:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:10:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:10:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:11:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:11:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:11:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:12:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:12:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:12:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:12:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:12:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:13:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:13:05 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:13:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:13:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:14:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:14:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:14:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:15:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:15:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:15:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:16:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:16:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:16:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:17:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:17:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:17:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:17:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:17:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:17:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:17:55 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:18:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:18:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:18:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:18:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:18:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:19:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:19:11 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:19:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:19:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:19:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:19:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:19:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:19:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:19:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:19:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:20:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:20:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:20:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:20:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:20:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:20:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:20:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:20:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:20:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:21:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:21:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:21:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:21:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:21:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:21:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:22:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:22:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:22:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:23:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:23:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:23:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:24:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:24:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:24:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:25:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:25:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:25:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:26:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:26:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:26:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:26:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:26:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:26:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:27:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:27:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:27:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:27:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:27:34 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:28:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:28:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:28:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:28:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:28:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:28:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:28:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:28:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:28:58 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:29:00 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:29:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:29:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:29:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:29:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:29:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:30:00 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:30:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:30:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:30:54 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Gigs.php 133
ERROR - 2020-10-28 08:30:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:31:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:31:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:31:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:31:14 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:31:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:31:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:32:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:32:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:32:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:32:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:32:59 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:33:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:33:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:33:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:34:08 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:34:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:34:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 08:34:33 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:34:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:34:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:35:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:35:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:35:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:36:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:36:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:36:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:37:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:37:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:37:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:38:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:38:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:38:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:39:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:39:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:39:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:40:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:40:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:40:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:41:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:41:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:42:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:42:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:42:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 08:43:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:43:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:43:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:43:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:43:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:43:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 08:44:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 08:44:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:00:58 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 09:00:58 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 09:00:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 09:00:59 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 09:00:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 09:00:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 09:01:00 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 09:01:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 09:01:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 09:01:00 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 09:01:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 09:01:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 09:01:00 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 09:01:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 09:01:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 09:01:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:01:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:01:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:01:32 --> Query error: Unknown column 'admin_email' in 'field list' - Invalid query: INSERT INTO `administrators` (`name`, `password`, `admin_email`, `admin_username`, `created_date`, `verified`, `status`) VALUES ('', '32cd35a9377d01137c64f450ae6fbc1aa67437cac77b21b152b34ff35b02f05ee9e1c68dec2b53040c7587afba02e8e23c395399133090990a4eb3871de2d904GumeEW2ay05/eV4eC8w9Rkc1gw5N/Gg/schHFeoniKc=', NULL, NULL, '2020-10-28 09:01:32', 1, 1)
ERROR - 2020-10-28 09:10:37 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 141
ERROR - 2020-10-28 09:18:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:18:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:18:18 --> Severity: error --> Exception: Call to undefined method Adminlist::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 51
ERROR - 2020-10-28 09:18:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:19:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:20:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:20:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 09:20:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:20:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:21:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:21:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:22:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:22:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:22:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:22:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:22:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:22:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:22:50 --> Severity: error --> Exception: Call to undefined method Adminlist::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 51
ERROR - 2020-10-28 09:23:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:23:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:23:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:23:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:24:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:24:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:24:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:25:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:25:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:25:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:26:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:26:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:26:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:27:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:27:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:27:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:28:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:28:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:28:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:29:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:29:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:29:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:30:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:30:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:30:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:30:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:30:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:31:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:32:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:32:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:32:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:32:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:32:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:32:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:33:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:33:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:33:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:33:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:33:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:33:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:34:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:34:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:34:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:34:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:34:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:34:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:35:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:35:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:35:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:35:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:35:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:36:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:37:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:37:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:37:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:37:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:37:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:37:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:38:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:38:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:38:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:38:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:38:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:38:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:39:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:58:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:58:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 09:59:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:59:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 09:59:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:00:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:00:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:00:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:00:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:00:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:01:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:01:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:01:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:02:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:02:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:02:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 10:03:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:03:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:03:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:04:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 10:04:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:04:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:05:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:05:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:05:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:06:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:06:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:06:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:07:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:07:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:07:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:08:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:08:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:08:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:08:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:08:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:09:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:09:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:11:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:11:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:11:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:12:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:12:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:12:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:12:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:12:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:13:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:13:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:13:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:14:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:14:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:14:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:14:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:14:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:14:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:14:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:15:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:15:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:16:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:16:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:17:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:17:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:17:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:18:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:18:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:19:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:19:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:20:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:20:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:20:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:20:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:20:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:21:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:21:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:21:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:21:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:21:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:22:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:23:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:23:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:23:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:23:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:23:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:23:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:24:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:24:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:24:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:24:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:24:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:24:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:25:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:25:17 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:25:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:25:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:25:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:25:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:25:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:26:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:26:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:26:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:26:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:26:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:26:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:27:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:27:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:27:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:27:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:27:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:27:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:28:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:28:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:28:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:28:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:28:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:28:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:29:06 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:29:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:29:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:29:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:29:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:29:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:29:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:29:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:30:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:30:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:30:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:30:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:30:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:31:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:31:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:31:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:31:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:31:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:31:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:31:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:31:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:31:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:32:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:32:15 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:32:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:32:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:33:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:33:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:33:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:34:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:34:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:34:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:35:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:35:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:35:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:35:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:35:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:35:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:36:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:36:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:36:36 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:36:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:36:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:37:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:37:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:37:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:38:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:38:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:38:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:39:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:39:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:39:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:40:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:40:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:40:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:41:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:41:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:42:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:42:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:42:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:42:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:42:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:42:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:42:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:42:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:43:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:43:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:43:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:43:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:43:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:44:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:44:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:44:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:44:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:45:01 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:45:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:45:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:45:18 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:45:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:45:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:45:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:45:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:46:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:46:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:46:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:46:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:46:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:46:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:47:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:47:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:47:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:47:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:47:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:47:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:48:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:48:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:48:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:48:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:48:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:49:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:50:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:50:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:50:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:50:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:50:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:50:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:51:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:51:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:51:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:51:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:51:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:51:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:52:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:52:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 10:52:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:52:37 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-28 10:52:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:52:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:53:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:53:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:54:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:54:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:54:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:55:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:55:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 10:55:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:55:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:56:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:56:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:57:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:57:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:57:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:57:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:58:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:59:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:59:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 10:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 10:59:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 10:59:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:00:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:00:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:00:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:00:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:01:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:01:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:01:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:02:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:03:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:03:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:03:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:04:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:04:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:04:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:04:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:04:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:04:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:04:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:04:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:04:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:05:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:05:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:05:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:05:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:05:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:06:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:06:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:07:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:07:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:07:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:07:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:07:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:08:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:08:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:08:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:08:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:08:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:08:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:08:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:09:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:09:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:09:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:09:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:09:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:10:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:10:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:10:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:10:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:10:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:10:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:11:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:12:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:12:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:12:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:12:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:12:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:12:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:12:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:12:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:12:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:12:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:12:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:13:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:13:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:13:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:13:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:13:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:13:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:14:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:14:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:14:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:14:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:14:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:14:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:14:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:14:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:15:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:15:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:15:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:15:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:15:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:15:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:16:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:16:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:16:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:17:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:17:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:18:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:19:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:19:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:19:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:19:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:19:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:20:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:20:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:20:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:20:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:20:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:20:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:21:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:21:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:21:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:21:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:22:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:23:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:23:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:23:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:23:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:23:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:23:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:24:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:25:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:25:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:25:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:25:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:25:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:25:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:26:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:26:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:27:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:27:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 11:27:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:27:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 11:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:27:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 11:27:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:28:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:28:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:28:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:28:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:28:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:29:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:29:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:29:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:29:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:29:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:30:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:30:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:30:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:30:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:30:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:30:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:32:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:33:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:34:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:34:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:34:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:34:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:35:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:35:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:35:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:36:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:36:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:36:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:37:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:37:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:37:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:38:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:38:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:38:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:39:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:39:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:39:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:40:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:40:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:40:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:41:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:41:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:41:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:42:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:42:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 11:42:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:43:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:43:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:43:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:44:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:44:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:44:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:45:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:45:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:45:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:46:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:46:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:46:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:47:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:47:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:47:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:48:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:48:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:48:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:49:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:49:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:49:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:50:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:50:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:50:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:51:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:51:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:51:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:52:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:52:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 11:52:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 12:00:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:00:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:00:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:00:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:00:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:00:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:01:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:01:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:01:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:01:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:02:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:02:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:02:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:02:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:02:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:02:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:02:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:03:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:03:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:03:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:03:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:04:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:04:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:04:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:04:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:05:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:05:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:05:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:05:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:05:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:05:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:06:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:06:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:06:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:07:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:07:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:07:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:07:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:08:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:09:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:09:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:09:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:10:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:12:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:13:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:13:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:13:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:13:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:14:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:14:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:14:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:15:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:15:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:15:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:15:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:15:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:16:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:16:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 12:16:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:16:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:17:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:17:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:17:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:18:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:19:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 12:20:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:20:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 12:21:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:21:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:22:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:22:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:22:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:22:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:22:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:23:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:23:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:23:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:24:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:24:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:25:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:25:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:25:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:25:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:26:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:26:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:27:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:28:07 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:28:08 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:28:08 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:29:11 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:29:12 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:29:12 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:29:12 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:29:12 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:29:13 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:29:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:29:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:29:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:30:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:30:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:30:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:30:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:31:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:32:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:32:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:32:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:32:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:33:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:33:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:33:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:34:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:35:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:35:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:35:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:36:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:36:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:36:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:37:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:37:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:37:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:38:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:38:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:39:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:39:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:40:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:40:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:42:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:42:44 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:42:45 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:42:45 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:42:45 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:42:46 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:42:46 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:43:33 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:43:34 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:43:35 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:43:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:43:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:44:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:44:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:44:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:44:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:45:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:45:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:45:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:45:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'key = 'auto_approval'' at line 1 - Invalid query:  UPDATE system_settings SET value = 0 WHERE key = 'auto_approval' 
ERROR - 2020-10-28 12:45:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:45:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:46:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:46:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:46:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:46:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:46:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:47:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:47:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:47:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:47:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'key = 'auto_approval'' at line 1 - Invalid query:  UPDATE system_settings SET value = 1 WHERE key = 'auto_approval' 
ERROR - 2020-10-28 12:47:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:47:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:47:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE key = 'auto_approval'' at line 1 - Invalid query:  UPDATE system_settings SET value =  WHERE key = 'auto_approval' 
ERROR - 2020-10-28 12:48:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:48:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:48:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:48:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:48:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 12:48:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 12:48:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:48:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:48:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 12:49:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:49:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:49:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:50:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:50:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:50:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:51:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:51:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:51:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:51:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `key` = 'auto_approval'' at line 1 - Invalid query:  UPDATE `system_settings` SET `value` =  WHERE `key` = 'auto_approval' 
ERROR - 2020-10-28 12:53:01 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:53:02 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:53:02 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:53:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:53:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:54:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:54:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:54:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:54:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:55:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:55:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:55:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:56:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:56:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:56:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:56:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:00 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 12:58:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 12:58:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 12:58:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:58:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:59:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:59:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:59:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:59:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 12:59:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:00:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:00:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:00:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:01:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:01:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:01:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:01:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `key` = 'auto_approval'' at line 1 - Invalid query:  UPDATE `system_settings` SET `value` =  WHERE `key` = 'auto_approval' 
ERROR - 2020-10-28 13:02:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:02:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:02:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:02:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:02:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:02:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:03:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:03:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:03:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:03:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:03:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:04:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:04:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:05:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:05:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:05:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:06:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:06:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:07:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:07:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:07:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:07:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:07:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:08:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:08:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:08:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:09:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:09:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:10:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:10:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:10:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:11:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:11:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:12:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:12:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:12:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:13:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:13:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:14:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:14:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:14:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:15:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:15:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:16:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:16:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:17:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:17:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:30:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:30:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:30:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:30:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:30:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:30:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:31:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:31:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:31:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:31:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:32:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:32:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:33:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:33:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:33:32 --> Query error: Column 'user_timezone' cannot be null - Invalid query: INSERT INTO `members` (`username`, `password`, `email`, `fullname`, `country`, `state`, `user_timezone`, `created_date`, `verified`, `reference_code`, `status`) VALUES ('divyaa14', '224d6b4ca2ab686eac98d14961146ef9057335101bda7582241edc0d6fbf0cbffa6b3e4673af560583c97ec653a0d2203a9ce79e2929a1c27fa0d3c05095ce3425gGMOlVrSQF3sCBf8qJVoVgu8qTE7LL1QPxaxUMaXU=', 'divya.a@dreamguys.co.in', 'Divya', '101', '35', NULL, '2020-10-28 13:33:32', 1, 274302, 1)
ERROR - 2020-10-28 13:33:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:33:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 13:34:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:34:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:34:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:35:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:35:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:35:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:36:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:36:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:36:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:36:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:37:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:37:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:38:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:38:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:38:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:38:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:39:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:39:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:40:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:40:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:40:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:41:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:41:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:41:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:41:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:41:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:41:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:41:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:42:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:42:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:42:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:42:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:42:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:42:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:42:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:43:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:43:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:43:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:43:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:43:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:43:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:43:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 13:43:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 13:44:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:44:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:44:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:44:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:44:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:44:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:45:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:45:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:45:13 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:45:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:45:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:45:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:45:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:46:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:46:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:46:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:46:26 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:46:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:46:32 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:46:36 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:46:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:46:44 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:46:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:46:59 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:47:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:47:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:47:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:47:22 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:47:24 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:47:26 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:47:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:47:28 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:47:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:47:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:47:57 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:48:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:48:01 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:48:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:48:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:48:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-28 13:48:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-28 13:48:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 13:48:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:48:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:48:41 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:48:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:49:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:49:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:49:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 13:49:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:49:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:49:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:50:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:50:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:50:09 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:12 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:15 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:17 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:20 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:23 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:23 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:24 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:24 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:50:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:50:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:50:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:50:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:51:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:51:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:51:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:51:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:51:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:51:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:52:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:52:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:52:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:52:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:52:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:53:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:53:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:53:08 --> Severity: error --> Exception: Call to undefined function frompng() D:\xampp\htdocs\thegigs_web\application\controllers\user\Sell_service.php 544
ERROR - 2020-10-28 13:53:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:53:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:53:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:53:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:54:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 13:54:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:54:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:54:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:55:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:55:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:55:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:56:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:56:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:56:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:57:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:57:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:57:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:58:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:58:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:58:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:59:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:59:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 13:59:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:00:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:00:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:00:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:01:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:01:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:01:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:02:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:02:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:02:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:03:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:03:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:03:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:04:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:04:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:04:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:04:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:04:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:04:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:05:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:05:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:05:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:05:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:05:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:05:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:05:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:05:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:05:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:05:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:05:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:05:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:05:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:06:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:06:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:06:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:06:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:06:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:06:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:06:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:07:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:07:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:07:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:07:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:07:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:07:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:08:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:08:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:08:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:08:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:08:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:08:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:08:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:08:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:09:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:09:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:09:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:09:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:09:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:10:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:10:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:10:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:10:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:10:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:11:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:11:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:11:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:11:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:11:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 14:11:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:12:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:12:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:12:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:12:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:12:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:12:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:13:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:13:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:13:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:13:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:13:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:13:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:13:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:13:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:13:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:14:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:14:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:14:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:14:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:14:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:14:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:15:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:15:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:16:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:16:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:16:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:16:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:16:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:16:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:16:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:17:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:17:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:17:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:17:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:17:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:17:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:17:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:17:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:18:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:18:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:18:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:18:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:18:50 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:19:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:19:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:19:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:19:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:19:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:19:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:20:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:20:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:20:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:20:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:21:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:21:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:21:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:21:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:22:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:22:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:22:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:22:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:22:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:22:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:23:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:23:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:23:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:23:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:24:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:24:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:24:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:24:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:24:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:24:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:24:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:24:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:24:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:24:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:24:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:24:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:25:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:25:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:25:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:25:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:26:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:26:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:26:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:26:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:26:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 14:27:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:27:55 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:28:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:28:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:28:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:28:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:28:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:28:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:28:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:28:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:29:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:29:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:29:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:29:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:29:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:30:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:30:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:30:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:30:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:30:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:31:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:31:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:31:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:31:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:31:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:32:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:32:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:32:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:32:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:33:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:33:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:33:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:34:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:34:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:34:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:34:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:34:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:34:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:35:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:35:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:35:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:35:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:36:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:36:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:36:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:37:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:37:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:37:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:37:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:37:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:39:15 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:39:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:39:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:39:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:40:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:40:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:40:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:41:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:41:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:41:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:42:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:42:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:42:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:42:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:43:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:43:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:43:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:43:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:43:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:43:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:44:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:44:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:48:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:48:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:49:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:49:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:49:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:49:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:49:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:49:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:50:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:50:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:50:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:50:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:50:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:50:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:51:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:51:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:51:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:51:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:52:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:52:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:52:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:52:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:52:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:52:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:53:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:53:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:53:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:53:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:53:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:53:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 14:53:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:53:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:54:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:54:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:54:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:54:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:54:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:54:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:54:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:54:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:54:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:54:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:54:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:54:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:54:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:55:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:55:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:55:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:55:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:55:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:55:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:55:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:55:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 14:55:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:55:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:55:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:55:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:55:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:55:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:56:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:56:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:56:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:56:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:56:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:56:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:56:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:57:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:57:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:57:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:57:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:57:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:57:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:57:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:58:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:58:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:58:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:58:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:58:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:58:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:58:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:59:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:59:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:59:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:59:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:59:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:59:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:59:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 14:59:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 14:59:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:00:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:00:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:00:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:00:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:00:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:00:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:00:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:01:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:01:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:01:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:01:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:01:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:01:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:01:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:01:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:02:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:02:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:02:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:02:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:02:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:02:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:02:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:02:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:03:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:03:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:03:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:03:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:03:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:03:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:03:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:03:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:03:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:03:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:03:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:04:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:04:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:04:23 --> Query error: Unknown column 'image_for' in 'field list' - Invalid query: INSERT INTO `bgimage` (`image_for`) VALUES ('Slider_Bg')
ERROR - 2020-10-28 15:04:50 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:04:51 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:05:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:05:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:05:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:05:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:05:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:05:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:05:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:05:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:05:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:06:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:06:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:06:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:06:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:06:40 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:07:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:07:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:07:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:07:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:07:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:07:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:07:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:07:53 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:08:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:08:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:08:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:08:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:08:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:09:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:09:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:09:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:09:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:09:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:09:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:09:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:10:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:10:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:10:16 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:10:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:10:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:10:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:11:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:11:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 15:11:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:11:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:11:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:12:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:12:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:12:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:12:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:12:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:12:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:13:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:13:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:13:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:13:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:13:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:13:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:13:58 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:14:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:14:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:14:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:14:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:14:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:14:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:14:53 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:15:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 15:15:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:15:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:16:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:16:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:17:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:17:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:17:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:18:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:18:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 15:19:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:19:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:19:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 15:19:59 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:53:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 15:54:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:54:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 15:54:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 15:54:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 15:54:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 15:55:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 15:55:21 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:57:42 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:58:04 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:58:22 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:58:56 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 15:59:16 --> Severity: error --> Exception: Call to undefined method Bgimage::image_resize() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 44
ERROR - 2020-10-28 16:00:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'jpg,`cropped_img` =uploads/category/mini_images/1603897206_256_256.jpg WHERE ...' at line 1 - Invalid query:  UPDATE `bgimage` SET `upload_image` = uploads/banners/1603897206.jpg,`cropped_img` =uploads/category/mini_images/1603897206_256_256.jpg WHERE `bgimg_id` = 16 
ERROR - 2020-10-28 16:01:20 --> Severity: error --> Exception: syntax error, unexpected '' . $src2 . '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 86
ERROR - 2020-10-28 16:02:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'jpg,`cropped_img` =uploads/category/mini_images/1603897329_256_256.jpg WHERE ...' at line 1 - Invalid query:  UPDATE `bgimage` SET `upload_image` = uploads/banners/1603897329.jpg,`cropped_img` =uploads/category/mini_images/1603897329_256_256.jpg WHERE `bgimg_id` = 17 
ERROR - 2020-10-28 16:07:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '18''' at line 1 - Invalid query:  UPDATE `bgimage` SET `upload_image` = 'uploads/banners/1603897637.jpg',`cropped_img` ='uploads/category/mini_images/1603897637_256_256.jpg'' WHERE `bgimg_id` = '18'' 
ERROR - 2020-10-28 16:09:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 16:09:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 16:09:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 16:09:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:09:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:09:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:09:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:09:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:09:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:10:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:10:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:10:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:11:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:11:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:11:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:11:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:11:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:12:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:12:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:12:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:12:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:13:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:13:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:13:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:14:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:14:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:14:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:15:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:15:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:15:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:15:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:16:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:16:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:16:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 16:16:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:16:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:16:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:16:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:17:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:17:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:17:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:17:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:17:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:17:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:18:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:18:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:18:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:18:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:18:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:18:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:19:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:19:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:19:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:19:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:19:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:20:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:20:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:20:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:20:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:20:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:20:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:20:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:21:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:21:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 16:21:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:21:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:22:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:23:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 16:23:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:21:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:21:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:21:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:21:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:42:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 17:42:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:43:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:43:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:43:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:43:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:44:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:44:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:44:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:45:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:45:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:45:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:46:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:46:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:46:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:47:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:47:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:47:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:48:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:48:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:48:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:49:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:49:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:50:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:50:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:50:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:51:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:51:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:51:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:52:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 17:58:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 17:58:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:59:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:59:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 17:59:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:00:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:00:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:00:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:00:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:00:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:01:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:01:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:01:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:01:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:01:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:01:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:02:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:02:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:03:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:03:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:03:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:03:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:03:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:03:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:04:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:04:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:04:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:04:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:04:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:04:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:05:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:05:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:05:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:05:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:05:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:10:43 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 18:10:44 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 18:10:44 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 18:10:45 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 18:10:45 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 18:10:45 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 18:10:45 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 18:10:45 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 18:10:46 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 18:10:46 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 18:10:46 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 18:10:46 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 18:10:46 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 18:10:46 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 18:10:46 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 18:10:46 --> Severity: Error --> Maximum execution time of 120 seconds exceeded D:\xampp\htdocs\thegigs_web\system\libraries\Session\drivers\Session_files_driver.php 180
ERROR - 2020-10-28 18:10:47 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2020-10-28 18:10:47 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\ADMIN\AppData\Local\Temp) Unknown 0
ERROR - 2020-10-28 18:10:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:10:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:10:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:10:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:10:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:10:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:12:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:12:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:12:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:13:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:13:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:13:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:14:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:14:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:14:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:15:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:15:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:16:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:16:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:16:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:17:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:17:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:17:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:18:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:18:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:18:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:19:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:19:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:19:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:20:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:20:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:20:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:21:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:21:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:21:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:22:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:34:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:34:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:34:37 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:35:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:35:55 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:36:18 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:36:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:36:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:36:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:36:33 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:36:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:36:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:36:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:36:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:36:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:36:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:37:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:37:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:38:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:38:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:38:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:38:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:38:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:38:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:38:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:38:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:39:11 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:39:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:39:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:39:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:40:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:40:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:40:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:40:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:41:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:41:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:41:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:41:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:41:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:41:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:41:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:42:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:42:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:42:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:42:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:42:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:43:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:43:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:43:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:43:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:43:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:44:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:44:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:44:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:44:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:44:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:44:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:45:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:45:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:45:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:45:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:45:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:45:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:46:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:46:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:46:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:46:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:46:31 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 18:46:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:46:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:46:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:47:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:47:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:47:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:47:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:47:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:47:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:48:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:48:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:48:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 18:48:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:48:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 18:48:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 18:48:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-28 18:49:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:49:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:49:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:49:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:49:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:49:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:49:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:49:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 18:49:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:50:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:50:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:50:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:50:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:50:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:50:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:51:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:51:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:51:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:51:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:51:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:51:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:52:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:52:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:52:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:52:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:52:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:52:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 18:53:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:53:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:53:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:53:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:53:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:53:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:54:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:54:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:54:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:54:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:54:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:55:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:55:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:55:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:55:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:55:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:55:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:56:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:56:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:56:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:56:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:56:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:56:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:57:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:57:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:57:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:57:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:57:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:57:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:58:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:58:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:58:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:58:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:58:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:58:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:59:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:59:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:59:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:59:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:59:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 18:59:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:00:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:00:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:00:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:00:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:00:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:00:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:01:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:01:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:01:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:01:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:01:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:01:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:02:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:02:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:02:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:02:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:02:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:02:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:03:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:03:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:03:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:03:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:03:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:03:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:04:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:04:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:04:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:04:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:04:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:05:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:12:14 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:12:25 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:12:47 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:13:02 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:13:35 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:13:38 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:13:38 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:13:39 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:13:52 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:14:04 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:14:06 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:14:07 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:14:07 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:14:07 --> Severity: error --> Exception: Call to undefined method Gigs_model::get_bg_image() D:\xampp\htdocs\thegigs_web\application\controllers\Gigs.php 141
ERROR - 2020-10-28 19:19:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:19:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:19:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:19:29 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 19:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:19:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:19:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:20:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:20:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:20:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:21:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:21:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 19:39:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-28 19:39:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:39:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:39:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:39:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:39:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:39:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:40:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:40:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:40:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:40:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:40:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:40:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:41:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:41:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:41:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:41:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:41:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:41:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:42:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:42:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:42:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:42:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:43:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:43:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-28 19:43:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:43:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:43:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:44:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 19:44:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:44:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:44:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:44:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:44:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:44:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:44:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:45:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:45:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:45:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:46:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:46:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-28 19:46:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:46:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:47:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:47:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:47:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:48:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:48:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:48:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:49:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:49:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:49:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:50:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:50:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:50:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:51:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:51:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:51:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:52:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:52:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:52:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:53:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:53:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:53:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:54:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-28 19:56:52 --> 404 Page Not Found: Forget_passwd/index
ERROR - 2020-10-28 19:57:13 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-28 19:57:44 --> Query error: Unknown column 'Slider_bg' in 'where clause' - Invalid query: SELECT * FROM `bgimage` WHERE `bgimg_for` = Slider_bg 
ERROR - 2020-10-28 19:58:34 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-28 19:59:50 --> Query error: Unknown column 'Slider_bg' in 'where clause' - Invalid query: SELECT * FROM `bgimage` WHERE `bgimg_for` = Slider_bg 
ERROR - 2020-10-28 20:02:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 20:02:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 20:02:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:15 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-28 20:02:28 --> 404 Page Not Found: admin/Forget_passwd/index
