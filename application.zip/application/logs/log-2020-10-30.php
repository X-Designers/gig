<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-30 05:33:27 --> 404 Page Not Found: Uploads/gig_images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-30 05:33:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:33:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:33:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:33:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:33:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:34:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:34:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:34:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:34:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:35:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:35:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:35:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:36:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:36:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:36:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:37:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:37:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:37:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:38:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:38:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:39:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:39:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:39:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:39:47 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 05:39:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:39:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:40:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-30 05:40:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:40:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:40:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:40:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:40:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:41:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:41:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:42:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:42:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:42:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:43:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:43:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:44:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:44:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:44:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:45:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:45:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:45:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:46:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:46:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:46:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:47:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:47:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:47:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:48:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-30 05:48:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 05:48:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:48:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:48:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:48:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:48:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:48:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:49:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:49:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:49:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:50:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:50:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:50:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:51:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:51:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:51:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:52:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:52:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:52:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:52:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:53:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:53:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:53:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:53:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 05:54:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:54:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:54:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:55:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:55:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:56:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:56:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:56:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:56:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:57:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:57:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:57:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:58:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:58:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:58:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:59:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:59:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 05:59:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:00:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:00:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:00:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:01:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:01:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:01:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:02:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:02:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:02:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:02:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:02:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:03:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:03:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:03:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:04:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:04:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:04:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:05:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:05:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:05:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:06:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:06:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:06:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:07:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:07:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:07:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:08:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:08:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:08:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:09:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:09:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:09:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:09:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:10:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:10:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:10:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:11:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:11:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:11:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:12:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:12:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:12:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:13:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:13:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:13:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:14:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:14:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:14:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:15:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:15:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:15:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:16:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:16:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:16:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:16:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:17:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:17:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:17:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:18:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:18:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:18:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:19:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:19:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:19:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:20:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:20:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:20:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:21:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:21:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:21:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:22:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:22:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:22:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:23:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:23:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:23:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:24:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:24:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:24:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:25:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:25:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:25:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:26:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:27:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:28:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:28:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:35:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:35:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:36:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:37:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:37:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:37:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:38:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:38:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:38:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:38:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:38:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:38:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:39:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:39:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:39:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:40:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:40:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:40:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:40:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:41:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:41:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 06:41:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:42:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:42:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:42:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:43:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:43:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:43:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:43:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:44:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:44:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:44:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:44:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:44:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:45:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:45:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:45:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:47:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:47:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:47:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:47:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:47:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:47:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:47:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:47:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:48:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:48:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:48:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:49:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:49:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:49:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:49:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:49:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:51:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:51:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:52:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:52:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:52:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:52:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:52:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:52:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:52:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:52:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:53:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:56:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:56:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:56:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:56:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:56:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:57:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:57:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:57:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:58:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:58:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:58:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:58:28 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Category.php 16
ERROR - 2020-10-30 06:59:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:59:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:59:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 06:59:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 06:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 06:59:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:00:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 07:00:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 07:00:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 07:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:00:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:00:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:00:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:00:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:00:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:00:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:00:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:00:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:00:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:01:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:01:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:01:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:02:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:02:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:02:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:03:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:03:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:03:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:03:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:04:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:04:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:04:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:04:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:04:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:05:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:05:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:05:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:06:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:06:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:06:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:07:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:08:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:08:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:08:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:08:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:08:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:09:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:09:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:09:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:09:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:09:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:09:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:09:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:09:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:09:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:09:46 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Category.php 16
ERROR - 2020-10-30 07:09:55 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Category.php 16
ERROR - 2020-10-30 07:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:10:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:10:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:11:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:11:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:11:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:12:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:12:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:12:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:13:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:13:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:13:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:14:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 07:14:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:14:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:14:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:14:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:15:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:15:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:15:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:16:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:16:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:16:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:17:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:17:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:17:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:18:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:18:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:18:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:19:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:19:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:19:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:20:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:20:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:20:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:20:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:20:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:20:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:21:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:21:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:21:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:22:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:22:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:22:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:23:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:23:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:23:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:24:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:24:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:25:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:25:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:25:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:26:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:26:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:26:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:27:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:27:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:27:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:27:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:27:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:28:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:28:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:28:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 07:29:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:29:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:29:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:30:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:30:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:30:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:31:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:31:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:31:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:32:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:32:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:32:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:33:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:33:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:33:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:34:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:34:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:34:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:35:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:35:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:36:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:36:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:36:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:36:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:36:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:37:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:37:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:37:46 --> Query error: Table 'new_gigs.term' doesn't exist - Invalid query: SELECT * FROM `term` WHERE 1
ERROR - 2020-10-30 07:37:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:37:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:38:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:38:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:38:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:38:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:39:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:39:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:39:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:40:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:40:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:40:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:41:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:41:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:42:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:42:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:43:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:43:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:44:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:44:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:44:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:45:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:45:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:45:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:46:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:46:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:46:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:47:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:47:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:47:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:48:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:48:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:48:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:49:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:49:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:49:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:54:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:54:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:54:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:54:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:54:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:55:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:55:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:55:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:56:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:56:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:56:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:56:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:56:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:56:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:56:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:57:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:57:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:57:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:57:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:58:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:58:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:58:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:59:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:59:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:59:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 07:59:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 07:59:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:00:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:00:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:00:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:01:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:01:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:01:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:01:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:02:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:02:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:02:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:02:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:03:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:03:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:03:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:04:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:04:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:04:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:05:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:05:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:05:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:06:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:06:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:06:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:06:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 08:06:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:07:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:07:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:07:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:08:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:08:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:08:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:08:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:09:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:09:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:09:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:10:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:10:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:10:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:10:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:11:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:11:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:11:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:12:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:12:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:12:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:13:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:13:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:13:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:13:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:14:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:14:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:14:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:14:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:14:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 08:15:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:15:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:15:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:16:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:16:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:16:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:17:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:17:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:17:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:18:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:18:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:18:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:19:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:19:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:20:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:20:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:20:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:21:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:21:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:21:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:22:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:22:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:22:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:23:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:23:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:23:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:24:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:24:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:25:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:25:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:25:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:26:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:26:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:26:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 08:26:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 42
ERROR - 2020-10-30 08:27:19 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 42
ERROR - 2020-10-30 08:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:27:37 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 42
ERROR - 2020-10-30 08:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:04 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 42
ERROR - 2020-10-30 08:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:33:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:56 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:33:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:14 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:22 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:33 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:36:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:49 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:49 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:49 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:51 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:53 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:36:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:36:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:55 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:55 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:36:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:58 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:58 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:36:58 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 08:37:56 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:37:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:37:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:37:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:38:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:38:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:38:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:38:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:38:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:38:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:38:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:38:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:38:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:45:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:45:14 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:45:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:45:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:45:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:45:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:48:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 45
ERROR - 2020-10-30 08:48:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:48:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:48:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:48:40 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 45
ERROR - 2020-10-30 08:48:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:23 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:49:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:30 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:49:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:43 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:49:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:49:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:49:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:50:17 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:50:30 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 46
ERROR - 2020-10-30 08:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:51:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 47
ERROR - 2020-10-30 08:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:51:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:51:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:54:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 47
ERROR - 2020-10-30 08:54:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:54:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:54:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:56:31 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 47
ERROR - 2020-10-30 08:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:57:38 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 47
ERROR - 2020-10-30 08:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:59:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:59:16 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 44
ERROR - 2020-10-30 08:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:59:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 08:59:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:00:24 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 09:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:01:40 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 43
ERROR - 2020-10-30 09:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:03:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:03:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:03:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:03:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:03:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:03:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:03:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:03:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:04:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:04:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:04:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:04:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:04:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:04:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:04:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:04:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:04:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:04:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:05:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:05:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:05:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:06:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:06:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:06:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:06:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:06:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:06:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:06:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:06:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:06:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:06:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:06:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:07:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:07:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:07:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:08:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:08:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:08:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:08:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:08:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:08:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:08:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:08:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:09:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:09:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:09:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:09:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:09:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:10:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:10:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:10:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:10:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:10:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:10:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:10:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:10:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:11:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:17:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:17:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:37:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:45:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:45:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:45:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:45:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:45:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:46:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:46:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:46:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:47:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:47:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:47:11 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:47:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:47:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:47:16 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 09:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:33 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 09:47:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:47:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:47:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:47:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:48:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:48:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:48:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:48:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 09:48:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:48:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:48:38 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:49:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:49:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 09:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:53:59 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:54:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:54:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:54:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:54:20 --> 404 Page Not Found: admin/Bgimage/edit(21)
ERROR - 2020-10-30 09:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:54:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:54:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:54:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:55:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:55:35 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:55:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:55:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:55:48 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:55:49 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 09:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:55:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:55:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:56:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 09:56:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 09:58:31 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 09:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 09:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:00:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:00:57 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:00:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:00:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:01:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:01:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:01:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:01:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:01:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:01:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:02:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:02:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:03:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:03:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:03:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:04:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:04:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:04:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:04:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:04:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:05:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:05:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:05:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:05:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:05:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:05:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:05:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:06:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:06:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:06:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:07:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:07:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:07:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:08:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:08:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:08:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:09:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:09:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:09:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:09:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:09:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:09:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:10:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:10:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:11:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:11:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:11:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:11:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:11:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:11:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:11:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:11:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:12:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:12:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:12:12 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:12:12 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:12:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:12:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:12:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:12:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:12:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:12:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:13:15 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:13:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:15:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:15:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:15:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:16:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:16:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:16:31 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:16:31 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:17:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:17:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:17:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:17:58 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:18:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:18:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 10:18:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 10:18:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 10:18:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 10:18:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:18:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:19:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 10:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:19:46 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:19:46 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:19:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:19:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:19:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:19:51 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:20:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:20:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:20:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:20:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:21:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:21:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:24:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:29:21 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:29:23 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:31:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:31:37 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 10:31:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:31:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 10:32:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:32:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:32:48 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:32:48 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:32:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:32:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:32:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:33:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:33:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:33:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:34:03 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:34:03 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 10:34:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:34:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 10:34:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:34:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:35:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:35:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:35:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:36:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:36:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:36:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:37:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:37:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:37:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:38:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:38:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:38:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:39:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:39:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:39:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:40:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:40:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:40:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:41:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:41:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:41:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:42:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:42:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 10:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:43:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:43:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:44:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:44:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:44:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:45:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:45:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:45:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:46:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:46:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:46:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:47:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:47:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:47:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:48:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:48:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:48:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:49:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:49:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:49:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:50:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:50:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:50:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:51:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:51:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:51:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:52:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:52:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:52:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:53:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:53:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:53:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:54:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:54:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 10:54:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 11:07:05 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:07:05 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:07:05 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:07:06 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:07:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:07:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:07:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:07:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:08:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:08:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:08:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:09:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:09:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:09:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:10:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:10:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:10:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:11:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:11:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:11:47 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:11:47 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:11:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:11:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:12:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:12:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:12:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:13:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:13:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:13:36 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:13:36 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:13:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:13:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:13:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:14:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:14:25 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:14:25 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:14:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:14:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:14:29 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:14:29 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 11:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:14:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:14:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:14:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:14:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:14:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:14:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:14:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:15:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:15:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:15:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:15:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:15:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:15:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:15:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:15:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:15:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:16:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:16:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:16:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:16:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:16:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:16:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:16:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:17:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:17:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:17:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:18:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:18:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:18:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:18:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:19:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:19:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:19:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:20:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:20:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:20:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:20:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:21:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:21:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:21:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:21:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:21:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:22:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:22:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:22:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:22:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:23:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:23:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:23:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:23:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:23:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:24:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:24:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:24:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:25:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:25:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:25:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:25:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:25:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:26:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:26:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:26:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:26:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:26:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:26:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:26:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 11:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:27:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:27:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:27:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 11:27:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:27:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:27:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:28:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:28:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:28:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:28:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:28:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:29:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:29:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:29:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:29:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:29:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:29:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:30:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:30:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:30:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:30:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:31:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:31:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:31:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:31:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:31:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:32:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:32:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:32:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:33:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:33:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:33:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:34:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:34:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:34:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:35:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:35:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:35:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:35:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:35:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:36:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:36:16 --> Query error: Table 'new_gigs.admin_access' doesn't exist - Invalid query: SELECT `id`
FROM `admin_access`
WHERE `admin_id` IS NULL
AND `module_id` IS NULL
AND `access` = 1
ERROR - 2020-10-30 11:36:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:36:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:36:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:36:33 --> Query error: Table 'new_gigs.admin_access' doesn't exist - Invalid query: SELECT `id`
FROM `admin_access`
WHERE `admin_id` IS NULL
AND `module_id` IS NULL
AND `access` = 1
ERROR - 2020-10-30 11:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:37:17 --> Query error: Table 'new_gigs.admin_access' doesn't exist - Invalid query: SELECT `id`
FROM `admin_access`
WHERE `admin_id` IS NULL
AND `module_id` IS NULL
AND `access` = 1
ERROR - 2020-10-30 11:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 11:39:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:39:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:39:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:39:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:39:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:39:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:39:37 --> Query error: Table 'new_gigs.admin_access' doesn't exist - Invalid query: SELECT `id`
FROM `admin_access`
WHERE `admin_id` IS NULL
AND `module_id` IS NULL
AND `access` = 1
ERROR - 2020-10-30 11:40:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:40:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:40:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:41:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:41:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:41:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:42:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:42:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:42:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:43:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:43:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:43:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:43:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:43:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:44:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:44:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:44:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:45:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:45:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:45:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:46:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:46:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:46:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:46:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:47:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:47:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:47:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:47:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:47:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:48:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:48:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:48:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:48:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:48:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:48:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:48:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:48:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:49:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:49:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:50:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:50:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 11:50:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:51:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:51:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:51:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:51:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\modules\adminlist\edit_adminlist.php 72
ERROR - 2020-10-30 11:52:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:52:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:52:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:53:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:53:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:53:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:54:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:54:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:55:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:55:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:55:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:55:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:56:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:56:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:56:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:56:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:56:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:56:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:56:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:56:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:57:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:57:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:57:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:57:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:57:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:57:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:57:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:58:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:58:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:58:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:58:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:58:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:58:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 11:58:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:58:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:58:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:59:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:59:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:59:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:59:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:59:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 11:59:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:00:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:00:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:00:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:00:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:00:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:00:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:00:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:01:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 12:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 12:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 12:02:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 12:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 12:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 12:02:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:02:33 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 12:02:33 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 12:02:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:02:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:02:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:02:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:02:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:02:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:03:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:03:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:04:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:04:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:04:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:04:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:04:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:04:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:05:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:05:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:05:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:05:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:05:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:05:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:06:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:06:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:06:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:50 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:06:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:06:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:06:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:06:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:06:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:06:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:07:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:07:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:07:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:07:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:07:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:07:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:07:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:07:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:08:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:08:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:08:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:09:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:21 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:09:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:09:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:09:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:09:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:10:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:10:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:10:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:10:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:11:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:11:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:12:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:12:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:12:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:13:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:13:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:13:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:13:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:13:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:14:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:14:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:14:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:14:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:14:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:14:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:15:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:15:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:15:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:16:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:16:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:16:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:17:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:17:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:17:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:17:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:17:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:17:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:18:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:18:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:18:17 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:18:16', '', '', '', 1, 1)
ERROR - 2020-10-30 12:18:17 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:18:17', '', '', '', 1, 1)
ERROR - 2020-10-30 12:18:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:18:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:18:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 12:19:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:19:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:19:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:20:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:20:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:20:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:20:51 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:20:51', '', '', '', 1, 1)
ERROR - 2020-10-30 12:21:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:21:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:21:39 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:21:39', '', '', '', 1, 1)
ERROR - 2020-10-30 12:21:46 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:21:46', '', '', '', 1, 1)
ERROR - 2020-10-30 12:21:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:22:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:22:28 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:22:28', '', '', '', 1, 1)
ERROR - 2020-10-30 12:22:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:22:37 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'sas', '2', NULL, '2', '0', 'Dfdfdfdf\r\n', '0', '', '', 'USD', '2020-10-30 12:22:37', '', '', '', 1, 1)
ERROR - 2020-10-30 12:22:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:23:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:23:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:23:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:23:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:23:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:23:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:23:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:23:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:24:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:24:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:24:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:24:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:24:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:24:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:24:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:24:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:24:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:24:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:25:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:25:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:25:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:26:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:26:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:26:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:26:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:26:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:27:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:27:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:27:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:27:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:27:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:27:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:28:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:28:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:28:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:28:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:28:40 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:28:40', '', '', '', 1, 1)
ERROR - 2020-10-30 12:28:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:29:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:29:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:29:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:30:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:30:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:30:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:30:54 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:30:54', '', '', '', 1, 1)
ERROR - 2020-10-30 12:30:59 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:30:59', '', '', '', 1, 1)
ERROR - 2020-10-30 12:31:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:31:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:37 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:31:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:31:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:31:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:31:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:31:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:32:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:32:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:32:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:32:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:32:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:32:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:33:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:33:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:33:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:33:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:33:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:33:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:33:55 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:33:55', '', '', '', 1, 1)
ERROR - 2020-10-30 12:33:58 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:33:58', '', '', '', 1, 1)
ERROR - 2020-10-30 12:34:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:34:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:34:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:34:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:34:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:34:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:35:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:35:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:35:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:36:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:36:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:36:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:37:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:37:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:37:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:38:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:38:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:38:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:39:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:39:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:39:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:40:08 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:40:08', '', '', '', 1, 1)
ERROR - 2020-10-30 12:40:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:40:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:40:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:40:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:41:01 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'fdfd', '1', NULL, '2', '2', 'Dfddf\r\n', '0', '', '', 'USD', '2020-10-30 12:41:01', '', '', '', 1, 1)
ERROR - 2020-10-30 12:45:13 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:45:13', '', '', '', 1, 1)
ERROR - 2020-10-30 12:45:18 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testedd', '2', NULL, '2', '5', 'Dfd\r\n', '0', '', '', 'USD', '2020-10-30 12:45:18', '', '', '', 1, 1)
ERROR - 2020-10-30 12:46:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:46:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:46:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:46:52 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'fdfddsd', '1', NULL, '2', '2', 'Asdas\r\n', '0', '', '', 'USD', '2020-10-30 12:46:52', '', '', '', 1, 1)
ERROR - 2020-10-30 12:49:21 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'fdfddsd', '1', NULL, '2', '2', 'Asdas\r\n', '0', '', '', 'USD', '2020-10-30 12:49:21', '', '', '', 1, 1)
ERROR - 2020-10-30 12:55:21 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'fdfddsd', '1', NULL, '2', '2', 'Asdas\r\n', '0', '', '', 'USD', '2020-10-30 12:55:21', '', '', '', 1, 1)
ERROR - 2020-10-30 12:55:51 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'fdfddsd', '1', NULL, '2', '2', 'Asdas\r\n', '0', '', '', 'USD', '2020-10-30 12:55:51', '', '', '', 1, 1)
ERROR - 2020-10-30 12:56:12 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'fdfddsd', '1', NULL, '2', '2', 'Asdas\r\n', '0', '', '', 'USD', '2020-10-30 12:56:12', '', '', '', 0, 1)
ERROR - 2020-10-30 12:57:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:15 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:57:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:57:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:57:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:57:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:57:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:57:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:57:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:57:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 12:57:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 12:58:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:58:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:58:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:58:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:58:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:58:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:59:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:59:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:59:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:59:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 12:59:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 12:59:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:00:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:00:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:00:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:00:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:00:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:00:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:00:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:00:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:00:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:00:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:00:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:01:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:05:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:05:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:06:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:07:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:07:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:08:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:09:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:09:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:10:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:11:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:12:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:12:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:12:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query:  SELECT * FROM `administrators` WHERE `email` =  
ERROR - 2020-10-30 13:13:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@dreamguys.co.in' at line 1 - Invalid query:  SELECT * FROM `administrators` WHERE `email` = divya.a@dreamguys.co.in 
ERROR - 2020-10-30 13:13:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@dreamguys.co.in' at line 1 - Invalid query: SELECT * FROM `administrators` WHERE `email` = divya.a@dreamguys.co.in
ERROR - 2020-10-30 13:13:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@dreamguys.co.in' at line 1 - Invalid query: SELECT * FROM `administrators` WHERE `email` = divya.a@dreamguys.co.in
ERROR - 2020-10-30 13:13:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@dreamguys.co.in' at line 1 - Invalid query: SELECT * FROM `administrators` WHERE `email` = divya.a@dreamguys.co.in
ERROR - 2020-10-30 13:16:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@dreamguys.co.in' at line 1 - Invalid query: SELECT * FROM `administrators` WHERE `email` = divya.a@dreamguys.co.in
ERROR - 2020-10-30 13:16:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:16:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:16:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:16:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:17:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@dreamguys.co.in' at line 1 - Invalid query: SELECT * FROM `administrators` WHERE `email` = divya.a@dreamguys.co.in
ERROR - 2020-10-30 13:18:09 --> Severity: error --> Exception: Call to undefined method Dashboard::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 334
ERROR - 2020-10-30 13:18:51 --> Severity: error --> Exception: Call to undefined method Dashboard::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 334
ERROR - 2020-10-30 13:21:24 --> Severity: error --> Exception: Call to undefined method Dashboard::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 334
ERROR - 2020-10-30 13:21:34 --> Severity: error --> Exception: Call to undefined method Dashboard::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 334
ERROR - 2020-10-30 13:24:45 --> Severity: error --> Exception: Call to undefined method Dashboard::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 333
ERROR - 2020-10-30 13:25:08 --> Severity: error --> Exception: Call to undefined method Dashboard::decryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 333
ERROR - 2020-10-30 13:25:29 --> Severity: error --> Exception: Call to undefined method Dashboard::encryptor() D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 337
ERROR - 2020-10-30 13:25:43 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 343
ERROR - 2020-10-30 13:25:48 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 343
ERROR - 2020-10-30 13:34:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:34:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:34:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:17 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:34:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:34:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:34:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:34:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:34:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:34:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:34:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:34:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:34:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:35:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:35:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:35:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:36:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:36:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:36:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:37:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:37:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:37:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:38:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:38:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:39:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:39:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:39:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:40:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:40:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:40:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:40:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:40:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:40:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:41:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:41:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:41:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:41:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:41:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:41:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:42:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:42:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:42:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:42:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:42:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:42:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:42:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:42:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:42:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:42:41 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:42:41 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:42:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:42:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:42:50 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:42:50 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:42:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:42:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:42:56 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 13:43:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:43:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:43:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:43:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:43:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:44:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:44:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:44:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:44:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:44:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:44:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:45:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:45:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:45:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:46:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:46:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:46:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:47:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:47:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:47:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:48:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:48:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:48:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:48:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:48:48 --> 404 Page Not Found: admin/Adminlist/delete_adminlist
ERROR - 2020-10-30 13:48:54 --> 404 Page Not Found: admin/Adminlist/delete_adminlist
ERROR - 2020-10-30 13:49:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:49:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:49:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:49:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:49:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:50:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:50:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:51:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:51:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:51:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:51:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:51:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:51:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:52:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:52:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:52:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:53:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:53:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:53:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:53:58 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:53:58 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:53:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:54:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:06 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:54:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:54:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:54:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:54:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:54:56 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 13:54:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:54:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:55:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:55:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:55:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:55:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:55:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:55:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:55:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:55:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 13:55:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:56:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-30 13:56:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:56:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:57:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:57:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:57:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 13:57:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:58:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:58:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:58:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:58:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:58:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:58:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 13:58:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 13:58:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:58:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:59:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:59:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 13:59:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:00:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:00:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:00:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:01:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:01:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:29 --> 404 Page Not Found: Img/gigs_ad_red.png
ERROR - 2020-10-30 14:01:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:01:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:01:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:02:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:02:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:16 --> 404 Page Not Found: Img/gigs_ad_red.png
ERROR - 2020-10-30 14:02:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:02:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:37 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:40 --> 404 Page Not Found: Img/gigs_ad_red.png
ERROR - 2020-10-30 14:02:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:02:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:02:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:03:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:03:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:03:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:03:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:03:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:03:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:03:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:03:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:04:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:04:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:04:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:04:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:04:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:04:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:05:11 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-30 14:05:12 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-30 14:05:13 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-30 14:05:14 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:05:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:05:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:05:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:05:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:05:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:05:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:06:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:06:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:06:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:06:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:06:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:06:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:06:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:06:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:06:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:07:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:07:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:07:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:07:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:07:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:07:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:08:17 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-30 14:08:17 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:08:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:08:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:08:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:08:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:08:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:08:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:08:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:09:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:09:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:09:45 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:09:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:09:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:09:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:09:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:09:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:09:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:10:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:10:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:10:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:10:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:10:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:10:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:10:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:11:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:11:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:11:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:12:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:12:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:12:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:13:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:13:12 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:13:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:13:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:13:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:13:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:13:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:13:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:13:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:14:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:14:20 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:14:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:14:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:14:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:37 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:14:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:14:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:15:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:15:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:15:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:16:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:16:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:16:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:16:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:16:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:16:37 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:16:37 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:16:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:17:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:17:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:17:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:18:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:18:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:18:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:18:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:18:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:19:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:19:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:19:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:20:42 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:21:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:21:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:21:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:21:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:21:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:23:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:23:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:23:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:23:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:23:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:25:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:25:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:25:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:25:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:25:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:26:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:26:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:26:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:27:15 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:27:16 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:27:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:27:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:27:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:27:49 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:27:49 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:27:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:27:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:27:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:27:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:28:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:28:27 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:28:27 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:28:27 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:28:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:28:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:28:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:29:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:29:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:29:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:30:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:30:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:30:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:31:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:31:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:31:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:31:52 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:31:52 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:31:53 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:31:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:31:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:32:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:32:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:32:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:32:39 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:32:40 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:32:40 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:32:40 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:32:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:32:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:32:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:32:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:33:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:33:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:33:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:33:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:33:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:33:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:33:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:33:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:33:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:33:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:34:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:34:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:34:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:35:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:35:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:35:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:36:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:36:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:36:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:36:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:36:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:36:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:36:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:36:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:36:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:36:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:36:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:36:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:37:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:37:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:37:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:37:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:37:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:37:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:37:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:38:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:38:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:38:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:38:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:38:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:39:09 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\thegigs_web\application\views\user\modules\gigs\index.php 58
ERROR - 2020-10-30 14:39:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:39:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:39:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:40:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:40:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:40:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:40:35 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\thegigs_web\application\views\user\modules\gigs\index.php 58
ERROR - 2020-10-30 14:40:44 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\thegigs_web\application\views\user\modules\gigs\index.php 58
ERROR - 2020-10-30 14:40:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:40:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:40:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:40:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:40:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:41:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:41:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:41:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:41:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:41:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:42:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:42:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:42:39 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:42:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:42:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:42:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:42:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:42:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:42:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:42:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:42:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-30 14:43:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-30 14:43:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:43:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:43:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:44:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:44:03 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:44:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:44:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:44:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:44:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:45:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:45:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:45:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:45:50 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:45:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:45:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:45:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-30 14:46:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:46:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:46:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:51:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:51:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:51:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:52:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:52:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:52:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:52:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:52:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:52:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:52:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:53:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:53:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:53:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:54:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:55:47 --> 404 Page Not Found: admin/Bgimage/edit
ERROR - 2020-10-30 14:55:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:55:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:55:59 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 14:56:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 14:56:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 14:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 17
ERROR - 2020-10-30 14:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 14:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-30 15:04:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:04:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:04:05 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 15:04:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:04:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:04:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\category\edit_bgimg.php 17
ERROR - 2020-10-30 15:04:39 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\category\edit_bgimg.php 17
ERROR - 2020-10-30 15:06:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:06:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:06:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:06:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:07:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:07:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:07:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:07:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:07:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:07:21 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 15:07:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:07:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:07:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:07:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:07:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:08:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:08:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:08:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:08:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:08:36 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-30 15:08:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:08:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:08:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:08:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:09:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:09:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:09:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:10:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:10:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:10:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:11:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:11:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:11:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:11:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:12:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:12:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:12:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:12:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 17
ERROR - 2020-10-30 15:13:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:13:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:13:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:13:49 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 17
ERROR - 2020-10-30 15:14:39 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 17
ERROR - 2020-10-30 15:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:15:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:16:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 17
ERROR - 2020-10-30 15:17:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:17:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:17:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:17:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:18:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:18:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-30 15:18:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-30 15:18:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 19
ERROR - 2020-10-30 15:20:18 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit_bgimg.php 19
