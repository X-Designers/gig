<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-27 09:09:37 --> Query error: Table 'new_gigs.system_settings' doesn't exist - Invalid query: select * from system_settings WHERE status = 1
ERROR - 2020-10-27 09:12:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:12:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 09:13:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:13:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:14:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:14:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:14:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:14:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:15:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:15:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:15:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:15:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:15:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:15:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:15:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:15:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:15:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:16:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:16:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:16:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:17:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:17:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:17:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:18:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:18:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:18:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:19:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:19:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:20:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:20:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:21:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:21:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:21:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:21:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:21:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:21:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:22:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:22:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:22:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:23:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:23:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:23:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:24:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:24:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:24:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:25:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:25:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:25:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:26:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:26:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:26:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:27:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:27:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:27:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:27:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:27:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:27:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:28:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:28:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:28:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:29:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:29:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:29:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:30:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:30:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:30:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:30:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:31:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:31:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:31:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:32:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:32:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:32:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:33:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:33:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:33:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:34:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:34:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:34:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:35:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:35:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:35:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:36:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:36:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:36:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:37:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:37:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:37:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:38:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:38:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:38:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:39:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:39:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:39:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:40:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:40:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:41:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:41:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:41:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:42:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:42:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:52:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:52:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 09:52:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:53:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:53:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:53:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:54:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:54:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:55:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:55:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:55:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:56:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:56:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:56:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:57:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:57:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:57:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:58:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:58:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:59:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 09:59:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:00:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:00:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:00:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:01:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:01:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:02:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:02:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:02:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:03:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:03:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:27:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:27:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:27:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:27:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:27:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:27:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:27:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:27:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:27:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:28:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:28:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:28:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:29:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:29:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:29:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:30:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:30:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:30:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:31:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:31:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:31:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:32:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:32:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:32:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:33:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:33:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:33:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:34:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:34:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:34:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:35:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:35:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:35:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:35:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:36:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:36:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:36:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:37:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:37:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:37:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:37:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:37:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:38:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:38:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:38:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:38:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:39:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:39:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-27 10:39:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:40:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:40:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:40:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:41:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:41:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-27 10:41:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:41:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:42:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:42:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:42:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:43:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:43:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:43:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:44:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:44:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:44:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:45:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:45:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:45:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:46:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:46:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:46:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:47:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:47:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:47:33 --> Query error: Column 'user_timezone' cannot be null - Invalid query: INSERT INTO `members` (`username`, `password`, `email`, `fullname`, `country`, `state`, `user_timezone`, `created_date`, `verified`, `reference_code`, `status`) VALUES ('divya14', '564edc834f67b69ee17ecf749167789d192f101d55b3d5195e8739bdd6e6b98662223b6a321ba57fdcfa4da2642f859054f17391c21409ad080c0b754f5a384eWYQBcjwdSWGnvjnZuuZWoAg2COBsOo0sHhyHN580ZGs=', 'divyait145@gmail.com', 'Divyaar', '101', '35', NULL, '2020-10-27 10:47:33', 1, 896032, 1)
ERROR - 2020-10-27 10:47:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:48:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:48:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:48:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:49:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:49:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:49:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:49:49 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\modules\gigs\index.php 19
ERROR - 2020-10-27 10:49:53 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\modules\gigs\index.php 19
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:51:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:51:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:51:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:51:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:52:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:52:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-27 10:52:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:53:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:53:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:53:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:53:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 10:54:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 10:54:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:54:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:54:52 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-27 10:54:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:54:56 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-27 10:55:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:55:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:55:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:56:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:56:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:56:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:57:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:57:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:57:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:58:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:58:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:58:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:59:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:59:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 10:59:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:00:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:00:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:00:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:01:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:01:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:01:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:02:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:02:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:02:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:03:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:03:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:03:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:04:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:04:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:05:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:14:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:14:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:14:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:14:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:14:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:14:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:15:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:15:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:15:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:16:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:16:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:16:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:16:38 --> 404 Page Not Found: admin/Bgimage/index
ERROR - 2020-10-27 11:17:38 --> 404 Page Not Found: admin/Bgimage/index
ERROR - 2020-10-27 11:17:40 --> 404 Page Not Found: admin/Bgimage/index
ERROR - 2020-10-27 11:19:28 --> 404 Page Not Found: admin/Bgimage/index
ERROR - 2020-10-27 11:19:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:19:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:19:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:19:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:20:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:20:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:20:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:20:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:21:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:21:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:21:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:22:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:22:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:22:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:23:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:23:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:23:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:24:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:24:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:24:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:24:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:24:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:24:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:24:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:25:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:25:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:25:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:25:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:25:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:25:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:25:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:25:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:26:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:26:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:26:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:27:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:27:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:27:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:28:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:28:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:28:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:29:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:29:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:29:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:30:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:30:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:30:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:31:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:31:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:31:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:32:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:32:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:32:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:33:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:33:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:33:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:34:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:34:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:34:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:35:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:35:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:35:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:36:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:36:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:36:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:37:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:37:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:37:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:37:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:37:48 --> 404 Page Not Found: admin/Admin_list/index
ERROR - 2020-10-27 11:37:50 --> 404 Page Not Found: admin/Admin_list/index
ERROR - 2020-10-27 11:37:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:38:05 --> 404 Page Not Found: admin/Admin_list/index
ERROR - 2020-10-27 11:38:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:38:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:38:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:38:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:38:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:38:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:39:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:39:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:39:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:40:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:40:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:40:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:40:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:41:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:41:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:41:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 11:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:42:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:42:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:43:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:43:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:43:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:44:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:44:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:44:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:45:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:45:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:45:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:46:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:46:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:46:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:47:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:47:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:47:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:47:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:48:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:48:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:48:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:49:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:49:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:49:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:50:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:50:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:50:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:51:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:51:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:51:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:52:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:52:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:52:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:53:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:53:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:53:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:54:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:54:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:54:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:55:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:55:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:55:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:56:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:56:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-27 11:56:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:57:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:57:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:57:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:58:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:58:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:58:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:59:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:59:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 11:59:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:59:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 11:59:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 11:59:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:00:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:00:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:00:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:00:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:01:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:01:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:01:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:01:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:01:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:02:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:02:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 12:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 12:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 12:02:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:03:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:03:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:03:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:04:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` =' at line 1 - Invalid query:  UPDATE `sell_gigs` SET `status` =  WHERE `id` =  
ERROR - 2020-10-27 12:04:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:04:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:04:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:05:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:05:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:05:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:06:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:06:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:06:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:07:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:07:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:07:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:08:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:08:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:08:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:09:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:09:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:09:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:10:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:10:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:10:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:11:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:11:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:11:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:12:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:12:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:12:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:13:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:13:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:13:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:14:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:19:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:19:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:20:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:20:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:20:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:21:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:21:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:21:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:22:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:22:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:22:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:23:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:23:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:23:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:24:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:24:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:24:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:24:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:24:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:24:39 --> 404 Page Not Found: admin/Admin_list/index
ERROR - 2020-10-27 12:41:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:41:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:41:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'key='auto_approval'' at line 1 - Invalid query: select * from system_settings WHERE status = 1 and key='auto_approval'
ERROR - 2020-10-27 12:41:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'key='auto_approval'' at line 1 - Invalid query: select * from system_settings WHERE status = 1 and key='auto_approval'
ERROR - 2020-10-27 12:41:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` =' at line 1 - Invalid query:  UPDATE `sell_gigs` SET `status` =  WHERE `id` =  
ERROR - 2020-10-27 12:43:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:43:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:43:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:43:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:44:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:44:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:44:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:44:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:44:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:44:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:45:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:45:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:45:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:46:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:46:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\thegigs_web\application\views\admin\modules\gigs\index.php 13
ERROR - 2020-10-27 12:46:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:46:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\thegigs_web\application\views\admin\modules\gigs\index.php 13
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:46:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:46:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:47:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:47:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:47:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:48:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:48:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:48:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:49:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:49:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:49:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:50:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:50:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:50:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:51:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:51:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:51:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:52:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:52:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:52:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:53:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:53:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:53:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:54:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:54:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:54:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:55:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:55:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-27 12:55:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:56:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:56:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:56:45 --> Severity: Warning --> Use of undefined constant resultsys - assumed 'resultsys' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\thegigs_web\application\views\admin\modules\gigs\index.php 13
ERROR - 2020-10-27 12:56:45 --> Severity: Warning --> Illegal string offset 'status' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\gigs\index.php 13
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:56:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:56:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:57:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 12:57:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:57:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 12:57:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:57:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:58:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:58:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:58:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:59:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:59:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 12:59:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'key='auto_approval'' at line 1 - Invalid query: select * from system_settings WHERE status = '1' and key='auto_approval'
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:00:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:00:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:00:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:01:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:01:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:01:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:02:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:02:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:02:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:03:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:03:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:03:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:04:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:04:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:04:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:04:55 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Gigs.php 47
ERROR - 2020-10-27 13:04:55 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Gigs.php 47
ERROR - 2020-10-27 13:04:55 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Gigs.php 47
ERROR - 2020-10-27 13:04:57 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Gigs.php 47
ERROR - 2020-10-27 13:05:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:05:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:05:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:05:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:06:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:06:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:06:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:07:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:07:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:07:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:08:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:08:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:08:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:09:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:09:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:10:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:10:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:11:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:11:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:11:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:11:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:11:17 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:11:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:12:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:12:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:12:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:12:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:13:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:13:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:13:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:13:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:14:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:14:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:14:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:15:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:15:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:15:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:16:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:16:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:16:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:16:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:16:24 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:16:30 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:16:34 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:16:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:17:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:17:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:17:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:18:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:18:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:19:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:19:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:20:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:20:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:20:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:21:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:21:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:21:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:22:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:22:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:22:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:23:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:23:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:23:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:24:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:24:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:25:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:25:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:25:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:25:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-27 13:27:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-27 13:28:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:43:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:43:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:43:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:43:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:44:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:44:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:44:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:44:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:44:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:44:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:45:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:45:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:45:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:46:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:46:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:46:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:47:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:47:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:47:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:48:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:48:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:49:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:49:17 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Gigs.php 123
ERROR - 2020-10-27 13:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:51:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:51:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:51:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:52:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:52:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:52:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:53:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:53:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:53:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:54:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:54:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:54:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:55:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:55:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:55:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:56:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:56:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:56:10 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:56:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:56:31 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 0 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:56:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:57:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-27 13:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:57:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:57:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:57:20 --> Query error: Unknown column 'auto_approval' in 'where clause' - Invalid query:  UPDATE `sell_gigs` SET `status` = 1 WHERE `id` = auto_approval 
ERROR - 2020-10-27 13:57:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:57:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-27 13:58:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:58:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:58:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:58:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:58:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:58:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 13:59:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 13:59:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:00:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:00:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:00:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:01:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:01:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:01:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:01:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:02:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:02:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:03:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:03:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:03:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:03:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:04:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:04:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:04:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:05:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:05:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:05:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:06:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:06:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:07:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:07:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:08:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:08:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:08:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:08:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:26:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `id` =' at line 1 - Invalid query:  UPDATE `sell_gigs` SET `status` =  WHERE `id` =  
ERROR - 2020-10-27 14:26:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:26:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-27 14:27:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:27:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:27:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:28:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:28:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:28:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:29:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:29:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:29:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:30:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:30:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:30:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:31:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:31:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:31:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:32:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:32:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:32:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:33:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:33:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:33:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:34:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:34:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:34:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:35:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:35:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:35:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:36:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:36:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:36:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:37:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:38:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:38:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:38:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:39:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:39:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:40:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:40:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:40:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:41:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:41:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:42:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:42:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:43:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:43:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:44:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:44:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-27 14:45:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
