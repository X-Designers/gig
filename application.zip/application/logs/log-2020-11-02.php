<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-02 04:56:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 04:56:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 04:56:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 04:56:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:00:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:00:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:00:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 05:00:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:01:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:01:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:01:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:02:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:02:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:02:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:03:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:03:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:03:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:04:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:04:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:04:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:05:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:05:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:05:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:06:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:06:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:06:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:06:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:06:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:06:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:07:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:07:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:08:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:08:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:08:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:09:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:09:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:09:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:10:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:10:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:10:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:10:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:10:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:11:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:11:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:11:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:12:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:12:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:14:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:14:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:15:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:15:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:15:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:16:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:16:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:16:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:16:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:16:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:16:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:16:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:16:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:16:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:17:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:17:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:17:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:18:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:18:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:18:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:19:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:19:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:19:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:19:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:20:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:20:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:20:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:21:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:21:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:21:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:22:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:22:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:22:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:23:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:23:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:23:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:24:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:24:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:24:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:25:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:25:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:25:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:26:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:26:27 --> 404 Page Not Found: @@@@@@@@@/index
ERROR - 2020-11-02 05:26:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:26:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:26:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:27:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:27:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:27:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:27:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:27:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:28:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:28:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:28:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:29:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:29:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:29:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:30:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:30:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:30:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:31:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:31:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:31:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:32:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:32:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:32:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:32:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:33:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:33:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:33:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:33:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:34:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:34:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:34:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:35:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:35:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:35:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:36:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:36:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:36:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:37:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:37:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:37:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:37:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:38:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:38:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:39:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:39:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:39:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:40:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:40:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:40:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:41:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:41:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:41:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:42:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:42:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:42:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:43:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:43:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:44:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:44:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:44:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:45:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:45:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:45:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:46:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:46:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:46:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:46:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:47:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:47:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:47:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:47:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:48:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:48:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:48:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:48:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:48:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:48:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:48:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:49:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:49:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:49:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:49:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:49:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:49:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:50:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:50:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:50:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 05:50:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:50:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:50:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:50:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:51:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:51:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:51:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:51:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:51:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:52:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:52:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:52:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:52:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:52:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:52:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:53:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:53:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:53:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:53:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:53:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:53:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:54:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:54:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:54:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:54:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:54:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:54:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:55:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:55:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:55:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:55:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:55:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:55:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:56:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:56:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:56:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:56:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:56:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:57:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:57:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:57:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:57:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:58:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:58:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:58:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:59:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:59:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 05:59:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:00:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:00:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:00:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:01:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:01:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:01:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:02:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:02:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:02:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 06:03:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:37:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 07:37:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 07:37:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 07:37:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:37:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 07:37:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 07:37:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:38:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:38:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:39:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:39:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:39:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:40:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:40:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:40:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:41:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:41:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:41:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:42:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:42:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:42:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:43:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:43:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:43:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:44:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:44:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:44:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:45:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:45:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:45:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:46:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:46:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:46:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:47:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:47:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:47:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:48:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:48:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:49:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:49:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:49:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:50:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:50:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:50:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:51:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:51:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:52:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:52:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:53:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:53:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:53:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:54:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:54:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:54:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:55:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:55:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:55:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:56:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 07:56:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:03:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 D:\xampp\htdocs\thegigs_web\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-11-02 08:03:26 --> Unable to connect to the database
ERROR - 2020-11-02 08:09:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 08:10:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:10:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:10:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:10:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:11:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:11:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:11:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:12:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:12:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:12:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:13:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:13:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:13:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:14:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:14:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:14:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:15:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:15:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:15:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:16:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:16:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:17:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:17:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:17:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:18:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:18:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:18:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:18:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:19:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:19:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:19:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:20:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:20:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:21:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:21:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:26:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:26:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 08:26:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:27:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:27:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:27:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:28:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:28:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:28:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:29:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:29:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:29:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:30:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:30:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:30:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:31:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:31:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:31:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:32:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:32:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:32:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:33:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:33:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:33:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:34:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:34:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:34:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:35:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:35:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:35:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:36:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:36:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:36:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:37:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:37:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:37:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:38:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:38:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:38:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:52:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:52:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 08:52:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:53:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:53:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:53:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:54:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:54:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:54:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:55:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:55:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:55:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:56:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:56:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:56:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:57:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:57:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:57:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:58:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:58:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:58:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:59:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:59:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 08:59:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:00:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:00:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:00:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:01:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:01:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:01:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:02:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:02:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:02:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:03:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:03:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:03:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:04:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:04:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:04:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:04:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:05:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:05:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:05:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:05:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:05:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:05:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:05:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:06:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:06:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:06:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:07:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:07:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:07:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:07:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:07:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:07:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:07:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:07:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:08:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:08:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:08:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:09:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:09:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:09:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:10:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:10:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:10:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:11:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:11:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:11:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:12:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:12:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:12:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:12:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:12:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 09:12:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:12:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:12:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:13:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:13:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:13:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:13:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:13:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:14:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:14:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:14:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:15:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:15:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:15:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:15:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:16:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:16:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:16:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:16:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:17:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:17:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:17:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:17:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:17:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:17:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:17:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:18:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:18:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:18:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:19:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:19:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:20:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:20:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:20:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:21:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:21:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:21:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:22:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:22:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:22:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:23:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:23:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:23:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:24:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:24:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:24:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:24:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:24:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:24:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:24:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:25:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:25:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:25:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:25:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 09:25:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:25:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:26:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:26:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:26:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:27:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:27:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:27:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:28:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:28:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:28:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:29:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:29:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:29:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:30:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:30:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:30:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:31:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:31:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:31:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:32:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:32:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:32:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:33:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:33:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:33:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:34:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:34:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:34:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:35:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:35:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:35:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:36:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:36:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:36:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 09:37:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:03:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:03:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 10:03:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:03:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:04:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:04:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:04:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:05:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:05:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:05:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:06:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:06:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:06:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:07:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:07:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:07:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:08:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:08:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:09:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:09:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:09:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:09:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:10:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:10:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:11:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:11:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:11:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:12:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:12:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:12:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:13:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:38:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:38:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 10:38:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:39:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:39:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:39:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:40:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:40:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:41:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:41:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:41:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:42:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:42:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:42:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:43:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:43:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:43:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:44:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:44:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:44:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:45:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:45:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:45:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:46:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:46:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:46:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:47:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:47:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:47:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:55:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:55:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 10:55:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:55:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:56:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:56:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:56:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:57:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:57:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:57:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:58:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:58:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:58:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:59:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:59:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 10:59:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:00:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:00:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:00:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:00:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 11:00:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 11:00:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 11:00:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 11:00:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:01:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:01:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:02:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:02:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:02:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:03:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:03:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:03:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:04:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:04:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:04:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:05:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:05:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:05:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:06:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:06:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:06:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:07:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:07:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:08:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:08:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:08:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:08:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 11:08:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:09:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:09:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:09:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:10:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:10:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:10:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:11:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:11:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:12:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:12:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:12:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:13:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:13:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:14:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:14:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:14:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:15:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:16:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:16:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:16:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:16:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:16:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:17:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:17:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:17:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:18:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:18:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:18:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:19:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:19:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:19:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 11:19:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:28 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:19:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:19:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:19:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:20:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:20:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:21:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:22:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:22:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:22:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:22:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:22:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:22:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:22:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:22:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:22:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:22:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:23:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:23:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:23:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:23:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:23:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:23:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:23:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:24:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:24:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:24:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:24:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:24:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:25:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:25:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:25:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:26:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:26:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:26:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:26:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:27:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:27:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:27:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:27:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:27:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:27:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:27:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 11:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 11:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 11:28:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:28:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:28:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:29:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:29:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:30:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:30:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:30:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:31:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:31:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:31:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:31:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:32:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:32:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:32:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:33:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:33:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:33:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:34:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:34:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 11:34:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:35:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:35:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:35:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:37 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:35:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:35:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:36:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:36:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:36:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:37:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:37:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:37:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:38:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:38:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:38:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:39:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:39:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:39:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:39:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:39:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:39:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:49 --> 404 Page Not Found: Assets/img
ERROR - 2020-11-02 11:39:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:39:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:39:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:40:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:40:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:40:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:40:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:41:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:41:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:41:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:41:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:41:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:41:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:41:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:42:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:42:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:42:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:42:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:43:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:43:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:43:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:44:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-11-02 11:44:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:44:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:44:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:44:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 11:57:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:57:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:57:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:57:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:57:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 11:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 11:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:02:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:02:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:02:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:02:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:03:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:03:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:03:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:04:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:04:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:04:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:04:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:04:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:05:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:05:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:05:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:06:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:06:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:06:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:07:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:27 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:07:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:07:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:07:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:08:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:08:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:08:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:15 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:08:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:08:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:08:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:08:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:08:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:09:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:09:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:09:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:10:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:10:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:10:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:21 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:10:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:10:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:11:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:11:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:15 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:11:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:29 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:11:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:11:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:12:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:13:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:13:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:13:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:13:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:13:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:14:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:15:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:19:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:20:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:20:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:21:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:21:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:22:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:22:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:22:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:23:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:23:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:23:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:24:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:24:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:24:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:24:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:24:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:24:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:24:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:24:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:24:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:25:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:25:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:25:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:25:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:26:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:26:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:26:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:26:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:27:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:27:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:27:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:28:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:28:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:29:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:29:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:30:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:30:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:30:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:30:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:31:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:31:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:31:33 --> 404 Page Not Found: admin/Language/updatedefault_language
ERROR - 2020-11-02 12:31:40 --> 404 Page Not Found: admin/Language/updatedefault_language
ERROR - 2020-11-02 12:31:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:32:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:32:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:32:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:32:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:32:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:32:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:32:28 --> 404 Page Not Found: admin/Language/updatedefault_language
ERROR - 2020-11-02 12:32:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:32:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:32:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:32:59 --> 404 Page Not Found: admin/Language/updatedefault_language
ERROR - 2020-11-02 12:33:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:33:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:36:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:36:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:36:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:37:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:37:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:37:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:38:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:38:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:38:19 --> 404 Page Not Found: admin/Language/updatedefault_language
ERROR - 2020-11-02 12:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:38:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:39:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:39:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:39:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:40:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:40:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:40:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:40:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:40:38 --> 404 Page Not Found: Pages/index
ERROR - 2020-11-02 12:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:41:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:41:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:42:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:17 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:42:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:42:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:42:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-11-02 12:42:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:42:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:43:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:43:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:43:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 12:43:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:43:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:44:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:44:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:44:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:45:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:45:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:45:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:46:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:46:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:46:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 12:46:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 12:46:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:47:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:47:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:47:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:48:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:48:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:48:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:49:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:49:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:49:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:50:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:50:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:50:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:51:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:51:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:51:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:52:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:52:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:52:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:53:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:53:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:53:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:54:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:54:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:54:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:55:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:55:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 12:55:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 13:00:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-11-02 14:00:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:00:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:00:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:00:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:00:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:01:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:01:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:01:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:01:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:01:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-11-02 14:01:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:01:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:01:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:01:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:01:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:01:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:02:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:02:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:02:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:02:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:02:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:02:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:02:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:03:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:03:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:03:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:04:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:04:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:04:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:05:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:05:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:05:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:05:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:05:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:06:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:06:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:06:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:07:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:07:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:07:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:08:11 --> Query error: Table 'new_gigs.term' doesn't exist - Invalid query: SELECT * FROM `term` WHERE 1
ERROR - 2020-11-02 14:08:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:08:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:08:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:09:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:09:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:09:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:09:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:09:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:09:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:09:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:10:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:10:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:10:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:10:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:10:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:10:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:10:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:10:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:11:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:11:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:11:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:12:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:12:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:12:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:13:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:13:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:13:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:14:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:14:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:14:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:15:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:15:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:15:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:16:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:16:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:17:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:17:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:17:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:17:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:17:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:17:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:17:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:18:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:18:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:18:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:18:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:18:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:18:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:19:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:19:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:19:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:19:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:19:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:19:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:20:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:20:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:20:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:20:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:21:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:21:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:21:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:22:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:22:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:22:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:23:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:23:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:23:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:24:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:24:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:24:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:25:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:25:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:25:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:26:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:26:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:26:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:27:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:27:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:29:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:29:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:29:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:29:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:30:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:30:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:30:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:31:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:31:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:31:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:32:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:32:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:32:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:33:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:33:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:33:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:34:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:34:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:34:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:35:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:35:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:35:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:36:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:36:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:36:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:37:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:37:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:37:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:38:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:38:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:38:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:39:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:39:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:39:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:39:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:39:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:40:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:40:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:40:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:40:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:40:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:40:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:40:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:40:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:40:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:40:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:40:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:41:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:41:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:41:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:41:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:41:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:41:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:41:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:41:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:41:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:41:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:42:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:42:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:42:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:42:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:42:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:42:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:42:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:42:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:42:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:42:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:42:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:42:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:43:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:43:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:43:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:43:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:44:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:44:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:44:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:45:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:45:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:45:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:46:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:46:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:46:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:47:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:47:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:47:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:48:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:48:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:48:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:48:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:49:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:49:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:49:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:49:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:50:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:50:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:50:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:50:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:50:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:50:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:50:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:50:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:50:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:51:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:51:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:51:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:51:59 --> Query error: Table 'new_gigs.wallet_withdraw' doesn't exist - Invalid query: SELECT a . * , s.fullname AS user_name
                                    FROM  `wallet_withdraw` AS a
                                    LEFT JOIN members AS s ON s.USERID = a.user_id
                                    WHERE a.status = 1 ORDER BY a.`id` DESC 
ERROR - 2020-11-02 14:52:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:52:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:52:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:52:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:52:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:52:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:52:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:52:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:52:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:52:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:53:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:54:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:54:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:54:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:54:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:54:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:54:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:55:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:55:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:55:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:56:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:56:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:57:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:57:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:58:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:58:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-11-02 14:58:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:59:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:59:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:59:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 14:59:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:00:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:00:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:00:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:00:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:00:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:00:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:01:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:02:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:02:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:02:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:02:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:02:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:02:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:03:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:03:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:03:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:03:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:03:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:03:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:04:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:04:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:04:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:04:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:04:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:04:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:05:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:05:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:05:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:05:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:05:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:05:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-11-02 15:07:33 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:08:00 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:08:23 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Emailtemplate.php 32
ERROR - 2020-11-02 15:10:09 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:10:27 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:14:50 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:15:02 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:15:33 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:15:49 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:16:03 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:16:11 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:16:20 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:16:26 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:16:33 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:16:44 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:17:19 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:17:32 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:18:57 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:31:37 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:31:42 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:32:06 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:32:44 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 15:32:51 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 16:02:46 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 16:02:52 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 16:02:56 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
ERROR - 2020-11-02 16:02:58 --> Severity: Notice --> Undefined index: ip_city D:\xampp\htdocs\thegigs_web\application\controllers\Ajax.php 19
