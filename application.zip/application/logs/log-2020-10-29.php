<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-29 05:13:22 --> 404 Page Not Found: Uploads/gig_images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-29 05:13:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:40 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 05:13:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:13:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:13:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 05:14:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:14:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:14:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:15:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:15:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:15:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:16:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:16:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:16:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:17:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:17:21 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 05:17:40 --> 404 Page Not Found: admin/Adminlist/forget_passwd
ERROR - 2020-10-29 05:26:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 05:26:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 05:27:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 05:28:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 05:35:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:35:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 05:35:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 05:35:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 05:35:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:36:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:36:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:36:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:37:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:37:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:37:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:38:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:38:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:38:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:39:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:39:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:39:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:40:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:40:25 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 05:40:30 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 05:40:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:40:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:41:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:41:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:41:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:42:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:42:16 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 05:42:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 05:42:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 06:09:37 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 06:19:25 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 06:19:38 --> 404 Page Not Found: admin/Forget_passwd/index
ERROR - 2020-10-29 06:20:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:22:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:23:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:23:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:24:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:24:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:25:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:25:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:25:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:25:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:26:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:26:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:26:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:27:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:27:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:27:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:28:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:28:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:28:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:21 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:28:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:28:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:28:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:29:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:29:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:29:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:29:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:30:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:30:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:30:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:31:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:31:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:31:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:32:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:32:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:32:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:33:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:33:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:33:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:33:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:33:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:33:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:34:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:34:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:34:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:35:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:35:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:35:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:35:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:35:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:35:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:35:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:36:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:36:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:36:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:36:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:36:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:36:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:36:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:36:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:37:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:37:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:37:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:38:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:38:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:38:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:25 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:38:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:38:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:38:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:38:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:39:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:39:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:39:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:39:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:40:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:40:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:35 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:35 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:36 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:39 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:39 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:40 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:40 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:41 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:41 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:40:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:40:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:41:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:41:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:41:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:42:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:42:08 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\thegigs_web\application\views\admin\modules\bgimage\edit.php 17
ERROR - 2020-10-29 06:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:42:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:42:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:42:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:42:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:42:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:42:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:42:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:50 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:42:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:42:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:42:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:43:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:43:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:43:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:43:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:43:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:43:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:44:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:44:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:44:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:45:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:45:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:45:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:45:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:45:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:45:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:45:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:45:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:46:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:46:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:46:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:46:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:46:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:46:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:46:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:46:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:47:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:47:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:47:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:48:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:48:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:48:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:49:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:49:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:49:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:49:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:49:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:49:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:55 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:49:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:49:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:49:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:49:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:50:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:50:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:50:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:50:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:50:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:50:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:50:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:51:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:51:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:51:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:52:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 06:52:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:04 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:52:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:10 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:10 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:11 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:52:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:52:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:56 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:52:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:53:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 06:53:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 06:53:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:53:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 06:53:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:53:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:54:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:54:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:54:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:55:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:55:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:55:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:56:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:56:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:56:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:57:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:57:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:57:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:58:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:58:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:58:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:59:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:59:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 06:59:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:00:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:00:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:00:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:01:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:01:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:02:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:02:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:02:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:03:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:03:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:03:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:04:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:04:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:04:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:05:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:05:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:05:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:06:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:06:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:06:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:07:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:07:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:07:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:08:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:08:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:08:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:09:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:09:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:09:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:09:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:09:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:10:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:10:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:10:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:11:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:11:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:11:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:12:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:12:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:12:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:13:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:13:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:13:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:14:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:14:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:14:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:14:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:14:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:14:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:15:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:15:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:15:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:16:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:16:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:16:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:17:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:17:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:17:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:18:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:18:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:18:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:19:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:19:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:19:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:20:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:20:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:20:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:21:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:21:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:21:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:22:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:22:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:22:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:23:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:23:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:23:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:24:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:24:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:24:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:25:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:25:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:25:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:26:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:26:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:26:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:27:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:27:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:27:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:28:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:28:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:28:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:29:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:29:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:29:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:29:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:30:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:30:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:30:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:31:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:31:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:31:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:32:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:32:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:32:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:33:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:33:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:33:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:34:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:34:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:34:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:35:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:35:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:35:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:36:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:37:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:38:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 07:39:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:39:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:40:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:40:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:50:04 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 74
ERROR - 2020-10-29 07:50:12 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 74
ERROR - 2020-10-29 07:50:43 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 74
ERROR - 2020-10-29 07:51:01 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Bgimage.php 74
ERROR - 2020-10-29 07:55:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:55:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:55:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:56:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:56:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:56:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:57:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:57:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:57:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:58:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:58:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:58:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:58:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:58:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:59:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:59:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 07:59:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 07:59:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:00:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:00:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:00:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:01:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:01:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:01:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:02:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:02:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:02:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:03:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:03:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:03:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:04:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:04:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:04:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:05:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:05:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:05:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:06:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:06:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:06:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:07:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:07:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:07:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:07:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:08:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:08:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:08:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:09:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:09:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:09:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:10:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:10:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:10:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:10:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:11:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:11:31 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:11:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:11:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:11:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:12:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:12:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:12:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:13:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:13:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:13:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:13:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:13:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:13:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:13:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:14:15 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:14:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:14:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:14:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:14:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:14:59 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:15:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:15:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:15:09 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:15:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:15:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:15:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:15:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:16:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:16:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:16:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:16:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:16:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:16:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:17:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:17:17 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:17:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:17:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:17:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:18:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:18:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:18:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:19:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:19:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:19:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:20:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:20:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:20:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:21:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:21:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:21:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:22:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:22:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:22:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:22:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:23:10 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:23:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 08:23:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:23:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:23:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:24:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:24:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:24:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:25:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:25:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:25:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:25:57 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:26:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:26:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:26:13 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:26:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 08:26:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:26:28 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:26:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:26:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:26:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:26:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 08:27:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:27:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:27:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:28:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:28:09 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:28:09 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:28:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:28:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:28:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:28:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:29:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:29:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:29:45 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:29:45 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:29:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:29:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 08:30:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:30:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:30:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:30:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:30:41 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:30:41 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:30:41 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:30:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:30:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:31:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:31:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:31:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:32:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:32:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:32:41 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:32:42 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:32:42 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:32:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:32:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:32:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:32:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:33:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:33:23 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:33:23 --> 404 Page Not Found: Array/index
ERROR - 2020-10-29 08:33:23 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:33:23 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:33:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:33:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:33:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:34:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:34:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:34:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:35:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:35:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:35:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:35:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:35:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:36:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:36:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:37:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:37:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:37:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:38:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:38:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:38:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:38:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:38:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:39:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:39:15 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-29 08:39:16 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-29 08:39:18 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:39:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:39:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:39:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:39:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:39:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:40:02 --> 404 Page Not Found: Uploads/banners
ERROR - 2020-10-29 08:40:04 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:40:04 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:40:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:40:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:40:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:40:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:40:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:41:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:41:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:41:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:41:10 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:41:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:41:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:41:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:41:59 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:42:00 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:42:00 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 08:42:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:42:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:42:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:42:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:43:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:43:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:43:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:43:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:43:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:44:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:44:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:44:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:44:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:44:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:45:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:45:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:45:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:46:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:46:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:46:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:47:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:47:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:47:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:48:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:48:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:48:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:49:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:49:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:49:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:50:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:50:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:50:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:51:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:51:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:51:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:54 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:51:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:51:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:51:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:52:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:52:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:52:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 08:52:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:52:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:53:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:53:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:53:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:54:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:54:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:54:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:55:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:55:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 08:55:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:24 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:30 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:32 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:33 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:55:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:33 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 08:55:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:55:34 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 08:56:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:56:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 08:56:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 08:56:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:01:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:02:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:04:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:04:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:05:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:05:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:05:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:06:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:06:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:06:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:07:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:07:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:07:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:08:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:08:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:08:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:11:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:11:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:11:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:14:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:14:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:14:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:15:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:15:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:15:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:16:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:16:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:16:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:17:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:17:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:17:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:18:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:18:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:18:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:19:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:19:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:19:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:20:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:20:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:20:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:20:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:20:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 09:21:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:21:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:21:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:21:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 09:21:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:22:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:22:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:22:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:23:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:23:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:23:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:24:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:24:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:24:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 09:24:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:24:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 09:24:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:25:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:25:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 09:25:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:25:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:26:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:26:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:26:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:27:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:27:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:27:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:28:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:28:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:28:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:29:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:29:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:29:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:30:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:30:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:30:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:31:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:31:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:31:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:32:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:32:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:32:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:33:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:33:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:33:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:34:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:34:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:34:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:35:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:35:07 --> Query error: Unknown column 'id' in 'field list' - Invalid query: SELECT `id`
FROM `module_list`
ERROR - 2020-10-29 09:35:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 09:35:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 09:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 09:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 09:35:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:36:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:36:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:36:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:37:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:37:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:37:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:38:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:38:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:38:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:39:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:39:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:39:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:40:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:40:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:40:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:41:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:41:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:41:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:42:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:42:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:42:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:43:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:44:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:45:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:45:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:45:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:45:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:45:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:45:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:46:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:46:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:46:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:46:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:47:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:47:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:47:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:48:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:48:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:48:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:49:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:49:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:49:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:50:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 09:50:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:51:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:52:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:52:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:52:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 09:53:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 10:14:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 10:14:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 10:15:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 10:15:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 10:15:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:16:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:16:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:16:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:17:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:17:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:17:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:18:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:18:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:18:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:19:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:19:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:19:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:20:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:20:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:20:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:21:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:21:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:21:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:22:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:22:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:22:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:23:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:23:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:23:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:24:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:24:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:24:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:25:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:25:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:25:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:26:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:26:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 10:26:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:00:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:01:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:01:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:01:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:02:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:02:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:02:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:03:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:03:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:03:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:04:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:04:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:04:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:05:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:05:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:05:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:06:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:06:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:06:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:07:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:07:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:07:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:08:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:08:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:08:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:09:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:09:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:09:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:10:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:10:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:10:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:11:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:13:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:13:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:13:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:13:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:14:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:14:04 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `administrators` (`username`, `password`, `email`, `name`, `access_module`, `created_date`, `verified`, `status`) VALUES ('aasas', 'c7505aa1bcc6098e08ea11151100e9e767d22bfedcbfd7db14205b240e5e942f3f74c6704600db75e6e19599aa6bef132bf78168f7bce2f6e6c5506c5b4b1edek/8V0DpBz4wwsVEL/biz6TQFCebRK3WVgvUYjR6E4pM=', 'test@gmail.com', 'Testttt', Array, '2020-10-29 11:14:04', 1, 1)
ERROR - 2020-10-29 11:16:09 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `administrators` (`username`, `password`, `email`, `name`, `access_module`, `created_date`, `status`) VALUES ('aasas', 'e8e883674f2a14acc6beb1a198ed845c893a1aa5d54db147d02fc4793468d89573c5aa9b732f4f74bf715d8cd445ec5d77d1c0f05305494e7b7f1ae04577b89e3MQVGvIIk4DyN4Qpd9BR42t0rQjZZnSNq5U9hBwOwWc=', 'test@gmail.com', 'Testttt', Array, '2020-10-29 11:16:09', 1)
ERROR - 2020-10-29 11:23:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:23:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:23:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:24:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:24:27 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `administrators` (`username`, `password`, `email`, `name`, `access_module`, `created_date`, `status`) VALUES ('aasas', '900d292d420ab7f4b7c6c3abc93f02b3765a466fd563703c315097fc8b01842318546ce856db2c47e8dd18d87e29c36de41c739a7bdc8e268336b84d82d3a427sgBI3aIZmvE9AEFA9Qb5exdzRP2nPRMJciDQR2Wm59Y=', 'test@gmail.com', 'Testttt', Array, '2020-10-29 11:24:26', 1)
ERROR - 2020-10-29 11:24:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:25:59 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `administrators` (`username`, `password`, `email`, `name`, `access_module`, `created_date`, `status`) VALUES ('aasas', 'ddb3ccc1a68917d2851bd9f9bcf061d18f75be71aad863afb687ac68db20c33a91c64f422b5bd07ef6edd72b3964a3e809d812892ea274d8d1e87386436c6f75sOlq9xoA6BwBOH2J7Qi5OR7V0/z1NjeLpsBP3RyYs+Y=', 'test@gmail.com', 'Testttt', Array, '2020-10-29 11:25:59', 1)
ERROR - 2020-10-29 11:26:25 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `administrators` (`username`, `password`, `email`, `name`, `access_module`, `created_date`, `status`) VALUES ('aasas', '2db0df384149f63698811b652fa78c732a85fa23618c859dda7021d15f9fc1e0ec01f0bec6e6980548adf6351454dd85a4854ab259af2d2aa8bcb3006e1d477a4YUd6yR5fdXYE8yuDOH9erGblGuXv2WU2uWhRscyg7U=', 'test@gmail.com', 'Testttt', Array, '2020-10-29 11:26:25', 1)
ERROR - 2020-10-29 11:38:10 --> Query error: Table 'new_gigs.adminparams' doesn't exist - Invalid query: INSERT INTO `adminparams` (`admin_user_id`, `module_id`, `access_status`) VALUES (6, '1', 1)
ERROR - 2020-10-29 11:39:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:39:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:39:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:40:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:40:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:42:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:43:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:49:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:49:18 --> 404 Page Not Found: Undefinedadmin/dashboard
ERROR - 2020-10-29 11:49:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 11:50:12 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 11:50:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 11:50:13 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 11:50:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:50:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:50:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:50:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:50:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:51:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:51:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:51:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:52:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:52:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:53:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:53:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:53:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:53:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:54:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:54:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:54:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:55:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:55:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 11:55:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 11:55:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:01:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:01:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:01:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:01:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:01:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:02:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:02:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:02:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:02:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:02:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:02:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:02:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:03:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:03:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:03:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:04:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:04:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:04:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:05:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:05:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:05:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:06:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:06:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:06:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:06:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:08:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 12:09:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 12:12:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:12:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:12:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:12:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:12:53 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:12:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:12:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:12:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:13:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:13:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:13:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:14:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:14:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:14:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:15:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:15:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:16:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:16:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:16:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:17:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:17:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:17:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:18:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:18:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:19:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:19:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:20:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:20:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:20:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:21:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:21:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:21:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:22:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:22:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:22:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:23:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:23:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:23:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:24:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:24:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:24:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:25:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:25:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:25:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:26:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:26:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:26:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:27:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:27:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:27:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:28:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:28:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:28:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:29:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:29:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:29:38 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:34:13 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:34:45 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:34:45 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:35:32 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:35:34 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:24 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:29 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:36:30 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:36:30 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:36:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:44 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:36:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:36:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:37:53 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 161
ERROR - 2020-10-29 12:37:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:38:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:38:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:38:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:38:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:39:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:39:23 --> Severity: error --> Exception: syntax error, unexpected '$access_result_data_array' (T_VARIABLE) D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 412
ERROR - 2020-10-29 12:39:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:28 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:39:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:39:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:39:52 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:08 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:40:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:40:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:40:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:40:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:40:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:41:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:41:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:41:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:42:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:42:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:42:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:42:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:42:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 12:42:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:42:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:42:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:42:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 12:43:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:43:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 12:43:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 12:44:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 12:44:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:44:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:45:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:45:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:45:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:46:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:46:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:46:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:47:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:47:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:47:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:48:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:48:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:48:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:49:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:49:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:49:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 12:50:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:50:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:50:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:51:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:51:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:51:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:52:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:52:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:52:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:53:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:53:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:53:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:54:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:54:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:54:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:55:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:55:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:55:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:56:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:56:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:56:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:57:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:57:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:57:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:58:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:58:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 12:58:38 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 230
ERROR - 2020-10-29 12:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 12:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:01:20 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\thegigs_web\application\views\admin\includes\sidebar.php 230
ERROR - 2020-10-29 13:01:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:02:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:02:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:02:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:03:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:03:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:03:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:03:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:04:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:04:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:04:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:05:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:05:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:05:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:05:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:05:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:05:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:05:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:05:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:06:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:06:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:06:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:06:31 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:06:32 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:06:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:06:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:07:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 13:07:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:07:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:08:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:08:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:08:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:08:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:08:33 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:08:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:09:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:09:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:09:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:09:38 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:09:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:10:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:10:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:10:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:10:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:10:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:10:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:10:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:11:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:11:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:11:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:11:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:11:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:12:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:12:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:12:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:12:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:12:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:12:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:12:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:13:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:13:29 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:13:30 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:13:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:13:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:13:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:14:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:14:22 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:14:23 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:14:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:14:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:14:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:15:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:15:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:15:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:15:27 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:15:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:15:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:15:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:15:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:15:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:15:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:16:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:16:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:16:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:16:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:16:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:17:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:17:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:17:25 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:17:26 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:17:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:17:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:17:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:18:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:18:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:18:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:19:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:19:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:19:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:20:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:20:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:20:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:21:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:21:28 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:21:48 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:22:08 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:22:18 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:24:20 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:24:49 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:24:53 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:24:53 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\thegigs_web\application\controllers\admin\Dashboard.php 411
ERROR - 2020-10-29 13:25:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 13:26:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:26:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:26:37 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 13:26:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:26:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:27:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:27:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:27:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:28:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:28:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:28:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:29:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:29:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:29:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:30:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:30:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:30:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:31:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:31:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:31:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:32:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:32:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:32:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:33:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:33:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:33:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:34:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:34:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:34:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:35:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:35:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:35:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:36:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:36:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:36:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:37:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:37:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:37:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:38:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:38:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:38:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:39:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:39:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:39:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:40:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:40:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:40:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:40:17 --> Query error: Unknown column 'id' in 'field list' - Invalid query: SELECT `id`
FROM `module_access`
WHERE `admin_user_id` = '1'
AND `module_id` = '1'
AND `access_status` = 1
ERROR - 2020-10-29 13:40:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:40:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:41:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:41:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:41:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:41:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:42:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:42:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:42:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:43:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:43:31 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:43:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:43:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:43:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:44:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:44:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:44:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:44:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:44:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:44:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 13:45:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 13:45:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:46:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 13:46:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:47:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:47:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:47:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:48:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:48:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:49:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:49:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:49:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:50:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:50:42 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:50:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:50:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:50:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:50:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:51:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:51:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:51:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:52:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:52:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:52:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:53:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:59:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:59:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 13:59:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:59:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:59:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 13:59:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:00:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:00:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:00:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:00:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:48 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:00:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:00:49 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:50 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:50 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:51 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:00:52 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:01:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:01:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:01:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:02:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:02:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:02:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:03:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:03:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:03:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:04:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:04:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:04:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:04:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:04:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 14:05:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:05:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:05:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:06:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:06:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:06:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:07:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:07:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:07:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:08:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:08:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:08:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:09:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:09:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:09:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:10:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:10:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:10:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:11:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:11:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:11:45 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:12:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:12:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:12:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:13:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:13:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:13:44 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:14:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:14:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:26:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:26:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:27:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:27:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:27:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:27:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:27:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:27:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:28:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:28:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:28:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:29:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:29:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:29:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:29:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:29:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:29:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:30:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:30:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:30:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:30:58 --> 404 Page Not Found: Uploads/category
ERROR - 2020-10-29 14:31:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:31:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:31:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:31:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:31:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:32:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:32:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:32:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:32:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:32:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:32:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:32:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:33:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:33:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:34:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:01 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:34:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:07 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:09 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:25 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:34:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:34:42 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:43 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:44 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:45 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:45 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:46 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:47 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:48 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:34:53 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:35:09 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:35:13 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:35:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:35:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:35:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:35:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:35:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:36:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:36:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:36:26 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 14:43:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:43:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:43:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 14:43:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:43:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:43:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:43:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 14:43:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:43:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:44:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:44:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:44:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:45:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:45:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:45:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:46:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:46:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:46:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:47:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 14:48:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:48:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:48:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:48:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:48:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:49:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:49:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 14:49:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:50:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:50:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:50:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:51:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:51:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:51:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:52:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:52:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:52:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:53:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:53:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:53:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:54:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:54:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:54:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:55:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:55:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:55:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:56:15 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:56:35 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 14:56:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:11:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:11:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:12:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:03 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:04 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:06 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:07 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:12:14 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:15 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:15 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:16 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:17 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:18 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:19 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:12:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:20 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:21 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:12:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:12:28 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:12:32 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:04 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:07 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:08 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:24 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:25 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:43 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:44 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:44 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:44 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:45 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:13:45 --> Severity: error --> Exception: Call to a member function checkAdminUserPermission() on null D:\xampp\htdocs\thegigs_web\application\controllers\admin\Adminlist.php 17
ERROR - 2020-10-29 17:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:14:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:14:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:14:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:14:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:14:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:14:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:15:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:15:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:15:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:15:30 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:15:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:15:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:15:57 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:16:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:16:24 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN) D:\xampp\htdocs\thegigs_web\application\models\Common_model.php 9
ERROR - 2020-10-29 17:16:50 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN) D:\xampp\htdocs\thegigs_web\application\models\Common_model.php 9
ERROR - 2020-10-29 17:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:17:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:17:10 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:17:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:17:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:17:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:17:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` = 5
ERROR - 2020-10-29 17:17:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:17:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:17:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:18:16 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:18:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:18:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:18:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:18:50 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:19:09 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:19:29 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:19:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:20:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:20:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:20:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:20:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:20:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:20:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:20:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:21:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:21:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:21:05 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:21:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:21:26 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:21:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:21:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:21:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:22:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:22:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:22:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:22:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:22:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:22:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:22:34 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:22:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:22:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:22:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:22:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:23:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:23:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:23:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:24:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:24:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:24:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:25:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:25:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:25:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:26:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:26:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:26:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:27:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:27:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:27:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:28:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:28:39 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:29:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:29:20 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:29:40 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:30:00 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:11 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:30:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:30:18 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:37 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:30:38 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:30:49 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:30:51 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:31:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:31:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:31:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:31:06 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:31:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:31:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:31:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:31:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:31:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:55 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:56 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:31:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:31:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:59 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:31:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:31:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:00 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:32:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:32:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:03 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:32:06 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:32:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:32:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:32:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:32:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:32:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:32:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:33:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:33:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 17:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 17:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:33:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:33:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:33:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:33:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:34:08 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:34:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:34:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:34:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:34:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:34:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:35:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:35:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:35:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:35:31 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:35:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:35:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:36:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:36:11 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:36:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:36:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:36:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:36:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:37:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:37:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:37:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:37:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:37:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:37:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:38:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:38:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:38:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:38:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:38:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:38:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:39:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:39:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:39:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:39:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:39:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:39:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:40:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:40:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:40:27 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:40:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:40:47 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:40:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:41:07 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:41:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:41:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:41:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:42:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:42:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:42:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:43:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:43:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:43:52 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:44:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:44:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:44:53 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:45:12 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:45:32 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:45:51 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:45:54 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:45:55 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:45:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:57 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:58 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:45:59 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:46:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:46:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:46:07 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '10', NULL, '1', '2', 'Testtst\r\n', '0', 'Dfsdfsdf\r\n', '', 'USD', '2020-10-29 17:46:07', '', '', '', 1, 1)
ERROR - 2020-10-29 17:46:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:46:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:47:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:47:05 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '10', NULL, '1', '2', 'Testtst\r\n', '0', 'Dfsdfsdf\r\n', '', 'USD', '2020-10-29 17:47:05', '', '', '', 1, 1)
ERROR - 2020-10-29 17:47:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:47:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 17:47:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 17:47:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:47:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:47:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:47:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 17:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 17:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 17:47:56 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:47:57 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:48:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:48:16 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:48:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:48:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:48:38 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '5', NULL, '1', '5', 'Sds\r\n', '0', '', '', 'USD', '2020-10-29 17:48:38', '', '', '', 1, 1)
ERROR - 2020-10-29 17:48:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:49:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:49:10 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '5', NULL, '1', '5', 'Sds\r\n', '0', '', '', 'USD', '2020-10-29 17:49:10', '', '', '', 1, 1)
ERROR - 2020-10-29 17:49:17 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:49:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:49:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:49:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:49:24 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:49:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:49:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:49:58 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '2', 'Dfdf\r\n', '0', 'Dfsdf\r\n', '', 'USD', '2020-10-29 17:49:58', '', '', '', 1, 1)
ERROR - 2020-10-29 17:50:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:50:06 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '2', 'Dfdf\r\n', '0', 'Dfsdf\r\n', '', 'USD', '2020-10-29 17:50:06', '', '', '', 1, 1)
ERROR - 2020-10-29 17:50:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:50:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:51:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:51:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:51:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:52:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:52:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:52:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:52:46 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:52:46 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:53:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:53:04 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:53:05 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:53:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:53:24 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:53:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:53:44 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 17:54:01 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '5', 'Sdsdsd\r\n', '0', 'Sdsd\r\n', '', 'USD', '2020-10-29 17:54:01', '', '', '', 1, 1)
ERROR - 2020-10-29 17:54:02 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:54:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:54:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:55:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:55:21 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:55:41 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:55:51 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '5', 'Sdsdsd\r\n', '0', 'Sdsd\r\n', '', 'USD', '2020-10-29 17:55:51', '', '', '', 1, 1)
ERROR - 2020-10-29 17:56:01 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:57:57 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-29 17:57:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:57:59 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:58:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-10-29 17:58:00 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:01 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:02 --> 404 Page Not Found: Uploads/gig_images
ERROR - 2020-10-29 17:58:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 17:58:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:58:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:58:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:58:53 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '5', 'Sdsdsd\r\n', '0', 'Sdsd\r\n', '', 'USD', '2020-10-29 17:58:53', '', '', '', 1, 1)
ERROR - 2020-10-29 17:59:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:59:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 17:59:35 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '5', 'Sdsdsd\r\n', '0', 'Sdsd\r\n', '', 'USD', '2020-10-29 17:59:35', '', '', '', 1, 1)
ERROR - 2020-10-29 17:59:37 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '5', 'Sdsdsd\r\n', '0', 'Sdsd\r\n', '', 'USD', '2020-10-29 17:59:37', '', '', '', 1, 1)
ERROR - 2020-10-29 17:59:38 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-cleaning', '3', NULL, '1', '5', 'Sdsdsd\r\n', '0', 'Sdsd\r\n', '', 'USD', '2020-10-29 17:59:38', '', '', '', 1, 1)
ERROR - 2020-10-29 17:59:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:00:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 18:00:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 18:00:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 18:00:12 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:00:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:00:14 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:00:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:00:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:00:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:00:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:01:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:01:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:01:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:01:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:01:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:01:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:02:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:02:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:02:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:02:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:02:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:02:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:03:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:03:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:03:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:03:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:03:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:03:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:04:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:04:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:04:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:04:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:04:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:04:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:05:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:05:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:05:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:05:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:05:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:05:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:06:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:06:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:06:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:06:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:06:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:06:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:07:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:07:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:07:23 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:07:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:07:43 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:07:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:08:03 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT *
FROM `version_updates`
WHERE `build` IS NULL
ERROR - 2020-10-29 18:08:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:08:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:08:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:09:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:09:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:09:54 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:10:14 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:10:34 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:16:19 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:16:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:16:22 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:16:23 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:16:42 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:17:02 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:17:22 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:17:37 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'car-ghgh', '1', NULL, '1', '2', 'Ssd\r\n', '0', '', '', 'USD', '2020-10-29 18:17:37', '', '', '', 1, 1)
ERROR - 2020-10-29 18:19:36 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:19:36 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:19:48 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:19:49 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:20:08 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:20:18 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testtas', '3', NULL, '1', '5', 'Sdsd\r\n', '0', '', '', 'USD', '2020-10-29 18:20:18', '', '', '', 1, 1)
ERROR - 2020-10-29 18:20:49 --> Query error: Column 'time_zone' cannot be null - Invalid query: INSERT INTO `sell_gigs` (`user_id`, `title`, `gig_price`, `time_zone`, `delivering_time`, `category_id`, `gig_details`, `work_option`, `requirements`, `country_name`, `currency_type`, `created_date`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `cost_type`) VALUES ('14', 'testtas', '3', NULL, '1', '5', 'Sdsd\r\n', '0', '', '', 'USD', '2020-10-29 18:20:49', '', '', '', 1, 1)
ERROR - 2020-10-29 18:20:58 --> Query error: Table 'new_gigs.version_updates' doesn't exist - Invalid query: SELECT `version`
FROM `version_updates`
ORDER BY `version_id` DESC
ERROR - 2020-10-29 18:21:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 18:21:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-10-29 18:21:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-10-29 18:21:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:21:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:21:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:22:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:22:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:22:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:23:20 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:23:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:23:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:24:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:24:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:24:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:25:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:25:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:25:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:26:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:26:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:26:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:27:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:27:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:27:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:28:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:28:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:28:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:29:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:29:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:29:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:30:18 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:30:38 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:30:58 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:31:19 --> 404 Page Not Found: Uploads/profile_images
ERROR - 2020-10-29 18:31:38 --> 404 Page Not Found: Uploads/profile_images
