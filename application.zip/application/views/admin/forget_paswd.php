<?php
$query = $this->db->query("select * from system_settings WHERE status = 1");
$result = $query->result_array();
$this->website_name = '';
$fav = base_url() . 'assets/img/favicon.png';
if (!empty($result)) {
    foreach ($result as $data) {
        if ($data['key'] == 'website_name') {
            $this->website_name = $data['value'];
        }
        if ($data['key'] == 'favicon') {
            $favicon = $data['value'];
        }
    }
}
if (!empty($favicon)) {
    $fav = base_url() . 'uploads/logo/' . $favicon;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo $fav; ?>">
    <title><?php echo $this->website_name . ' Admin Panel'; ?></title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/css/admin.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url(); ?>assets/js/modernizr.min.js"></script>
</head>
<body>
    <div class="account-pages"></div>
    <div class="clearfix"></div>
    <div class="wrapper-page">
        <div class=" card-box">
            <div class="panel-heading text-center">
                <img class="img-fluid" src="<?= base_url(); ?>assets/img/logo-admin.png">
            </div>
            <div class="panel-body">
                <input type="hidden" id="base_url" value="<?php echo base_url(); ?>">
<!--                 <input type="hidden" id="login_error" value="<?php echo $this->session->flashdata('login_error'); ?>">
 -->                <!-- <?php
                if ($this->session->userdata('message')) {
                ?>
				<div class="alert alert-danger text-center fade in" id="flash_succ_message"><?php echo $this->session->userdata('message'); ?></div>
                <?php
                    $this->session->unset_userdata('message');
                }
                ?> -->
                <div id="fap_info"></div>
                <form action="" id="admin_login" class="m-t-20" method="post">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" name="email_id" id="email_id">
                    </div>
                    
                    <span id="login_error_msg" class="error_msg"></span>
                    <div class="form-group text-center m-t-40">
                        <button class="btn btn-primary btn-block text-uppercase" name="submit" type="submit" value="true" id="fap_login">Submit</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
    <script src="<?php echo base_url(); ?>assets/js/jquery-3.5.1.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrapValidator.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/admin_login.js"></script>
</body>
</html>