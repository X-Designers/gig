<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h4 class="page-title m-b-20 m-t-0">Add Client</h4>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card-box">
						<form id="admin_add_client" action="<?php echo base_url() . 'admin/client/create'; ?>" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="ip_addr">Client Url</label>
								<input type="url" name="client_name" placeholder="https://www.dreamguys.co.in" class="form-control" id="client_name">
								<span class="client_error"></span>
							</div>
							<div class="form-group">
								<label for="client_image">Client Image</label>
								<div id="avatar-view" class="avatar w200">
									<div class="dgt" data-status-upload-success="Client image updated" data-label-loading="File uploading.." data-instant-edit="true" data-service="<?php echo base_url(); ?>admin/client/upload_image" data-push="true" data-ratio="1:1" data-label="Upload Client Image" data-size="170,170" data-size="170,170" data-crop="0,0,170,170" data-max-file-size="2" data-will-remove="imageRemoved" data-did-upload="imageUpload">
										<input type="file" name="dgt[]"/>
									</div>
								</div>
								<span class="dgt_error"></span>
								<input type="hidden" name="imageurl" id="imageurl">
								<span class="help-block"><small>Recommended image size is <b>170px x 90px</b></small></span>
							</div>
							<div class="form-group">
								<label class="control-label">Status</label>
								<div>
									<div class="radio radio-primary radio-inline">
										<input type="radio" id="blog_status1" value="0" name="status" checked>
										<label for="blog_status1">Active</label>
									</div>
									<div class="radio radio-danger radio-inline">
										<input type="radio" id="blog_status2" value="1" name="status">
										<label for="blog_status2">Inactive</label>
									</div>
								</div>
							</div>
							<div class="form-group m-b-0 m-t-30">
								<button class="btn btn-primary" name="form_submit" value="submit" type="submit" id="submits">Submit</button>
								<a href="<?php echo base_url() . 'admin/client' ?>" class="btn btn-default m-l-5">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<input type="hidden" id="list_url" value="<?php echo base_url(); ?>admin/client">