<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h4 class="page-title m-b-20 m-t-0">Edit Banner</h4>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card-box">
						<form id="admin_edit_bgimage" action="<?php echo base_url() . 'admin/bgimage/edit/' . $list['id']; ?>" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="image_for">Image For</label>
								<select  name="image_for"  class="form-control" id="image_for">
								<option value="">Select</option>
								<option value="Slider_Bg" <?php if($list['bgimg_for']=='Slider_Bg') {echo "selected";} ?>>Slider Bg</option>
								<option value="Advertise" <?php if($list['bgimg_for']=='Advertise') {echo "selected";} ?>>Advertisement</option>
								<option value="Giggsicon" <?php if($list['bgimg_for']=='Giggsicon') {echo "selected";} ?>>Gigs Icon</option>
								</select>
							</div>
							<div class="form-group">
								<div class="text-center text-error" id="error-exist"></div>
								<label for="banner_img"> Image</label>
								<div class="uploader"><input type="file" class="form-control" name="banner_img" placeholder="Select file"></div>
								<br>
								<?php
									$upload_image = $list['upload_image'];
									$img_url = base_url() . $upload_image;
								if (!empty($upload_image)) { ?>
									<img src="<?php echo $img_url; ?>" class="site-logo" id="img_url" class="w120">
								<?php } ?>
							</div>
							
							<div class="form-group m-b-0 m-t-30">
								<button class="btn btn-primary" name="form_submit" value="submit" type="submit">Submit</button>
								<a href="<?php echo base_url() . 'admin/bgimage' ?>" class="btn btn-default m-l-5">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
