<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h4 class="page-title m-b-20 m-t-0">Edit Category</h4>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card-box">
						
						<form id="admin_edit_bgimage" action="<?php echo base_url() . 'admin/bgimage/edit_bgimg/' . $list['bgimg_id']; ?>" method="post" enctype="multipart/form-data">

							<div class="form-group">
								<label for="image_for">Image For</label>
								<select  name="image_for"  class="form-control" id="image_for" onchange="get_iconimagelist(image_for.value)">
								<option value="">Select</option>
								<option value="Slider_Bg" <?php if($list['bgimg_for']=='Slider_Bg') {echo "selected";} ?>>Slider Bg</option>
								<option value="Advertise" <?php if($list['bgimg_for']=='Advertise') {echo "selected";} ?>>Advertisement</option>
								<option value="Section3-Icon" <?php if($list['bgimg_for']=='Section3-Icon') {echo "selected";} ?>>Section3-Icon</option>
								</select>
							</div>
							
							<div class="form-group" id="bg_adimg" <?php if($list['bgimg_for']=='Section3-Icon'){ ?> style="display: none;"<?php } else { ?> style="display: block;"<?php } ?>>
								<div class="text-center text-error" id="error-exist"></div>
								<label for="banner_img"> Image</label>
								<div class="uploader"><input type="file" class="form-control" name="banner_img" placeholder="Select file"></div>
								<br>
								<?php
									$upload_image = $list['upload_image'];
									$img_url = base_url() . $upload_image;
								if (!empty($upload_image)) { ?>
									<img src="<?php echo $img_url; ?>" class="site-logo" id="img_url" class="w120">
								<?php } ?>
							</div>
						<div class="form-group" id="allgigsimg" <?php if($list['bgimg_for']=='Section3-Icon'){ ?> style="display: block;"<?php } else { ?> style="display: none;"<?php } ?>>
								<label for="client_image">Create Gig Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="creategig_ic" id="creategig_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="creategig_ic_imageurl" id="creategig_ic_imageurl">
								<label for="client_image">Publish Gig Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="publishgig_ic" id="publishgig_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="publishgig_ic_imageurl" id="publishgig_ic_imageurl">

								<label for="client_image">Receive Order Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="receive_ic" id="receive_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="receive_ic_imageurl" id="receive_ic_imageurl">
								<label for="client_image">Paid Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="paid_ic" id="paid_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="paid_ic_imageurl" id="paid_ic_imageurl">
								<!--<span class="help-block"><small>Recommended image size is <b>170px x 90px</b></small></span>-->
								<?php
									$upload_image = $list['upload_image'];
									$expimg=explode("###",$upload_image);
									foreach($expimg as $dimag)
									{
									$img_url = base_url() . $dimag;
								if (!empty($dimag)) { ?>
									<img src="<?php echo $img_url; ?>" class="site-logo" id="img_url" class="w120">
								<?php } }?>
							</div>
							<div id="" style="color:#d40f0f;">*Image Size for Banner Should be in 1872 x 476 , Advertisement : 1564 x 460,Icons : 25 x 25</div>
							<div class="form-group m-b-0 m-t-30">
								<input type="hidden" name="bgimg_id" value="<?php if (!empty($list['bgimg_id'])) { echo $list['bgimg_id']; } ?>" id="bgimg_id">
								<button class="btn btn-primary" name="form_submit" value="submit" type="submit">Submit</button>
								<a href="<?php echo base_url() . 'admin/bgimage' ?>" class="btn btn-default m-l-5">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>