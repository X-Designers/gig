<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h4 class="page-title m-b-20 m-t-0">Add Image</h4>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card-box">
						<form id="admin_add_bgimage" action="<?php echo base_url() . 'admin/bgimage/create'; ?>" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="ip_addr">Image for</label>
								<select  name="image_for"  class="form-control section3icon" id="image_for" onchange="get_iconimagelist(image_for.value)">
								<option value="">Select</option>
								<option value="Slider_Bg">Slider Bg</option>
								<option value="Advertise">Advertisement</option>
								<option value="Section3-Icon">Section3-Icon</option>
								</select>
								<span class="imgfor_error"></span>
							</div>

							<div class="form-group" id="bg_adimg">
								<label for="client_image">Upload Image</label>
								<!--<div id="avatar-view" class="avatar w200">
									<div class="dgt" data-status-upload-success="Bgimage image updated" data-label-loading="File uploading.." data-instant-edit="true" data-service="<?php echo base_url(); ?>admin/bgimage/upload_image" data-push="true" data-ratio="1:1" data-label="Upload Bgimage Image" data-size="170,170" data-size="170,170" data-crop="0,0,170,170" data-max-file-size="2" data-will-remove="imageRemoved" data-did-upload="imageUpload">
								<div class="uploader"><input type="file" class="form-control" name="banner_img" placeholder="Select file"></div>
									</div>
								</div>-->
								<div class="uploader"><input type="file" class="form-control" name="banner_img" id="banner_img" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="imageurl" id="imageurl">
								<!--<span class="help-block"><small>Recommended image size is <b>170px x 90px</b></small></span>-->
							</div>

							<div class="form-group" id="allgigsimg" style="display: none;">
								<label for="client_image">Create Gig Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="creategig_ic" id="creategig_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="creategig_ic_imageurl" id="creategig_ic_imageurl">
								<label for="client_image">Publish Gig Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="publishgig_ic" id="publishgig_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="publishgig_ic_imageurl" id="publishgig_ic_imageurl">

								<label for="client_image">Receive Order Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="receive_ic" id="receive_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="receive_ic_imageurl" id="receive_ic_imageurl">
								<label for="client_image">Paid Icon</label>
								
								<div class="uploader"><input type="file" class="form-control" name="paid_ic" id="paid_ic" placeholder="Select file"></div>

								<span class="dgt_error"></span>
								<input type="hidden" name="paid_ic_imageurl" id="paid_ic_imageurl">
								<!--<span class="help-block"><small>Recommended image size is <b>170px x 90px</b></small></span>-->
							</div>
							<div id="" style="color:#d40f0f;">*Image Size for Banner Should be in 1872 x 476 , Advertisement : 1564 x 460,Icons : 25 x 25</div>

							<div class="form-group m-b-0 m-t-30">
								<button class="btn btn-primary" name="form_submit" value="submit" type="submit" id="submits">Submit</button>
								<a href="<?php echo base_url() . 'admin/client' ?>" class="btn btn-default m-l-5">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<input type="hidden" id="list_url" value="<?php echo base_url(); ?>admin/bgimage">