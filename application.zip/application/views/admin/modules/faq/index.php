<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h4 class="page-title m-t-0">FAQ</h4>
				</div>
				
				<div class="col-sm-4 text-right m-b-20">
					<a href="<?php echo base_url($theme . '/' . $module . '/create'); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add FAQ</a>
				</div>
				
			</div>
			<?php
			if ($this->session->userdata('message')) {
				echo $this->session->userdata('message');
			}
			?>
			<div class="panel">
				<div class="panel-body">
					<div class="table-responsive">
						<table class="table table-striped table-actions-bar m-b-0">
							<thead>
								<tr>
									<th>#</th>
									<th>Title</th>
									<th>Description</th>
									<th class="text-right">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
								if (!empty($lists)) {
								$sno = 0;
								foreach ($lists as $row) {
									
										
										
								?>
								<tr>
									<td> <?php echo $sno+1; ?></td>
									<td> <?php echo ucfirst($row['page_title']); ?></td>
									<td> <?php echo $row['description'] ?></td>
									<td class="text-right">
										<a href="<?php echo base_url('admin/faq/edit/' . $row['faq_id']); ?>" class="on-default view-row table-action-btn" data-toggle="tooltip" data-placement="top" title="Edit"><i class="mdi mdi-pencil text-success"></i></a>&nbsp;
										<a href="javascript:;" class="on-default remove-row table-action-btn delete_faq_menu" data-toggle="tooltip" data-placement="top" title="Delete" id="Onremove_<?php echo $row['faq_id']; ?>" data-id="<?php echo $row['faq_id']; ?>"><i class="mdi mdi-window-close text-danger"></i></a>
									</td>
								</tr>
								<?php
									}
								}
								 else {
								?>
								<tr>
									<td colspan="5">
										<p class="text-danger text-center m-b-0">No Records Found</p>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>