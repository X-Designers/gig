<div class="content-page">
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <h4 class="page-title m-b-20 m-t-0">Edit FAQ</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="card-box">
                        
                        <form class="form-horizontal" action="<?php echo base_url('admin/faq/edit/' . $datalist['faq_id']); ?>" method="POST" enctype="multipart/form-data">
                            
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Page Title</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="page_title" id="page_title" value="<?php if ($datalist['page_title']) { echo $datalist['page_title']; } ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Page Content</label>
                                <div class="col-sm-9">
                                    <?php
                                    if (!empty($value['page_desc'])) {
                                        echo  "<textarea class='form-control' id='ck_editor_textarea_id' rows='6' name='page_desc'>" . $datalist['description'] . "</textarea>";
                                        echo display_ckeditor($ckeditor_editor1);
                                    } else {
                                        echo "<textarea class='form-control' id='ck_editor_textarea_id' rows='6' name='page_desc'> </textarea>";
                                        echo display_ckeditor($ckeditor_editor1);
                                    }
                                    ?>
                                </div>
                            </div>
                            
                            <div class="m-t-30 text-center">
                                <button name="form_submit" type="submit" class="btn btn-primary center-block" value="true">Save Changes</button>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>