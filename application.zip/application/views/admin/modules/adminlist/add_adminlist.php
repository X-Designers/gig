<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h4 class="page-title m-b-20 m-t-0">Add Admin</h4>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card-box">
						<form id="admin_addlist" action="<?php echo base_url() . 'admin/adminlist/add_adminlist/'; ?>" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label for="admin_fullname">Name</label>
								<input type="text" name="admin_fullname"  placeholder="Enter Full name" value="" class="form-control" id="admin_fullname">
							</div>
							<div class="form-group">
								<label for="admin_email">Email</label>
								<input type="text" name="admin_email" placeholder="Enter Email" value="" class="form-control" id="admin_email" >
							</div>
							<div class="form-group">
								<label for="admin_username">Username</label>
								<input type="text" name="admin_username" placeholder="Enter Username" value="" class="form-control" id="admin_username" >
							</div>
							<div class="form-group">
								<label for="admin_username">Password</label>
								<input type="text" name="admin_password" placeholder="Enter password" value="" class="form-control" id="admin_password" >
							</div>
							<div class="form-group">
								<label>Set Access</label>
								<div class="example1">
									<div><input type="checkbox" name="selectall1" id="selectallad1" class="all" value="1"> <label for="selectall1"><strong>Select all</strong></label></div>
									<?php
								$module_result = $this->db->select('*')->get('module_list')->result_array();

									 foreach ($module_result as $module) {
										$checkcondition  = "";
										//if(!empty($user['user_id'])){
											//$access_result = $this->db->where('admin_id',$user['user_id'])->where('module_id',$module['id'])->where('access',1)->select('id')->get('admin_access')->result_array();
											//if(!empty($access_result)){
												//$checkcondition  = "checked='checked'";
											//}
										//}
									?>
									<div><input type="checkbox" class="checkboxad" name="accesscheck[]" id="check<?php echo $module['module_id'];?>" value="<?php echo $module['module_id'];?>"> <label for="check1"><?php echo $module['module_name'];?></label></div>
									<?php } ?>									
								</div>
							</div>

							<!---<div class="form-group">
								<label for="admin_verified" class="control-label">Verified</label>
								<div>
									<div class="radio radio-primary radio-inline">
										<input type="radio" id="admin_verified" value="0" name="admin_verified" <?php if ($list['verified'] == 0) { echo 'checked=""'; } ?>>
										<label for="admin_verified">Active</label>
									</div>
									<div class="radio radio-danger radio-inline">
										<input type="radio" id="admin_verified" value="1" name="admin_verified" <?php if ($list['verified'] == 1) { echo 'checked=""'; } ?>>
										<?php if ($list['verified'] == 1) { ?>
										<label for="admin_verified1">Inactive</label>
										<?php } ?>
									</div>
								</div>
							</div>---->
							<!---<div class="form-group">
								<label for="admin_status" class="control-label">Status</label>
								<div class="">
									<div class="radio radio-primary radio-inline">
										<input type="radio" id="admin_status" value="0" name="admin_status" <?php if ($list['status'] == 0) { echo 'checked=""'; } ?>>
										<label for="admin_status">Active</label>
									</div>
									<div class="radio radio-danger radio-inline">
										<input type="radio" id="admin_status1" value="1" name="admin_status1" <?php if ($list['status'] == 1) { echo 'checked=""'; } ?>>
										<label for="admin_status1">Inactive</label>
									</div>
								</div>
							</div>--->
							<div class="form-group m-b-0 m-t-30">
								<button class="btn btn-primary" name="form_submit" value="submit" type="submit">Submit</button>
								<a href="<?php echo base_url() . 'admin/adminlist' ?>" class="btn btn-default m-l-5">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>