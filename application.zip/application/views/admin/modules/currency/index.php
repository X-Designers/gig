<div class="content-page">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<?php
					if ($this->session->flashdata('message')) { ?>
					<p class="bg-success"><?php echo $this->session->flashdata('message'); ?></p>
					<?php } ?>
					<h4 class="page-title m-b-20 m-t-0">Manage Currency</h4>
				</div>
				<div class="col-sm-4 text-right m-b-20">
					<a href="<?php echo base_url() . 'admin/currency/add_currency'; ?>" class="btn btn-primary btn-sm">
						<i class="fa fa-plus"></i> Add Currency
					</a>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card-box">
						<div class="table-responsive">
							<table class="table table-actions-bar table-striped releasetable m-b-0">
								<thead>
									<tr>
										<th>#</th>
										<th>Country</th>
										<th>Currency Code</th>
										<th>Status</th>
										<th>Created Date</th>
										<th class="text-right">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
									if (!empty($list)) {
									$i = 0;
									foreach ($list as $item) {
										$status = 'Active';
										if ($item['status'] == 0) {
											$status = 'Inactive';
										}
									?>
									<tr>
										<td><?php echo $i++; ?></td>
										<td><?php echo $item['currency_name']; ?></td>
										<td><?php echo $item['currency_code']; ?></td>
										<td id="change_staus_<?php echo $item['gig_id']; ?>"><?php echo $status; ?></td>
										<td><?php
											if (!empty($item['created_date'])) {
												echo date('d M Y', strtotime(str_replace('-', '/', $item['created_date'])));
											} else {
												echo "";
											}
											?></td>
										<td class="toogle_switch text-right">
											<a href="<?php echo base_url() . "admin/currency/edit_currency/" . $item['id']; ?>" class="table-action-btn" title="Edit">
												<i class="mdi mdi-pencil text-success"></i>
											</a>
											<a href="javascript:void(0)" data-id="<?php echo $item['id']; ?>" class="table-action-btn admin_delete_currency" title="Delete">
												<i class="mdi mdi-window-close text-danger"></i>
											</a>
										</td>
									</tr>
									<?php
									}
									} else {
									?>
									<tr>
										<td colspan="10">
											<p class="text-danger text-center m-b-0">No Records Found</p>
										</td>
									</tr>
									<?php
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>