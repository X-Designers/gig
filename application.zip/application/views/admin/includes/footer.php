			<footer class="footer text-right">
				&copy; <?php echo date('Y'); ?> <div class="version">Version 1.0</div>
			</footer>
			<input type="hidden" id="base_url" value="<?php echo base_url(); ?>">
			<input type="hidden" id="module" value="<?php echo $module; ?>">
			<input type="hidden" id="page" value="<?php echo $page; ?>">
			<input type="hidden" id="page_id" value="<?php echo $this->uri->segment(3); ?>">
		</div>
	</div>
	<script src="<?php echo base_url(); ?>assets/js/jquery-3.5.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootbox.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/detect.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/fastclick.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap-colorpicker.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap-switch.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrapValidator.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/admin_validation.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/admin.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jstz-1.0.4.min.js"></script>
	<?php if ($module == 'policy_settings' || $module == 'client') { ?>
	<script src="<?php echo base_url(); ?>assets/js/dgt.cropper.min.js"></script>
	<?php } ?>
</body>
</html>